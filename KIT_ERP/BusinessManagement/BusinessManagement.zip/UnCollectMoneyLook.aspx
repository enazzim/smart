<%@ Register TagPrefix="igtblexp" Namespace="Infragistics.WebUI.UltraWebGrid.ExcelExport" Assembly="Infragistics.WebUI.UltraWebGrid.ExcelExport.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Page language="c#" Codebehind="UnCollectMoneyLook.aspx.cs" AutoEventWireup="false" Inherits="KIT_ERP.BusinessManagement.UnCollectMoneyLook" %>
<%@ Register TagPrefix="uc1" TagName="CompanySearchControl" Src="../Common/CompanySearchControl/CompanySearchControl.ascx" %>
<%@ Register TagPrefix="igcmbo" Namespace="Infragistics.WebUI.WebCombo" Assembly="Infragistics.WebUI.WebCombo.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igtbl" Namespace="Infragistics.WebUI.UltraWebGrid" Assembly="Infragistics.WebUI.UltraWebGrid.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>UnCollectMoneyLook</title>
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<LINK href="../StyleSheet2.css" type="text/css" rel="stylesheet">
		<script language="javascript">
		<!--
		function ResettxtBox()
		{
			ResetBox();			
		}
		//-->
		</script>
	</HEAD>
	<body bgColor="#f7f6f6" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<TABLE id="Table1" style="Z-INDEX: 101; LEFT: 10px; POSITION: absolute; TOP: 10px" height="550"
				cellSpacing="0" cellPadding="0" width="800" border="0">
				<TR>
					<TD width="20"></TD>
					<TD vAlign="top" align="center" width="800">
						<FIELDSET style="BORDER-RIGHT: #696969 2px solid; BORDER-TOP: #696969 2px solid; BORDER-LEFT: #696969 2px solid; WIDTH: 800px; BORDER-BOTTOM: #696969 2px solid; HEIGHT: 48px"><LEGEND style="FONT-SIZE: 9pt" align="top">[�˻�����]
							</LEGEND>
							<TABLE id="Table2" cellSpacing="0" cellPadding="0" width="800">
								<TR>
									<TD align="left" width="210"><uc1:companysearchcontrol id="CSC1" runat="server"></uc1:companysearchcontrol></TD>
									<TD align="right" width="590"><FONT face="����"><INPUT id="btnReset" style="WIDTH: 65px; HEIGHT: 20px" onclick="javascript:ResettxtBox()"
												type="button" value="�ʱ�ȭ" name="btnReset">&nbsp; </FONT>
										<asp:button id="bt_Search" runat="server" Height="20px" Width="60px" Text="��  ��" Font-Size="10pt"></asp:button>&nbsp;</TD>
								</TR>
							</TABLE>
						</FIELDSET>
						&nbsp;
					</TD>
				</TR>
				<TR>
					<TD width="20"></TD>
					<TD vAlign="top" align="center" width="800">
						<FIELDSET style="BORDER-RIGHT: #696969 2px solid; BORDER-TOP: #696969 2px solid; BORDER-LEFT: #696969 2px solid; WIDTH: 800px; BORDER-BOTTOM: #696969 2px solid; HEIGHT: 425px"><LEGEND style="FONT-SIZE: 9pt" align="top">[�˻����]</LEGEND>
							<TABLE id="Table3" cellSpacing="0" cellPadding="0" width="800">
								<TR>
									<TD height="30"><igtbl:ultrawebgrid id="UltraWebGrid1" runat="server" Height="446px" Width="800px">
											<DisplayLayout AutoGenerateColumns="False" AllowSortingDefault="OnClient" RowHeightDefault="20px"
												Version="3.00" AllowColumnMovingDefault="OnServer" HeaderClickActionDefault="SortMulti" BorderCollapseDefault="Separate"
												AllowColSizingDefault="Free" RowSelectorsDefault="No" Name="UltraWebGrid1" CellClickActionDefault="RowSelect">
												<AddNewBox>
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													</Style>
												</AddNewBox>
												<Pager PageSize="19" StyleMode="ComboBox" AllowPaging="True">
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													</Style>
												</Pager>
												<HeaderStyleDefault Cursor="Hand" BorderStyle="Solid" BackColor="LightGray">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</HeaderStyleDefault>
												<RowSelectorStyleDefault Cursor="Hand"></RowSelectorStyleDefault>
												<FrameStyle Width="800px" BorderWidth="1px" Font-Size="8pt" Font-Names="Verdana" BorderStyle="Solid"
													BackColor="Silver" Height="446px"></FrameStyle>
												<FooterStyleDefault BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</FooterStyleDefault>
												<EditCellStyleDefault BorderWidth="0px" BorderStyle="None"></EditCellStyleDefault>
												<SelectedRowStyleDefault Cursor="Hand" ForeColor="White" BackColor="Navy"></SelectedRowStyleDefault>
												<RowAlternateStyleDefault Cursor="Hand" BackColor="LightSteelBlue"></RowAlternateStyleDefault>
												<RowStyleDefault Cursor="Hand" BorderWidth="1px" BorderColor="Gray" BorderStyle="Solid" BackColor="#EBEFF6">
													<Padding Left="3px"></Padding>
													<BorderDetails WidthLeft="0px" WidthTop="0px"></BorderDetails>
												</RowStyleDefault>
											</DisplayLayout>
											<Bands>
												<igtbl:UltraGridBand>
													<Columns>
														<igtbl:UltraGridColumn HeaderText="�ŷ�ó��" Key="CompanyName" HeaderClickAction="Select" BaseColumnName="CompanyName">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Left">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center" Height="25px"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����ڵ�Ϲ�ȣ" Key="BusinessRegistrationNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="BusinessRegistrationNum">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����" Key="SaleDistinction" Width="50px" HeaderClickAction="SortMulti"
															BaseColumnName="SaleDistinction">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����" Key="BuyingDistinction" Width="50px" HeaderClickAction="SortMulti"
															BaseColumnName="BuyingDistinction">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���� �����" Key="LastYearSaleTransferCost" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="LastYearSaleTransferCost">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���� ���Ծ�" Key="LastYearBuyingTransferCost" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="LastYearBuyingTransferCost">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� ����ݾ�" Key="TotalSaleCost1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� ���ݾ�" Key="CollectMoney1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� �̼��ݾ�" Key="UncollectMoney1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� ���Աݾ�" Key="TotalBuyingCost1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� ���ޱݾ�" Key="PaymentMoney1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1�� �����ޱݾ�" Key="UnPaymentMoney1" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney1">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� ����ݾ�" Key="TotalSaleCost2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� ���ݾ�" Key="CollectMoney2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� �̼��ݾ�" Key="UncollectMoney2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� ���Աݾ�" Key="TotalBuyingCost2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� ���ޱݾ�" Key="PaymentMoney2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2�� �����ޱݾ�" Key="UnPaymentMoney2" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney2">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� ����ݾ�" Key="TotalSaleCost3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� ���ݾ�" Key="CollectMoney3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� �̼��ݾ�" Key="UncollectMoney3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� ���Աݾ�" Key="TotalBuyingCost3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� ���ޱݾ�" Key="PaymentMoney3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3�� �����ޱݾ�" Key="UnPaymentMoney3" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney3">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ����ݾ�" Key="TotalSaleCost4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���ݾ�" Key="CollectMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� �̼��ݾ�" Key="UncollectMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���Աݾ�" Key="TotalBuyingCost4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���ޱݾ�" Key="PaymentMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� �����ޱݾ�" Key="UnPaymentMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ����ݾ�" Key="TotalSaleCost4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���ݾ�" Key="CollectMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� �̼��ݾ�" Key="UncollectMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���Աݾ�" Key="TotalBuyingCost4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� ���ޱݾ�" Key="PaymentMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4�� �����ޱݾ�" Key="UnPaymentMoney4" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney4">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� ����ݾ�" Key="TotalSaleCost5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� ���ݾ�" Key="CollectMoney5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� �̼��ݾ�" Key="UncollectMoney5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� ���Աݾ�" Key="TotalBuyingCost5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� ���ޱݾ�" Key="PaymentMoney5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5�� �����ޱݾ�" Key="UnPaymentMoney5" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney5">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� ����ݾ�" Key="TotalSaleCost6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� ���ݾ�" Key="CollectMoney6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� �̼��ݾ�" Key="UncollectMoney6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� ���Աݾ�" Key="TotalBuyingCost6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� ���ޱݾ�" Key="PaymentMoney6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="6�� �����ޱݾ�" Key="UnPaymentMoney6" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney6">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� ����ݾ�" Key="TotalSaleCost7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� ���ݾ�" Key="CollectMoney7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� �̼��ݾ�" Key="UncollectMoney7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� ���Աݾ�" Key="TotalBuyingCost7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� ���ޱݾ�" Key="PaymentMoney7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="7�� �����ޱݾ�" Key="UnPaymentMoney7" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney7">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� ����ݾ�" Key="TotalSaleCost8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� ���ݾ�" Key="CollectMoney8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� �̼��ݾ�" Key="UncollectMoney8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� ���Աݾ�" Key="TotalBuyingCost8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� ���ޱݾ�" Key="PaymentMoney8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="8�� �����ޱݾ�" Key="UnPaymentMoney8" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney8">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� ����ݾ�" Key="TotalSaleCost9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� ���ݾ�" Key="CollectMoney9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� �̼��ݾ�" Key="UncollectMoney9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� ���Աݾ�" Key="TotalBuyingCost9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� ���ޱݾ�" Key="PaymentMoney9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="9�� �����ޱݾ�" Key="UnPaymentMoney9" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney9">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� ����ݾ�" Key="TotalSaleCost10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� ���ݾ�" Key="CollectMoney10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� �̼��ݾ�" Key="UncollectMoney10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� ���Աݾ�" Key="TotalBuyingCost10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� ���ޱݾ�" Key="PaymentMoney10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="10�� �����ޱݾ�" Key="UnPaymentMoney10" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney10">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� ����ݾ�" Key="TotalSaleCost11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� ���ݾ�" Key="CollectMoney11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� �̼��ݾ�" Key="UncollectMoney11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� ���Աݾ�" Key="TotalBuyingCost11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� ���ޱݾ�" Key="PaymentMoney11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="11�� �����ޱݾ�" Key="UnPaymentMoney11" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney11">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� ����ݾ�" Key="TotalSaleCost12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalSaleCost12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� ���ݾ�" Key="CollectMoney12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="CollectMoney12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� �̼��ݾ�" Key="UncollectMoney12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UncollectMoney12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� ���Աݾ�" Key="TotalBuyingCost12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="TotalBuyingCost12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� ���ޱݾ�" Key="PaymentMoney12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="PaymentMoney12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="12�� �����ޱݾ�" Key="UnPaymentMoney12" Format="\ ###,###,###" HeaderClickAction="SortMulti"
															BaseColumnName="UnPaymentMoney12">
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
													</Columns>
												</igtbl:UltraGridBand>
											</Bands>
										</igtbl:ultrawebgrid></TD>
								</TR>
								<TR>
									<TD height="30"><FONT face="����">&nbsp;</FONT>
										<asp:button id="bt_Excel" runat="server" Height="20px" Width="60px" Text="Excel"></asp:button><igtblexp:ultrawebgridexcelexporter id="UltraWebGridExcelExporter1" runat="server"></igtblexp:ultrawebgridexcelexporter></TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
			</TABLE>
		</form>
	</body>
</HTML>
