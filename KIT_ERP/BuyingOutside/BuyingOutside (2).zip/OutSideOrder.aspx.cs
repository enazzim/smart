using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideOrder�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideOrder : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnRegistration;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected System.Web.UI.WebControls.LinkButton linkTempUpdate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcMaxDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcMinDate;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOO_HT;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		
		protected System.Web.UI.HtmlControls.HtmlInputHidden chkAll;
		protected Infragistics.WebUI.WebDataInput.WebDateTimeEdit wdcDeliveryDemandDate;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		DataSet dsOR = new DataSet();
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}
			ItemSearchControl1.HalfFinishedProducts = true;
			ItemSearchControl1.Products = true;	
			CSC1.UnitCostDistinction="���ְŷ�ó";
			

			if(!Page.IsPostBack)
			{
				Session["dsOR"] = dsOR;

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
				
			}		
			else
			{	
				dsOR = (DataSet)Session["dsOR"];
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.btnRegistration.Click += new System.EventHandler(this.btnRegistration_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			this.DataBinding += new System.EventHandler(this.uwgOO_HT_DataBinding);

		}
		#endregion

		private void uwgOO_HT_DataBinding(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
			SqlDataAdapter OO_DataAdapter1 = new SqlDataAdapter(@"SELECT OOR_HT.ItemNum, OOR_HT.ItemDrawNum, OOR_HT.ItemName, OOR_HT.UnitCostDistinction, OOR_HT.BeginProcessCode, OOR_HT.BeginProcess, OOR_HT.EndProcessCode, OOR_HT.EndProcess, CI_MT.CompanyName, OOR_HT.FirstDeliveryDemandQuantity, OOR_HT.FirstDeliveryDemandDate, SecondDeliveryDemandQuantity, SecondDeliveryDemandDate, ThirdDeliveryDemandQuantity, ThirdDeliveryDemandDate, FourthDeliveryDemandQuantity, FourthDeliveryDemandDate, FifthDeliveryDemandQuantity, FifthDeliveryDemandDate, OOR_HT.OrderQuantity, UCI_MT.StandardUnitCost as ApplyUnitCost,(UCI_MT.StandardUnitCost * FirstDeliveryDemandQuantity) as TotalCost, OOR_HT.ProgressCondition, OOR_HT.RegistrationPerson, OOR_HT.RegistrationPersonID, OOR_HT.RegistrationDate,  OOR_HT.UpdatingPerson, OOR_HT.UpdatingPersonID, OOR_HT.UpdatingDate, ProductionPlanHistoryIndex, OutSideOrderRequestHistoryIndex 
				FROM OOR_HT 
				INNER JOIN II_MT ON OOR_HT.ItemNum = II_MT.ItemNum 
				Inner join UCI_MT on OOR_HT.ItemNum = UCI_MT.ItemNum and OOR_HT.BeginProcessCode = UCI_MT.BeginProcessCode and OOR_HT.EndProcessCode = UCI_MT.EndProcessCode
				inner join CI_MT on UCI_MT.BusinessRegistrationNum = CI_MT.BusinessRegistrationNum
				WHERE OOR_HT.ItemNum like @num and OOR_HT.ItemDrawNum like @draw and OOR_HT.ItemName like @name 
				and II_MT.RecodingState = 1 
				and UCI_MT.RecodingState = 1 and UCI_MT.UnitCostDistinction = '���ִܰ�' and UCI_MT.OrderRate = (Select Max(OrderRate) From UCI_MT where ItemNum like @num and UnitCostDistinction = '���ִܰ�')
				and CI_MT.CompanyName Like @CompanyName
				and CI_MT.BusinessRegistrationNum Like @BusinessRegistrationNum
				and  (OOR_HT.RegistrationDate >= @begin and OOR_HT.RegistrationDate <= @end) and ItemClassification1 Like @Classification and (ProgressCondition = '���') order by CI_MT.CompanyName, FirstDeliveryDemandDate "+
				" SELECT ItemNum, ItemDrawNum, ItemName, UnitCostDistinction, BeginProcessCode, BeginProcess, EndProcessCode, EndProcess, CompanyName, BusinessRegistrationNum, OrderRate, FirstDeliveryDemandQuantity, FirstDeliveryDemandDate, SecondDeliveryDemandQuantity, SecondDeliveryDemandDate, ThirdDeliveryDemandQuantity, ThirdDeliveryDemandDate, FourthDeliveryDemandQuantity, FourthDeliveryDemandDate, FifthDeliveryDemandQuantity, FifthDeliveryDemandDate, OrderQuantity, ApplyUnitCost, TotalCost, RemainQuantity, VolumNum, ProgressCondition, RegistrationPerson, RegistrationPersonID, RegistrationDate, UpdatingPerson, UpdatingPersonID, UpdatingDate, OutSideOrderRequestHistoryIndex, OutSideOrderHistoryIndex FROM OO_HT WHERE (ItemNum IS NULL)",conn);

			OO_DataAdapter1.SelectCommand.Parameters.Add("@num",SqlDbType.VarChar).Value = "%"+ItemSearchControl1.ItemNum+"%";
			if(ItemSearchControl1.hdItem.Trim() == "")
			{
				OO_DataAdapter1.SelectCommand.Parameters.Add("@draw",SqlDbType.VarChar).Value = "%"+ItemSearchControl1.ItemDrawNum+"%";
				OO_DataAdapter1.SelectCommand.Parameters.Add("@name",SqlDbType.VarChar).Value = "%"+ItemSearchControl1.ItemName+"%";
			}
			else
			{
				OO_DataAdapter1.SelectCommand.Parameters.Add("@draw",SqlDbType.VarChar).Value = "%%";
				OO_DataAdapter1.SelectCommand.Parameters.Add("@name",SqlDbType.VarChar).Value = "%%";
			}

			OO_DataAdapter1.SelectCommand.Parameters.Add("@Classification",SqlDbType.VarChar).Value ="%"+ddlItemClassification1.SelectedItem.Value+"%";
			OO_DataAdapter1.SelectCommand.Parameters.Add("@CompanyName",SqlDbType.VarChar).Value = "%"+CSC1.Company+"%";
			OO_DataAdapter1.SelectCommand.Parameters.Add("@BusinessRegistrationNum",SqlDbType.VarChar).Value =  "%"+CSC1.BusinessRegistrationNum+"%";

			if(wdcMinDate.Text.Trim()=="")
				OO_DataAdapter1.SelectCommand.Parameters.Add("@begin",SqlDbType.SmallDateTime).Value = DateTime.Parse("1900-01-01").ToShortDateString();
			else
				OO_DataAdapter1.SelectCommand.Parameters.Add("@begin",SqlDbType.SmallDateTime).Value = DateTime.Parse(wdcMinDate.Value.ToString()).ToShortDateString();
			if(wdcMaxDate.Text.Trim()=="")
				OO_DataAdapter1.SelectCommand.Parameters.Add("@end",SqlDbType.SmallDateTime).Value = DateTime.Parse("2076-06-06").ToShortDateString();
			else
				OO_DataAdapter1.SelectCommand.Parameters.Add("@end",SqlDbType.SmallDateTime).Value = DateTime.Parse(wdcMaxDate.Value.ToString()).ToShortDateString();

			OO_DataAdapter1.Fill(dsOR);

			

			int drRowCount = 0;
			foreach(DataRow dr in dsOR.Tables[0].Rows)
			{
				drRowCount++;

				//�� BO_HT�� ���ι��� ���� �Ƿڿ����� ������ ���� ����
				string strSQL = @"select * from UCI_MT, CI_MT,II_MT where UCI_MT.RecodingState = 1 and CI_MT.RecodingState =1 and 
								II_MT.RecodingState = 1 and UCI_MT.UnitCostDistinction = '���ִܰ�' and 
								UCI_MT.BusinessRegistrationNum = CI_MT.BusinessRegistrationNum AND II_MT.ItemNum = UCI_MT.ItemNum 
								AND UCI_MT.ItemNum = '" + dr["ItemNum"] + "' and BeginProcessCode = '"+dr["BeginProcessCode"]+ "' and EndProcessCode = '"+dr["EndProcessCode"]+"'  and UCI_MT.OrderRate != 0 order by UCI_MT.OrderRate desc";

				DataSet dsUCI_CI_IIJoin= new DataSet();	
				SqlDataAdapter UCI_CI_IIJoinAdapter = new SqlDataAdapter(strSQL,conn);
				UCI_CI_IIJoinAdapter.Fill(dsUCI_CI_IIJoin);

				DataTable table = dsOR.Tables[1];

				for(int count =0; count <=dsUCI_CI_IIJoin.Tables[0].Rows.Count - 1;count++)
				{
					Decimal first = 0, second = 0, third = 0, fourth = 0, fifth = 0;

					//������� row�� dsBR�� �߰���.

					DataRow row = table.NewRow();
					row["ItemNum"] = dsUCI_CI_IIJoin.Tables[0].Rows[count]["ItemNum"].ToString();
					row["ItemDrawNum"] = dsUCI_CI_IIJoin.Tables[0].Rows[count]["ItemDrawNum"].ToString();
					row["ItemName"] = dsUCI_CI_IIJoin.Tables[0].Rows[count]["ItemName"].ToString();

					row["CompanyName"] = dsUCI_CI_IIJoin.Tables[0].Rows[count]["CompanyName"].ToString();
					row["BusinessRegistrationNum"] = dsUCI_CI_IIJoin.Tables[0].Rows[count]["BusinessRegistrationNum"].ToString();
					row["OrderRate"] = Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString());
				
					//OO_HTrow.FirstDeliveryDemandDate = DateTime.Parse(dr["FirstDeliveryDemandDate"].ToString());					
					
					if(Convert.IsDBNull(dr["FirstDeliveryDemandDate"]))
						row["FirstDeliveryDemandDate"] = Convert.DBNull;					
					else
						row["FirstDeliveryDemandDate"] = DateTime.Parse(dr["FirstDeliveryDemandDate"].ToString());	

					if(Convert.IsDBNull(dr["SecondDeliveryDemandDate"]))
						row["SecondDeliveryDemandDate"] = Convert.DBNull;					
					else
						row["SecondDeliveryDemandDate"] = DateTime.Parse(dr["SecondDeliveryDemandDate"].ToString());

					if(Convert.IsDBNull(dr["ThirdDeliveryDemandDate"]))
						row["ThirdDeliveryDemandDate"] = Convert.DBNull;					
					else
						row["ThirdDeliveryDemandDate"] = DateTime.Parse(dr["ThirdDeliveryDemandDate"].ToString());					
					
					if(Convert.IsDBNull(dr["FourthDeliveryDemandDate"]))
						row["FourthDeliveryDemandDate"] = Convert.DBNull;					
					else
						row["FourthDeliveryDemandDate"] = DateTime.Parse(dr["FourthDeliveryDemandDate"].ToString());					
				
					if(Convert.IsDBNull(dr["FifthDeliveryDemandDate"]))
						row["FifthDeliveryDemandDate"] = Convert.DBNull;					
					else
						row["FifthDeliveryDemandDate"] = DateTime.Parse(dr["FifthDeliveryDemandDate"].ToString());
								
					if(count == dsUCI_CI_IIJoin.Tables[0].Rows.Count - 1)
					{
						//1������ 5������ ���ⷮ
						first=Decimal.Parse(dsOR.Tables[0].Rows[drRowCount - 1]["FirstDeliveryDemandQuantity"].ToString());
						second=Decimal.Parse(dsOR.Tables[0].Rows[drRowCount - 1]["SecondDeliveryDemandQuantity"].ToString());
						third=Decimal.Parse(dsOR.Tables[0].Rows[drRowCount - 1]["ThirdDeliveryDemandQuantity"].ToString());
						fourth=Decimal.Parse(dsOR.Tables[0].Rows[drRowCount - 1]["FourthDeliveryDemandQuantity"].ToString());
						fifth=Decimal.Parse(dsOR.Tables[0].Rows[drRowCount - 1]["FifthDeliveryDemandQuantity"].ToString());
					

						
						//��ǰ��� ������ü�� ������� ������ ȸ���� ���ּ��� ���ϴ� ��
						for(int rowCount = dsOR.Tables[1].Rows.Count - (dsUCI_CI_IIJoin.Tables[0].Rows.Count - 1); rowCount <= dsOR.Tables[1].Rows.Count - 1; rowCount++)
						{					
							first -= Decimal.Parse(dsOR.Tables[1].Rows[rowCount]["FirstDeliveryDemandQuantity"].ToString());
							second -= Decimal.Parse(dsOR.Tables[1].Rows[rowCount]["SecondDeliveryDemandQuantity"].ToString());
							third -= Decimal.Parse(dsOR.Tables[1].Rows[rowCount]["ThirdDeliveryDemandQuantity"].ToString());
							fourth -= Decimal.Parse(dsOR.Tables[1].Rows[rowCount]["FourthDeliveryDemandQuantity"].ToString());
							fifth -= Decimal.Parse(dsOR.Tables[1].Rows[rowCount]["FifthDeliveryDemandQuantity"].ToString());
						}							
					}

					else
					{			
						//������ ������ 1������ 5�������� ��ǰ�䱸���� ����ؼ� ���� �ִ´�.
						first = Decimal.Parse(dr["FirstDeliveryDemandQuantity"].ToString())*Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString())/100;
						second = Decimal.Parse(dr["SecondDeliveryDemandQuantity"].ToString())*Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString())/100;
						third = Decimal.Parse(dr["ThirdDeliveryDemandQuantity"].ToString())*Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString())/100;
						fourth = Decimal.Parse(dr["FourthDeliveryDemandQuantity"].ToString())*Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString())/100;
						fifth = Decimal.Parse(dr["FifthDeliveryDemandQuantity"].ToString())*Decimal.Parse(dsUCI_CI_IIJoin.Tables[0].Rows[count]["OrderRate"].ToString())/100;						
					}


					//1������ 5������ ��ǰ�䱸���� ����� ���� ������ �䱸���� �־��ش�.					
					row["FirstDeliveryDemandQuantity"] = first;
					row["SecondDeliveryDemandQuantity"] = second;
					row["ThirdDeliveryDemandQuantity"] = third;
					row["FourthDeliveryDemandQuantity"] = fourth;
					row["FifthDeliveryDemandQuantity"] = fifth;
					
									
					//��ȸ�纰 �� ��ǰ�䱸���� 1������ 5�������� ��ǰ�䱸���� ���Ѱ��� �־��ش�.
					row["OrderQuantity"] = first+ second + third + fourth + fifth;
					row["RemainQuantity"] = first+ second + third + fourth + fifth;
					row["OutSideOrderRequestHistoryIndex"] = int.Parse(dr["OutSideOrderRequestHistoryIndex"].ToString());//�����Ƿڿ����ȣ
					
					//�� �ŷ�ó���� ����ܰ��� �ٸ��⶧���� �ŷ�ó���� �ܰ����̺����� ���ִܰ��� �����ͼ� �����ش�
					row["BeginProcessCode"] = dr["BeginProcessCode"].ToString(); //���۰����ڵ�
					row["BeginProcess"] = dr["BeginProcess"].ToString();//���۰���
					row["EndProcessCode"] = dr["EndProcessCode"].ToString(); //��������ڵ�
					row["EndProcess"] = dr["EndProcess"].ToString();//�������	

					string str = @"Select * From UCI_MT Where RecodingState = 1 and UnitCostDistinction = '���ִܰ�' and BusinessRegistrationNum = @com and 
						BeginProcessCode = @begin and EndProcessCode = @end and ItemNum = @Item  and UCI_MT.OrderRate != 0 order by UCI_MT.OrderRate desc";
					conn.Open();
					SqlCommand comm =new SqlCommand(str,conn);
					comm.Parameters.Add("@com",SqlDbType.VarChar).Value = dsUCI_CI_IIJoin.Tables[0].Rows[count]["BusinessRegistrationNum"].ToString();
					comm.Parameters.Add("@begin",SqlDbType.VarChar).Value = row["BeginProcessCode"].ToString();
					comm.Parameters.Add("@end",SqlDbType.VarChar).Value = row["EndProcessCode"].ToString();
					comm.Parameters.Add("@Item",SqlDbType.VarChar).Value = row["ItemNum"].ToString();
					SqlDataReader drow = comm.ExecuteReader();
					while(drow.Read())
					{
						row["ApplyUnitCost"] = Decimal.Parse(drow["StandardUnitCost"].ToString());//ǥ�شܰ�
					}
					drow.Close();
					conn.Close();

					row["TotalCost"] = Decimal.Parse(row["ApplyUnitCost"].ToString()) * Decimal.Parse(row["OrderQuantity"].ToString()); //�ѱݾ�														
					row["UnitCostDistinction"] = dr["UnitCostDistinction"].ToString();//�ܰ�����
					
					if(first+ second + third + fourth + fifth != 0)
						dsOR.Tables[1].Rows.Add(row);		
				}
			}
			

			try
			{
				//�����Ƿڿ���� ���� ���ֵ��� ���� ���ֿ����� ���̺����� ����ξ��ش�.
				//�����Ƿڰ� ���� ���ֵ��� ���� ���ֿ����� ���̺����� ����ξ��ش�.
				dsOR.Relations.Add(dsOR.Tables[0].Columns["OutSideOrderRequestHistoryIndex"],
					dsOR.Tables[1].Columns["OutSideOrderRequestHistoryIndex"]);	
			}

			catch(System.Exception x)
			{
				string s = x.Message;
				string m = s;
			}

			finally
			{
				//ó�� ���̴� ȭ�鿡�� ����Ʈ�� �����Ƿڿ����� ������ +Ŭ���������� ���ֿ����� ���´�.
				uwgOO_HT.DataSource = dsOR.Tables[0].DefaultView;	
			}

		}


		private void btnRegistration_Click(object sender, System.EventArgs e)
		{
			
			//�׸��忡 ǰ���� ���µ� ���ֹ�ư�� Ŭ�������� �޼���â
			if(this.uwgOO_HT.Rows.Count == 0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('���ֺ��� ǰ���� �����ϴ�.');");
				Response.Write("history.back();");
				Response.Write("</script>");
			}
			else
			{


				for(int i = 0; i < uwgOO_HT.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(uwgOO_HT.Rows[i].Cells.FromKey("chk").Value == null)
					{
						uwgOO_HT.Rows[i].Cells.FromKey("chk").Value = false;
					}

					if(!bool.Parse(uwgOO_HT.Rows[i].Cells.FromKey("chk").Value.ToString()))
					{
						// ������ ����Լ�
						DataRow[] row = dsOR.Tables[0].Select("OutSideOrderRequestHistoryIndex = '" + uwgOO_HT.Rows[i].Cells.FromKey("OutSideOrderRequestHistoryIndex").Value + "'");
						dsOR.Tables[0].Rows.Remove(row[0]);
					}
				}

//				for(int i = uwgOO_HT.Rows.Count-1; i >= 0 ; i--)
//				{
//					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
//					if(uwgOO_HT.Rows[i].Cells.FromKey("chk").Value == null)
//					{
//						uwgOO_HT.Rows[i].Cells.FromKey("chk").Value = false;
//					}
//
//					if(!bool.Parse(uwgOO_HT.Rows[i].Cells.FromKey("chk").Value.ToString()))
//					{
//						// ������ ����Լ�
//						DataRow[] row = dsOR.Tables[0].Select("OutSideOrderRequestHistoryIndex = '" + uwgOO_HT.Rows[i].Cells.FromKey("OutSideOrderRequestHistoryIndex").Value + "'");
//						dsOR.Tables[0].Rows.Remove(row[0]);
//						row[0].Delete();
//					}
//				}

				if(dsOR.Tables[0].Rows.Count == 0)
				{
					Response.Write("<script language=javascript>");
					Response.Write("alert('�׸��� ������ �ּ���!');");
					Response.Write("</script>");

				}
				else
				{
					
					//��ϰ�ü�� ���
					KIT_ERP.Register register = new Register(dsOR,"OutSideOrder",Session["ID"].ToString());
					register.DataSetRegistration();

					// ����� �ϰ����ڿ��� üũ�ڽ� ���ڸ� false�� �ٲپ��ش�
					for(int i = 0; i < uwgOO_HT.Rows.Count; i++)
					{
						uwgOO_HT.Rows[i].Cells[0].Value = false;
					}

					dsOR.Tables[1].Clear();
					dsOR.Tables[0].Clear();
					Session["dsOR"] = dsOR;
					if(uwgOO_HT.Rows.Count == 0)
						Session.Remove("dsOR");

					this.DataBind();


				}
			}
	
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{

			if(dsOR.Tables.Count != 0)
			{
				dsOR.Tables[1].Clear();
				dsOR.Tables[0].Clear();
			}
			this.DataBind();
		}
	}
}