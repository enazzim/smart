<%@ Register TagPrefix="igtbl" Namespace="Infragistics.WebUI.UltraWebGrid" Assembly="Infragistics.WebUI.UltraWebGrid.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igcmbo" Namespace="Infragistics.WebUI.WebCombo" Assembly="Infragistics.WebUI.WebCombo.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igsch" Namespace="Infragistics.WebUI.WebSchedule" Assembly="Infragistics.WebUI.WebDateChooser.v1.2, Version=1.2.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="uc1" TagName="ItemSearchControl" Src="../Common/ItemSearchControl/ItemSearchControl.ascx" %>
<%@ Page language="c#" Codebehind="BuyingDelivery.aspx.cs" AutoEventWireup="false" Inherits="KIT_ERP.BuyingOutside.BuyingDelivery" codePage="949" %>
<%@ Register TagPrefix="uc1" TagName="CompanySearchControl" Src="../Common/CompanySearchControl/CompanySearchControl.ascx" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta http-equiv="Content-Type" content="text/html; charset=ks_c_5601-1987">
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<script language="javascript" src="../MessageWindows.js"></script>
		<LINK href="../StyleSheet2.css" type="text/css" rel="stylesheet">
		<SCRIPT type="text/javascript"><!--
		function ResettxtBox()
		{
			
			ResetTextBox();
			ResetBox();
			var objChooser1 = igdrp_getComboById("wcStartDate");
			var objChooser2 = igdrp_getComboById("wcEndDate");
			objChooser1.setValue(null);
			objChooser2.setValue(null);	
			document.Form1.ddlItemClassification1.options[0].selected=true;
		}
		
		function Lot(inputValue)
        {
			document.Form1.hdLotNum.value = inputValue;
			document.Form1.Textbox1.value = inputValue;
			
		}
		function open()
		{
			//window.showModalDialog("../LotNumberManagement.aspx","","width=760,height=400,left=300,top=400, center=yes, resizable= yes");
			window.open("../LotNumberManagement.aspx","","width=760,height=400,left=300,top=400, center=yes, resizable= yes");
		}
		
		var Test = 0;
		
		
		
		//�׸��峻 �׸��������� �Ʒ��� �ؽ�Ʈ�ڽ��� ��ä���
		function uwgBD_HT_AfterSelectChangeHandler(gridName, id) {		
			rowindex(id);//�׸��� ������ �ϰ� �Ǹ� hidden�� � ������ ���� �Ͽ����� �����ڸ� �ִ� �Լ��� ȣ��	
		}
		
		//Grid��  ������ �ϸ� � �׸��带 �����Ͽ����� ���屸�� hidden�ʵ忡 ���� �ִ� �Լ�
		function rowindex(id)
		{		
			var num = new Array(3);			
			
			num = id.split('_');
			if(num.length > 2)
			{
				document.Form1.HistoryIndex.value = "1";																
			}
			else
			{
				document.Form1.HistoryIndex.value = "0";			
			}
		}
		
		function uwgBD_HT_DblClickHandler(gridName, cellId){
			
			
			// �ʱ�ȭ
			document.Form1.txtItemNum.value = "";
			document.Form1.txtCost.value = "";
			document.Form1.txtItemName.value = "";
			document.Form1.txtDeliveryQuantity.value = "";
			document.Form1.txtOrderQuantity.value = "";
			document.Form1.txtCashQuantity.value = "";
			document.Form1.txtRemainQuantity.value = "";
			
			Form1.btnRegistration.focus();
			
			
			
			var row = igtbl_getRowById(cellId);//������ �ο��� �ε���
		
		
			if(document.Form1.HistoryIndex.value == 1)
			{
				//�׸��忡�� �ڽ� �׸����� ������ ���������� �׸� ��ä���
				document.Form1.txtItemNum.value = row.getCellFromKey("ItemNum").getValue();//ǰ���ȣ
				document.Form1.txtCost.value = row.getCellFromKey("ApplyUnitCost").getValue();//����ܰ�
				document.Form1.txtItemName.value = row.getCellFromKey("ItemName").getValue();//ǰ���
				document.Form1.txtDeliveryQuantity.value = row.getCellFromKey("DeliveryRequestQuantity").getValue();//��ǰ�Ƿڼ���
				document.Form1.txtOrderQuantity.value = "";
				document.Form1.txtCashQuantity.value = "";
				document.Form1.txtRemainQuantity.value = "";
				document.Form1.UnitCost.value = row.getCellFromKey("UnitCost").getValue();//�ܰ�
				
				
				document.Form1.HistoryIndex.value = "1";//���屸�� (��ǰ�Ƿڿ����� ������ ���� ǥ����)
				document.Form1.IndexNum.value = row.getCellFromKey("BuyingDeliveryRequestHistoryIndex").getValue();//���ų�ǰ�Ƿڿ����ȣ
				
				
				
				
			
			}
			else
			{
				//�׸��忡�� �θ𳻿��� ���������� �׸� ��ä���
				document.Form1.txtItemNum.value = row.getCellFromKey("ItemNum").getValue();//ǰ���ȣ
				document.Form1.txtCost.value = row.getCellFromKey("ApplyUnitCost").getValue();//����ܰ�
				document.Form1.txtItemName.value = row.getCellFromKey("ItemName").getValue();//ǰ���
				document.Form1.txtDeliveryQuantity.value = row.getCellFromKey("RemainQuantity").getValue();//��ǰ����
				document.Form1.txtOrderQuantity.value = row.getCellFromKey("OrderQuantity").getValue();//���ּ���
				document.Form1.txtCashQuantity.value = Number(row.getCellFromKey("OrderQuantity").getValue()) - Number(row.getCellFromKey("RemainQuantity").getValue());//���Լ���
				document.Form1.txtRemainQuantity.value = row.getCellFromKey("RemainQuantity").getValue();//�ܷ�
				document.Form1.UnitCost.value = row.getCellFromKey("UnitCost").getValue();//�ܰ�
				
				document.Form1.HistoryIndex.value = "0";//���屸�� (���ֿ����� ������ ���� ǥ����)
				document.Form1.IndexNum.value = row.getCellFromKey("BuyingOrderHistoryIndex").getValue();//���Ź��ֿ����ȣ
				
			}
	
		}
		
		function Process()
		{
		
		
			var value = Number(Form1.txtRemainQuantity.value) - Number(Form1.txtDeliveryQuantity.value);
			
			if(value < 0)
			{
				if(Test = 0)
				{
					if(confirm("�԰������� �ܷ����� �����ϴ�! �׷����԰��Ͻðڽ��ϱ�?")) 
					{
							Test =1;
							return true;
					}
					else
					{
						Form1.txtDeliveryQuantity.value = 0;	
						Form1.txtDeliveryQuantity.focus();	
							return false;
					}
				}
			}
			
			
		
			/*	
				var txtIncongruityQuantity = Form1.txt;
						var value = Number(RemoveComma(Form1.txtRemainQuantity.value)) - Number(RemoveComma(Form1.txtDeliveryQuantity.value));
						var sqTxt = Form1.txtSuccessQuantity;
			//���ֺ����� 0%�� �ɼ������Ƿ� 0%�� �ȴٸ� �޼���â�� ����ְ� ������ ����� �ٽ� ä���.
			//if(Form1.txtDeliveryQuantity.value > Form1.txtRemainQuantity.value)
			if(sqTxt < 0)
			{
			//	alert("�ܷ����� ��ǰ������ �����ϴ�!");			
				
			//	Form1.txtDeliveryQuantity.value = 0;	
			//	Form1.txtDeliveryQuantity.focus();	
				if(confirm("��ǰ������ �ܷ����� �����ϴ� �׷�����ǰ�Ͻðڽ��ϱ�?")) 
				{
				
						return true;
				}
				else
				{
					Form1.txtDeliveryQuantity.value = 0;	
					Form1.txtDeliveryQuantity.focus();	
						return false;
				}
				
			} 
			
			*/
		
		}
		
--></SCRIPT>
	</HEAD>
	<body bottomMargin="0" leftMargin="0" topMargin="0" rightMargin="0" ms_positioning="GridLayout"
		XMLNS:igtbl="http://schemas.infragistics.com/ASPNET/WebControls/UltraWebGrid" onload="document.Form1.btnRegistration.focus();">
		<form id="Form1" method="post" runat="server">
			<TABLE id="Table1" style="Z-INDEX: 100; POSITION: relative; TOP: 10px; LEFT: 10px" cellSpacing="0"
				cellPadding="0" width="800" border="0" height="550">
				<TR>
					<TD style="HEIGHT: 11px" width="20"></TD>
					<TD style="HEIGHT: 11px"><FIELDSET style="BORDER-BOTTOM: dimgray 2px solid; BORDER-LEFT: dimgray 2px solid; WIDTH: 800px; HEIGHT: 20px; BORDER-TOP: dimgray 2px solid; BORDER-RIGHT: dimgray 2px solid"
							align="middle"><LEGEND style="FONT-SIZE: 10pt" align="left">[ �˻� ]
							</LEGEND>
							<TABLE id="Table2" cellSpacing="0" cellPadding="0" width="800" align="center" border="0">
								<TR height="35">
									<TD align="left" width="800" colSpan="8" height="30">
										<table id="table4" cellSpacing="0" cellPadding="0" width="800" align="center" border="0">
											<tr>
												<td width="200">
													<uc1:CompanySearchControl id="CSC1" runat="server"></uc1:CompanySearchControl></td>
												<td width="600"><uc1:itemsearchcontrol id="ItemSearchControl1" runat="server"></uc1:itemsearchcontrol></td>
											</tr>
										</table>
									</TD>
								</TR>
								<TR>
									<TD align="right" width="70" height="30">����䱸��&nbsp;</TD>
									<TD align="left" width="100" height="30">
										<igsch:webdatechooser id="wcStartDate" runat="server" BorderColor="DimGray" Height="20px" BackColor="#EEEEE9"
											BorderStyle="Solid" Width="100px" Text=" " NullDateLabel=" ">
											<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
												ShowTitle="False" ShowFooter="False">
												<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
												<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
												<DropDownStyle BackColor="White"></DropDownStyle>
												<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
											</CalendarLayout>
											<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid" BackColor="#EEEEE9"></DropDownStyle>
											<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
											<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
										</igsch:webdatechooser></TD>
									<TD align="center" width="5" height="30">~</TD>
									<TD width="100" height="30">
										<igsch:webdatechooser id="wcEndDate" runat="server" BorderColor="DimGray" Height="20px" BackColor="#EEEEE9"
											BorderStyle="Solid" Width="100px" Text=" " NullDateLabel=" ">
											<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
												ShowTitle="False" ShowFooter="False">
												<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
												<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
												<DropDownStyle BackColor="White"></DropDownStyle>
												<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
											</CalendarLayout>
											<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid" BackColor="#EEEEE9"></DropDownStyle>
											<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
											<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
										</igsch:webdatechooser></TD>
									<td width="100" align="right">��ǰ��&nbsp;</td>
									<td width="100" align="left">
										<asp:dropdownlist id="ddlItemClassification1" runat="server" Width="115px" BackColor="#EEEEE9"></asp:dropdownlist></td>
									<TD align="right" colSpan="2" height="30" width="325"><INPUT id="btnReset" style="WIDTH: 65px; HEIGHT: 20px" onclick="javascript:ResettxtBox()"
											type="button" value="�ʱ�ȭ" name="btnReset">&nbsp;
										<asp:button id="btnSearch" runat="server" Height="20px" Width="65px" Text="��   ��" Font-Size="9pt"></asp:button>&nbsp;
									</TD>
								</TR>
								<TR>
									<TD align="right" colSpan="8" height="8"></TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
				<TR>
					<TD style="HEIGHT: 400px" width="20"></TD>
					<TD style="HEIGHT: 400px" vAlign="top" align="left">
						<FIELDSET style="BORDER-BOTTOM: dimgray 2px solid; BORDER-LEFT: dimgray 2px solid; WIDTH: 800px; HEIGHT: 100%; BORDER-TOP: dimgray 2px solid; FONT-WEIGHT: normal; BORDER-RIGHT: dimgray 2px solid"
							align="middle"><LEGEND style="FONT-SIZE: 10pt" align="left">[ �˻� ]
							</LEGEND>
							<TABLE id="Table3" align="center" cellSpacing="0" cellPadding="0" width="800">
								<TR height="35">
									<TD vAlign="top" align="center"><igtbl:ultrawebgrid id="uwgBD_HT" runat="server" Width="800px" Height="386px">
											<DisplayLayout StationaryMargins="Header" AutoGenerateColumns="False" AllowSortingDefault="Yes"
												RowHeightDefault="20px" Version="3.00" ViewType="Hierarchical" SelectTypeRowDefault="Extended"
												ScrollBarView="Horizontal" ScrollBar="Always" AllowColumnMovingDefault="OnServer" HeaderClickActionDefault="SortMulti"
												BorderCollapseDefault="Separate" AllowColSizingDefault="Free" RowSelectorsDefault="No" Name="uwgBDxHT"
												TableLayout="Fixed" CellClickActionDefault="RowSelect">
												<AddNewBox>
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">

<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White">
</BorderDetails>

</Style>
												</AddNewBox>
												<Pager PageSize="16" StyleMode="ComboBox" AllowPaging="True">
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">

<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White">
</BorderDetails>

</Style>
												</Pager>
												<HeaderStyleDefault VerticalAlign="Middle" BorderStyle="Solid" BackColor="LightGray" Height="25px">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</HeaderStyleDefault>
												<FrameStyle Width="800px" BorderWidth="1px" Font-Size="9pt" Font-Names="����" BorderColor="DimGray"
													BorderStyle="Solid" BackColor="Silver" Height="386px"></FrameStyle>
												<FooterStyleDefault BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</FooterStyleDefault>
												<ClientSideEvents AfterSelectChangeHandler="uwgBD_HT_AfterSelectChangeHandler" DblClickHandler="uwgBD_HT_DblClickHandler"></ClientSideEvents>
												<EditCellStyleDefault BorderWidth="0px" BorderStyle="None"></EditCellStyleDefault>
												<SelectedRowStyleDefault Cursor="Hand" ForeColor="White" BackColor="Navy"></SelectedRowStyleDefault>
												<RowAlternateStyleDefault Cursor="Hand" BackColor="LightSteelBlue"></RowAlternateStyleDefault>
												<RowStyleDefault Cursor="Hand" BorderWidth="1px" Font-Size="9pt" Font-Names="����" BorderColor="Gray"
													BorderStyle="Solid" BackColor="#EBEFF6">
													<Padding Left="3px"></Padding>
													<BorderDetails WidthLeft="0px" WidthTop="0px"></BorderDetails>
												</RowStyleDefault>
											</DisplayLayout>
											<Bands>
												<igtbl:UltraGridBand Key="ItemNum">
													<Columns>
														<igtbl:UltraGridColumn HeaderText="ǰ���ȣ" Key="ItemNum" Width="120px" HeaderClickAction="SortMulti" BaseColumnName="ItemNum">
															<CellStyle HorizontalAlign="Left">
																<Padding Left="2px"></Padding>
															</CellStyle>
															<HeaderStyle Height="25px"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ȣ" Key="ItemDrawNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ItemDrawNum">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǰ���" Key="ItemName" HeaderClickAction="SortMulti" BaseColumnName="ItemName">
															<CellStyle HorizontalAlign="Left">
																<Padding Left="2px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����" Key="Unit" Width="35px" BaseColumnName="Unit">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�� ��" Key="Standard" BaseColumnName="Standard"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ŷ�ó��" Key="CompanyName" HeaderClickAction="SortMulti" BaseColumnName="CompanyName">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����ڵ�Ϲ�ȣ" Key="BusinessRegistrationNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="BusinessRegistrationNum">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="1����ǰ�䱸��" Key="FirstDeliveryDemandQuantity" Hidden="True" Format="###,###,##0.00"
															HeaderClickAction="SortMulti" BaseColumnName="FirstDeliveryDemandQuantity">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ѹ��ַ�" Key="OrderQuantity" Width="80px" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="OrderQuantity">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ܷ�" Key="RemainQuantity" Width="70px" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="RemainQuantity">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����䱸��" Key="FirstDeliveryDemandDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="FirstDeliveryDemandDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2����ǰ�䱸��" Key="SecondDeliveryDemandQuantity" Hidden="True" Format="###,###,##0.00"
															HeaderClickAction="SortMulti" BaseColumnName="SecondDeliveryDemandQuantity">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="2����ǰ�䱸��" Key="SecondDeliveryDemandDate" Hidden="True" Format="yyyy-MM-dd"
															HeaderClickAction="SortMulti" BaseColumnName="SecondDeliveryDemandDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3����ǰ�䱸��" Key="ThirdDeliveryDemandQuantity" Hidden="True" Format="###,###,##0.00"
															HeaderClickAction="SortMulti" BaseColumnName="ThirdDeliveryDemandQuantity">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="3����ǰ�䱸��" Key="ThirdDeliveryDemandDate" Hidden="True" Format="yyyy-MM-dd"
															HeaderClickAction="SortMulti" BaseColumnName="ThirdDeliveryDemandDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4����ǰ�䱸��" Key="FourthDeliveryDemandQuantity" Hidden="True" Format="###,###,##0.00"
															HeaderClickAction="SortMulti" BaseColumnName="FourthDeliveryDemandQuantity">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="4����ǰ�䱸��" Key="FourthDeliveryDemandDate" Hidden="True" Format="yyyy-MM-dd"
															HeaderClickAction="SortMulti" BaseColumnName="FourthDeliveryDemandDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5����ǰ�䱸��" Key="FifthDeliveryDemandQuantity" Hidden="True" Format="###,###,##0.00"
															HeaderClickAction="SortMulti" BaseColumnName="FifthDeliveryDemandQuantity">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="5����ǰ�䱸��" Key="FifthDeliveryDemandDate" Hidden="True" Format="yyyy-MM-dd"
															HeaderClickAction="SortMulti" BaseColumnName="FifthDeliveryDemandDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǥ�شܰ�" Key="UnitCost" Width="60px" Format="###,###,###" BaseColumnName="UnitCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���ִܰ�" Key="ApplyUnitCost" Width="60px" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="ApplyUnitCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ѱݾ�" Key="TotalCost" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="TotalCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���ֺ���" Key="OrderRate" Width="50px" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="OrderRate">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������ȣ" Key="VolumNum" Hidden="True" HeaderClickAction="SortMulti" BaseColumnName="VolumNum">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�������" Key="ProgressCondition" Width="70px" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ProgressCondition">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationPerson" HeaderClickAction="SortMulti" BaseColumnName="RegistrationPerson">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ID" Key="RegistrationPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationPersonID"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������" Key="UpdatingPerson" HeaderClickAction="SortMulti" BaseColumnName="UpdatingPerson">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������ID" Key="UpdatingPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingPersonID"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������" Key="UpdatingDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="��ȣ" Key="BuyingOrderHistoryIndex" Width="50px" HeaderClickAction="SortMulti"
															BaseColumnName="BuyingOrderHistoryIndex">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
													</Columns>
												</igtbl:UltraGridBand>
											</Bands>
										</igtbl:ultrawebgrid></TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
				<TR>
					<TD width="20"></TD>
					<TD>
						<TABLE style="WIDTH:800px; HEIGHT:46px" cellSpacing="0" cellPadding="0">
							<TR>
								<TD align="right" height="8" width="60"></TD>
								<TD height="8" width="100"></TD>
								<TD align="right" height="8" width="60"></TD>
								<TD height="8" width="100"></TD>
								<TD align="right" height="8" width="60"></TD>
								<TD height="8" width="100"></TD>
								<TD align="right" height="8" width="60"></TD>
								<TD align="left" height="8" width="100"></TD>
								<TD align="right" height="8" width="160"><INPUT id="hdLotNum" style="WIDTH: 67px; HEIGHT: 21px" type="hidden" size="5" runat="server"><INPUT id="IndexNum" style="WIDTH: 15px; HEIGHT: 21px" type="hidden" size="1" runat="server"><INPUT id="HistoryIndex" style="WIDTH: 15px; HEIGHT: 21px" type="hidden" size="1" runat="server"><INPUT id="UnitCost" style="WIDTH: 15px; HEIGHT: 21px" type="hidden" size="1" name="Hidden1"
										runat="server"></TD>
							</TR>
							<TR>
								<TD align="right" width="60">ǰ��&nbsp;</TD>
								<TD width="100"><asp:textbox id="txtItemNum" runat="server" Width="100px" Enabled="False" BorderStyle="Solid"
										BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px"></asp:textbox></TD>
								<TD align="right" width="60">ǰ��&nbsp;</TD>
								<TD width="100"><asp:textbox id="txtItemName" runat="server" Width="100px" Enabled="False" BorderStyle="Solid"
										BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px"></asp:textbox></TD>
								<TD title="ǰ���:" align="right" width="60">�԰���&nbsp;</TD>
								<TD width="100"><asp:textbox id="txtDeliveryQuantity" runat="server" style="TEXT-ALIGN: right" Width="100px"
										BorderStyle="Solid" BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px">0</asp:textbox></TD>
								<TD align="right" width="60">�ܰ� &nbsp;</TD>
								<TD align="left" width="100">
									<asp:textbox id="txtCost" style="TEXT-ALIGN: right" runat="server" BorderColor="DimGray" Height="20px"
										BackColor="#EEEEE9" BorderWidth="1px" BorderStyle="Solid" Width="100px">0</asp:textbox></TD>
								<TD align="right" width="160">�⵵
									<asp:dropdownlist id="ddlYear" runat="server" Width="55px" BackColor="#EEEEE9">
										<asp:ListItem Value="2018">2018</asp:ListItem>
										<asp:ListItem Value="2019">2019</asp:ListItem>
										<asp:ListItem Value="2020">2020</asp:ListItem>
										<asp:ListItem Value="2021">2021</asp:ListItem>
										<asp:ListItem Value="2022">2022</asp:ListItem>
										<asp:ListItem Value="2023">2023</asp:ListItem>
										<asp:ListItem Value="2024">2024</asp:ListItem>
										<asp:ListItem Value="2025">2025</asp:ListItem>
										<asp:ListItem Value="2026">2026</asp:ListItem>
										<asp:ListItem Value="2027">2027</asp:ListItem>
									</asp:dropdownlist>��
									<asp:dropdownlist id="ddlMon" runat="server" Width="40px" BackColor="#EEEEE9">
										<asp:ListItem Value="1">1</asp:ListItem>
										<asp:ListItem Value="2">2</asp:ListItem>
										<asp:ListItem Value="3">3</asp:ListItem>
										<asp:ListItem Value="4">4</asp:ListItem>
										<asp:ListItem Value="5">5</asp:ListItem>
										<asp:ListItem Value="6">6</asp:ListItem>
										<asp:ListItem Value="7">7</asp:ListItem>
										<asp:ListItem Value="8">8</asp:ListItem>
										<asp:ListItem Value="9">9</asp:ListItem>
										<asp:ListItem Value="10">10</asp:ListItem>
										<asp:ListItem Value="11">11</asp:ListItem>
										<asp:ListItem Value="12">12</asp:ListItem>
									</asp:dropdownlist></TD>
							</TR>
							<TR>
								<TD title="���ּ���:" style="HEIGHT: 24px" align="right" width="60">���ַ�&nbsp;</TD>
								<TD style="HEIGHT: 24px" width="100"><asp:textbox id="txtOrderQuantity" style="TEXT-ALIGN: right" runat="server" Width="100px" Enabled="False"
										BorderStyle="Solid" BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px"></asp:textbox></TD>
								<TD style="HEIGHT: 24px" align="right" width="60">���Է�&nbsp;</TD>
								<TD style="HEIGHT: 24px" width="100"><asp:textbox id="txtCashQuantity" style="TEXT-ALIGN: right" runat="server" Width="100px" Enabled="False"
										BorderStyle="Solid" BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px"></asp:textbox></TD>
								<TD style="HEIGHT: 24px" align="right" width="60">�ܷ�&nbsp;</TD>
								<TD style="HEIGHT: 24px" width="100"><asp:textbox id="txtRemainQuantity" style="TEXT-ALIGN: right" runat="server" Width="100px" Enabled="False"
										BorderStyle="Solid" BackColor="#EEEEE9" Height="20px" BorderColor="DimGray" BorderWidth="1px"></asp:textbox></TD>
								<TD style="HEIGHT: 24px" align="right" width="60">
									�԰���&nbsp;</TD>
								<TD style="HEIGHT: 24px" align="left" width="100"><igsch:webdatechooser id="wdcDeliveryDate" runat="server" NullDateLabel=" " Width="100px" BackColor="#EEEEE9"
										Height="20px">
										<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
											ShowTitle="False" ShowFooter="False">
											<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
											<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
											<DropDownStyle BackColor="White"></DropDownStyle>
											<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
										</CalendarLayout>
										<DropDownStyle BorderStyle="Inset"></DropDownStyle>
										<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
										<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
									</igsch:webdatechooser></TD>
								<TD align="right" width="160"><asp:button id="btnRegistration" runat="server" Width="65px" Height="20px" Text="��   ��" Font-Size="9pt"></asp:button>&nbsp;</TD>
							</TR>
						</TABLE>
					</TD>
				</TR>
			</TABLE>
		</form>
	</body>
</HTML>
