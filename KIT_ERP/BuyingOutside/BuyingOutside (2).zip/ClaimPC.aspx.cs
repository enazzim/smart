using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Configuration;
using System.Data.SqlClient;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// ClaimPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ClaimPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcFromDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcToDate;
		protected System.Web.UI.WebControls.Button bt_Search;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected System.Web.UI.WebControls.Button bt_Excel;
		protected System.Web.UI.WebControls.LinkButton lnk_Update;
		protected System.Web.UI.WebControls.Button bt_Delete;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter UltraWebGridExcelExporter1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_RowIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_RowSelectIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_Cost;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdMon;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
	


		/// <summary>
		/// Ŭ���ӿ���
		/// </summary>
		protected DataSet ClaimCause
		{
			get
			{
				Update source = new Update(Session["ID"].ToString());
				DataSet ds_Cause = source.ClaimCause();			
				return ds_Cause;
			}
		}

		/// <summary>
		/// Ŭ��������
		/// </summary>
		protected DataSet ClaimStatus
		{
			get
			{
				Update source = new Update(Session["ID"].ToString());
				DataSet ds_Status = source.ClaimStatus();
				return ds_Status;
			}
		}





		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			ItemSearchControl1.Commodity = true; //��ǰ ���ε�				
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			ItemSearchControl1.HalfFinishedProducts = true;//����ǰ ���ε�
			ItemSearchControl1.RawMaterials = true;//������ ���ε�
			CSC1.UnitCostDistinction = "���ſ���";

			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if(!Page.IsPostBack)
			{
				bt_Delete.Attributes.Add("onClick","return confirm('������ �׸��� �����Ͻðڽ��ϱ�?');");
				
				
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_Search.Click += new System.EventHandler(this.bt_Search_Click);
			this.bt_Excel.Click += new System.EventHandler(this.bt_Excel_Click);
			this.lnk_Update.Click += new System.EventHandler(this.lnk_Update_Click);
			this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
			this.UltraWebGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.UltraWebGrid1_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_Search_Click(object sender, System.EventArgs e)
		{
			UltraWebGrid1.DataSource = Find();
			UltraWebGrid1.DataBind();
		}

		/// <summary>
		/// �˻��Լ�
		/// </summary>
		/// <returns></returns>
		private DataSet Find()
		{
			Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
                search = new Search("ClaimPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,wdcFromDate,wdcToDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			else
				search = new Search("ClaimPC",ItemSearchControl1.ItemNum, "", "",wdcFromDate,wdcToDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			return search.DataSet_search();
		}

		private void bt_Delete_Click(object sender, System.EventArgs e)
		{
			Delete del = new Delete(UltraWebGrid1,"ClaimPC");
			del.MainRowDelete();
			UltraWebGrid1.DataSource = Find();
			UltraWebGrid1.DataBind();
		}

		private void lnk_Update_Click(object sender, System.EventArgs e)
		{
			ArrayList arr = new ArrayList();
			arr.Add(decimal.Parse(lb_Cost.Value));//������ �ݾ�
			arr.Add(int.Parse(hdYear.Value));//�����⵵
            arr.Add(int.Parse(hdMon.Value));//������
			arr.Add(int.Parse(lb_RowSelectIndex.Value));//���� �׸��� Row�ε���

			KIT_ERP.Update up = new KIT_ERP.Update("ClaimPC",arr,UltraWebGrid1,Session["ID"].ToString());
			up.MainTableUpdate();
			UltraWebGrid1.DataSource = Find();
			UltraWebGrid1.DataBind();
		}

		private void bt_Excel_Click(object sender, System.EventArgs e)
		{
			if(UltraWebGrid1.Rows.Count == 0)
			{
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else
			{
				Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwg_CL = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
				uwg_CL = UltraWebGrid1;
				uwg_CL.DisplayLayout.Pager.AllowPaging = false;
				uwg_CL.Columns.FromKey("chk").Hidden = true;
				uwg_CL.DataSource = Find();
				uwg_CL.DataBind();
				UltraWebGridExcelExporter1.Export(uwg_CL);

			}
		}

		private void UltraWebGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			UltraWebGrid1.DataSource = Find();
			UltraWebGrid1.DataBind();
		}
	}
}
