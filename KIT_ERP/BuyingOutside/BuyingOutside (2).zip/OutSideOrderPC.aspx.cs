using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideOrderPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideOrderPC : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.Button btnStop;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOO_HT;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected System.Web.UI.WebControls.Button btnNext;
		protected System.Web.UI.WebControls.Button btnNow;
		protected System.Web.UI.WebControls.Button btnPre;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		private static int Division;		
		//private static string Volum;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Volum;
		private DataSet ds;
		protected System.Web.UI.WebControls.Button btEndCancel;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected System.Web.UI.WebControls.Button btEnd;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.WebControls.DropDownList ddlState;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}


			ItemSearchControl1.HalfFinishedProducts = true; //����ǰ ���ε�
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction = "���ְŷ�ó";


			if(!Page.IsPostBack)
			{

				// ������ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnDelete.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ���ָ� ���� �Ͻðڽ��ϱ�?');");
				// ��ҹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnCancel.Attributes.Add("onClick","return Confirm('���ָ� ��� �Ͻðڽ��ϱ�?');");
				// �ߴܹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnStop.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ���ָ� �ߴ� �Ͻðڽ��ϱ�?');");
				
				
				Volnum();
				// ������ư Ŭ���� ���忡�� ����ū �ε��� ��ȣ�� ������
				//�׸��忡 �׸��� ���� ���� ��ҹ�ư ��Ȱ��ȭ
				if(uwgOO_HT.Rows.Count == 0)
					btnCancel.Enabled = false;

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.btnPre.Click += new System.EventHandler(this.btnPre_Click);
			this.btnNow.Click += new System.EventHandler(this.btnNow_Click);
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			this.uwgOO_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgOO_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.btEnd.Click += new System.EventHandler(this.btEnd_Click);
			this.btEndCancel.Click += new System.EventHandler(this.btEndCancel_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCalcel_Click);
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("OutSideOrderPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName, wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value,ddlItemClassification1.SelectedItem.Value);
			else
				search = new KIT_ERP.Search("OutSideOrderPC",ItemSearchControl1.ItemNum,"", "", wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value,ddlItemClassification1.SelectedItem.Value);
			return search.DataSet_search();
		}


		/// <summary>
		/// �˻���ư Ŭ�� 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnSearch_Click(object sender, System.EventArgs e)
		{

			uwgOO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
			uwgOO_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgOO_HT.DataSource = Search();
			this.uwgOO_HT.DataBind();

			Division = 0;
			btnCancel.Enabled = false;
		}

		//������ư Ŭ��
		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			if(this.uwgOO_HT.Rows.Count ==0)
			{				
				Response.Write("<script language=javascript>");
				Response.Write("alert('������ ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				KIT_ERP.Delete delete = new KIT_ERP.Delete(uwgOO_HT,"OutSideOrderPC");
				delete.MainRowDelete();

				if(Division == 0)
				{
					this.uwgOO_HT.DataSource = Search();
					this.uwgOO_HT.DataBind();
				}
				else
				{
					VideoButton video = new VideoButton(uwgOO_HT,"OutSideOrderPC", Volum.Value);
					uwgOO_HT.DataSource = video.FindVolum();
				}
				this.uwgOO_HT.DataBind();				
			}			
		}
		
		
		/// <summary>
		/// ��ҹ�ư Ŭ��
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnCalcel_Click(object sender, System.EventArgs e)
		{

			if(this.uwgOO_HT.Rows.Count ==0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('����� ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				uwgOO_HT.DisplayLayout.Pager.AllowPaging = false;
				VideoButton aa = new VideoButton(uwgOO_HT,"OutSideOrderPC", Volum.Value);
				uwgOO_HT.DataSource = aa.FindVolum();
				uwgOO_HT.DataBind();
				// ��Ұ�ü ����
				KIT_ERP.Cancel cancle = new KIT_ERP.Cancel(uwgOO_HT, "OutSideOrderPC", Volum.Value);
				cancle.MainRowCancel();
				Volnum();
				uwgOO_HT.DisplayLayout.Pager.AllowPaging = true;
				VideoButton video = new VideoButton(uwgOO_HT,"OutSideOrderPC", Volum.Value);
				uwgOO_HT.DataSource = video.FindVolum();
				uwgOO_HT.DataBind();
					
			}
		}
		

		
		/// <summary>
		/// �ߴܹ�ư Ŭ��
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnStop_Click(object sender, System.EventArgs e)
		{
			if(this.uwgOO_HT.Rows.Count ==0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('�ߴ��� ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				KIT_ERP.Stop stop = new KIT_ERP.Stop(uwgOO_HT, "OutSideOrderPC",Session["ID"].ToString());
				stop.MainTableStop();
				
				if(Division == 0)
				{
					this.uwgOO_HT.DataSource = Search();
					this.uwgOO_HT.DataBind();
				}
				else
				{
					VideoButton video = new VideoButton(uwgOO_HT,"OutSideOrderPC", Volum.Value);
					uwgOO_HT.DataSource = video.FindVolum();
				}
				uwgOO_HT.DataBind();			
			}			
		}

		//���������� ��ư
		private void btnExcel_Click(object sender, System.EventArgs e)
		{

			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgOO_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;

			if(Division == 0)
			{
				this.uwgOO_HT.DataSource = Search();
				this.uwgOO_HT.DataBind();
			}
			else
			{
				VideoButton vol = new VideoButton(uwgOO_HT,"OutSideOrderPC",Volum.Value);
				uwgOO_HT.DataSource = vol.FindVolum();
			}

			uwgExcelImport.DataBind();
			uwgExcel.Export(uwgExcelImport);
		}

			

		//Paging ���
		private void uwgOO_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgOO_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			this.uwgOO_HT.DataSource = Search();
			this.uwgOO_HT.DataBind();
			
		}


		/// <summary>
		/// ������ȣ ã�� �Լ�
		/// </summary>
		/// <returns></returns>
		private void Volnum()
		{
			///////////////////////////////////////
			// ������ư�� ����
			// Volum�� ������ȣ �ְ����� �־�д�.
			//////////////////////////////////////
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();	
			string str_Vol = "Select Max(VolumNum) From OO_HT";
			SqlCommand comm_Vol = new SqlCommand(str_Vol,conn);
			if(!Convert.IsDBNull(comm_Vol.ExecuteScalar()))
				Volum.Value = Convert.ToString(comm_Vol.ExecuteScalar());
			else
				Volum.Value = "0";
			conn.Close();

			if(Volum.Value == "0")
			{
				btnNext.Enabled = false;
				btnPre.Enabled = false;
			}
		}

		/// <summary>
		/// ������ư Ŭ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnPre_Click(object sender, System.EventArgs e)
		{
			uwgOO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancel.Enabled = true;
			vol_Pre();

			VideoButton vol = new VideoButton(uwgOO_HT,"OutSideOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgOO_HT.DataSource = ds;
			uwgOO_HT.DataBind();
			Division = 1;
		}


		/// <summary>
		/// ��� ������ư
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNow_Click(object sender, System.EventArgs e)
		{
			uwgOO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancel.Enabled = true;
			vol_Now();
			VideoButton vol = new VideoButton(uwgOO_HT,"OutSideOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgOO_HT.DataSource = ds;
			uwgOO_HT.DataBind();
			Volnum();
			Division = 1;
		}

		/// <summary>
		/// ������ư Ŭ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNext_Click(object sender, System.EventArgs e)
		{
			uwgOO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancel.Enabled = true;
			vol_Next();
			
			VideoButton vol = new VideoButton(uwgOO_HT,"OutSideOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgOO_HT.DataSource = ds;
			uwgOO_HT.DataBind();
			Division = 1;
		}


		/// <summary>
		/// ������Ǿ��ȣ ã�� �Լ�
		/// </summary>
		private void vol_Pre()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Max(VolumNum) as VolumNum From OO_HT where VolumNum < @num";
			comm.Parameters.Add("@num",SqlDbType.Int).Value = int.Parse(Volum.Value);
							
			if(comm.ExecuteScalar() != Convert.DBNull)
			{
				SqlDataReader dr = comm.ExecuteReader();
				if(dr.Read())
					Volum.Value = dr["VolumNum"].ToString();
			}
			else
			{
				RegisterStartupScript("","<script>alert('�� ó���Դϴ�!')</script>");
				btnPre.Enabled = false;
				btnNext.Enabled = true;
			}
			
			conn.Close();	
			
			
		}

		/// <summary>
		/// ���� ������ȣ ã�� �Լ�
		/// </summary>
		private void vol_Now()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Max(VolumNum) as VolumNum From OO_HT";
							
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
				Volum.Value = dr["VolumNum"].ToString();
			dr.Close();

			if(Volum.Value == "")
			{
				RegisterStartupScript("","<script>alert('������ȣ�� �����ϴ�!')</script>");
				Volum.Value = "0";
				btnCancel.Enabled = false;
				btnPre.Enabled = false;
				btnNext.Enabled = false;
			}
			else
			{			
				btnPre.Enabled = true;
				btnNext.Enabled = true;
			}
			conn.Close();
		}

		/// <summary>
		/// ���ĺ�����ȣ ã�� �Լ�
		/// </summary>
		private void vol_Next()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Min(VolumNum) as VolumNum From OO_HT where VolumNum > @num";
			comm.Parameters.Add("@num",SqlDbType.Int).Value = int.Parse(Volum.Value);
							
			if(comm.ExecuteScalar() != Convert.DBNull)
			{
				SqlDataReader dr = comm.ExecuteReader();
				if(dr.Read())
					Volum.Value = dr["VolumNum"].ToString();
			}
			else
			{
				RegisterStartupScript("","<script>alert('�� ���Դϴ�!');</script>");
				btnPre.Enabled = true;
				btnNext.Enabled = false;
			}
			
			conn.Close();	
			
		}





	
		//Row Template ���� ������ �ϰ� ������ư�� ������ LinkButton�� ��������ó��.....�����Ѵ�.
		private void linkUpdate_Click(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			
			try
			{			
				OO_HT_Update(conn,tr); //���ֿ��� �����ϴ� �Լ�
				
				tr.Commit();
				Response.Write("<script language=javascript>");
				Response.Write("alert('�����Ǿ����ϴ�!');");
				Response.Write("</script>");
			}
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();
			}
		}

		//���Ź��ֿ��� �����ϴ� �Լ�
		private void OO_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			//���� ���Ź��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
			int rowcount = int.Parse(hdRowIndex.Value);

			string str =" UPDATE OO_HT SET " +
				" FirstDeliveryDemandQuantity = @firstorderquantity,FirstDeliveryDemandDate=@firstdate,"+
				" SecondDeliveryDemandQuantity=@secondorderquantity ,SecondDeliveryDemandDate=@seconddate, " +
				" ThirdDeliveryDemandQuantity=@thirdorderquantity ,ThirdDeliveryDemandDate=@thirddate, " +
				" FourthDeliveryDemandQuantity=@fourthorderquantity ,FourthDeliveryDemandDate=@fourthdate, " +
				" FifthDeliveryDemandQuantity=@fifthorderquantity ,FifthDeliveryDemandDate=@fifthdate, " +
				" ApplyUnitCost = @applyunitcost,TotalCost = @totalcost, " +
				" OrderQuantity = @orderquantity, RemainQuantity = @requantity, "+
				" UpdatingPerson = @person,"+
				" UpdatingPersonID = @personid, "+
				" UpdatingDate = @date WHERE OutSideOrderHistoryIndex= @INDEX ";
		
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@firstorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FirstDeliveryDemandQuantity").Value.ToString());
			comm.Parameters.Add("@firstdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FirstDeliveryDemandDate").Value.ToString());
			comm.Parameters.Add("@secondorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandQuantity").Value.ToString());
						
			if(uwgOO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value == null || uwgOO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@seconddate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
				comm.Parameters.Add("@seconddate", SqlDbType.DateTime).Value = DateTime.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			
			comm.Parameters.Add("@thirdorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandQuantity").Value.ToString());
			
			if(uwgOO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value == null || uwgOO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@thirddate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
				comm.Parameters.Add("@thirddate", SqlDbType.DateTime).Value = DateTime.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			comm.Parameters.Add("@fourthorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandQuantity").Value.ToString());
						
			if(uwgOO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value == null || uwgOO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@fourthdate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
				comm.Parameters.Add("@fourthdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
		
			comm.Parameters.Add("@fifthorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandQuantity").Value.ToString());
			
			if(uwgOO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value == null || uwgOO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@fifthdate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
				comm.Parameters.Add("@fifthdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			comm.Parameters.Add("@applyunitcost", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm.Parameters.Add("@totalcost", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("TotalCost").Value.ToString());
			
			comm.Parameters.Add("@orderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("OrderQuantity").Value.ToString());
			comm.Parameters.Add("@requantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("OrderQuantity").Value.ToString());
		
			comm.Parameters.Add("@person", SqlDbType.VarChar).Value = Session["UserName"].ToString();
			comm.Parameters.Add("@personid", SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm.Parameters.Add("@date", SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();

			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOO_HT.Rows[rowcount].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());
						
			comm.ExecuteNonQuery();	
		}

		//�Ϸ��ư Ŭ��
		private void btEnd_Click(object sender, System.EventArgs e)
		{
			if ( this.SelectedRow_IsEnd() )
			{
				bool bRowRegist = false;
			
			
				for( int i = 0 ; i < uwgOO_HT.Rows.Count ; i ++)
				{
					if (Convert.ToBoolean( uwgOO_HT.Rows[i].Cells.FromKey("chk").Value ))
					{
						int index = int.Parse(uwgOO_HT.Rows[i].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());		// �����ε���
					
						DB_End( index ) ;
					

						bRowRegist = true;
					}
				}
				if ( bRowRegist )
				{
					Response.Write("<script>alert('�Ϸ� �Ǿ����ϴ�.')</script>");
					this.uwgOO_HT.DataSource = Search();
					this.uwgOO_HT.DataBind();
				}
				else
					Response.Write("<script>alert('���õ� ǰ���� �����ϴ�.')</script>");
			}
			else
			{
				Response.Write("<script>alert('���� �׸�� �� ������°� �Ϸ��Ҽ� ���� �׸��� �ֽ��ϴ�!')</script>");
			}
		}

		/// <summary>
		/// �Ϸ��Ҽ� �ִ� �׸��� �ִ��� �ľ��ϴ� �Լ�
		/// </summary>
		/// <returns>üũ�� �׸�� �߿� ������°� �ߴܵǾ��ų� �Ϸ�Ȱ��� �Ϸ��� �� ����. �׷��Ƿ� false�� �����Ѵ�</returns>
		private bool SelectedRow_IsEnd()
		{
			bool bReturnValue = true;

			for( int i = 0 ; i < uwgOO_HT.Rows.Count ; i ++)
			{
				if (Convert.ToBoolean( uwgOO_HT.Rows[i].Cells.FromKey("chk").Value ) 
					&& (uwgOO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() == "�ߴ�" || uwgOO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() == "�Ϸ�"))
				{
					bReturnValue = false;
					break;
				}
			}
			return bReturnValue;
		}

		/// <summary>
		/// DB�� ������¸� �Ϸ����� ������Ų��
		/// </summary>
		/// <param name="idx"></param>
		private void DB_End(int idx)
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = con;
			try
			{
				con.Open();
				
				string str = "Update OO_HT Set ProgressCondition = '�Ϸ�', UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where OutSideOrderHistoryIndex = @OutSideOrderHistoryIndex";
				
				cmd.Transaction = con.BeginTransaction();
				cmd.CommandText = str;
				cmd.Parameters.Add("@OutSideOrderHistoryIndex", idx);
				cmd.Parameters.Add("@Person", Session["UserName"].ToString());
				cmd.Parameters.Add("@PersonID", Session["ID"].ToString());
				cmd.Parameters.Add("@date", DateTime.Now.ToShortDateString());
				cmd.ExecuteNonQuery();
				cmd.Transaction.Commit();
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				cmd.Transaction.Rollback();
			}
			finally
			{
				con.Close();
			}
		}

		private void btEndCancel_Click(object sender, System.EventArgs e)
		{
			if ( this.SelectedRow_IsEndCancle() )
			{
				bool bRowRegist = false;
			
			
				for( int i = 0 ; i < uwgOO_HT.Rows.Count ; i ++)
				{
					if (Convert.ToBoolean( uwgOO_HT.Rows[i].Cells.FromKey("chk").Value ))
					{
						int index = int.Parse(uwgOO_HT.Rows[i].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());		// �����ε���
					
						DB_EndCancle( index ) ;
					

						bRowRegist = true;
					}
				}
				if ( bRowRegist )
				{
					Response.Write("<script>alert('�Ϸ���� �Ǿ����ϴ�.')</script>");
			
					this.uwgOO_HT.DataSource = Search();
					this.uwgOO_HT.DataBind();
				}
				else
					Response.Write("<script>alert('���õ� ǰ���� �����ϴ�.')</script>");
			}
			else
			{
				Response.Write("<script>alert('���� �׸�� �� ������°� �Ϸᰡ �ƴ� �׸��� �־� ����� �� �����ϴ�!')</script>");
			}
		}


		/// <summary>
		/// �Ϸ�����Ҽ� �ִ� �׸��� �ִ��� �ľ��ϴ� �Լ�
		/// </summary>
		/// <returns>üũ�� �׸�� �߿� ������°� �Ϸ�Ȱ���̿ܿ��� ����� �� ����. �׷��Ƿ� false�� �����Ѵ�</returns>
		private bool SelectedRow_IsEndCancle()
		{
			bool bReturnValue = true;

			for( int i = 0 ; i < uwgOO_HT.Rows.Count ; i ++)
			{
				if (Convert.ToBoolean( uwgOO_HT.Rows[i].Cells.FromKey("chk").Value) == true 
					&& uwgOO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() != "�Ϸ�")
				{
					bReturnValue = false;
					break;
				}
			}
			return bReturnValue;
		}

		/// <summary>
		/// DB�� ������¸� ����Ǵ� ���÷� �����Ų��
		/// </summary>
		/// <param name="idx"></param>
		private void DB_EndCancle(int idx)
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			decimal order = 0;
			decimal remain = 0;
			string str  = @"select OrderQuantity,RemainQuantity From OO_HT Where OutSideOrderHistoryIndex = @OutSideOrderHistoryIndex ";
			SqlCommand cmd = new SqlCommand();
			cmd.CommandText = str;
			cmd.Connection = con;
			con.Open();
			cmd.Parameters.Add("@OutSideOrderHistoryIndex", idx);
			SqlDataReader dr = cmd.ExecuteReader();
			while(dr.Read())
			{
				order = decimal.Parse(dr["OrderQuantity"].ToString());
				remain = decimal.Parse(dr["RemainQuantity"].ToString());
			}
			con.Close();

			if(order - remain == 0 || order - (order - remain) < 0 )
				str = "Update OO_HT Set ProgressCondition = '���',UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where OutSideOrderHistoryIndex = @OutSideOrderHistoryIndex ";
			else
				str = "Update OO_HT Set ProgressCondition = '����',UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where OutSideOrderHistoryIndex = @OutSideOrderHistoryIndex";
			
			try
			{
				con.Open();
				cmd.Transaction = con.BeginTransaction();
				cmd.CommandText = str;
				cmd.Parameters.Add("@Person", Session["UserName"].ToString());
				cmd.Parameters.Add("@PersonID", Session["ID"].ToString());
				cmd.Parameters.Add("@date", DateTime.Now.ToShortDateString());
				cmd.ExecuteNonQuery();
				cmd.Parameters.Clear();
				cmd.Transaction.Commit();
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				cmd.Transaction.Rollback();
			}
			finally
			{
				con.Close();
			}
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = uwgOO_HT;
			bool check = true;
			for(int count = uwgOO_HT.Rows.Count-1 ; count >=0 ; count--)
			{
				if(UWG.Rows[count].Cells.FromKey("chk").Value == null || UWG.Rows[count].Cells.FromKey("chk").Value.ToString() == "false")
					UWG.Rows[count].Delete();
			}

			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count >= 11)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
					
				Session["Grid"] = UWG;
				RegisterStartupScript("","<script>window.open('./Popup/PurchaseOrder.aspx','','width=1050,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
			}
			else
			{
				this.uwgOO_HT.DataSource = Search();
				this.uwgOO_HT.DataBind();
			}
		}

	


	}
}
