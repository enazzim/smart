using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// SubBuyingDelivery�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SubBuyingDelivery : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcEndDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.TextBox txtItemNum;
		protected System.Web.UI.WebControls.TextBox txtItemName;
		protected System.Web.UI.WebControls.TextBox txtDeliveryQuantity;
		protected System.Web.UI.WebControls.TextBox txtCost;
		protected System.Web.UI.WebControls.TextBox txtOrderQuantity;
		protected System.Web.UI.WebControls.TextBox txtCashQuantity;
		protected System.Web.UI.WebControls.TextBox txtRemainQuantity;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcDeliveryDate;
		protected System.Web.UI.WebControls.Button btnRegistration;
		protected System.Web.UI.HtmlControls.HtmlInputHidden IndexNum;
		protected System.Web.UI.HtmlControls.HtmlInputHidden HistoryIndex;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden UnitCost;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.WebControls.DropDownList ddlYear;
		protected System.Web.UI.WebControls.DropDownList ddlMon;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdItemDrawNum;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			ItemSearchControl1.SubMaterials = true; //������ ���ε�
			ItemSearchControl1.Expendable = true;// �Ҹ�ǰ
			CSC1.UnitCostDistinction = "���Űŷ�ó";

			

			//�� ó�� �������� �ε�ɶ�....
			if(!Page.IsPostBack)
			{	
				txtDeliveryQuantity.Attributes.Add("OnKeyUp", "return Process()");
				wdcDeliveryDate.NullDateLabel = DateTime.Now.ToShortDateString();


				foreach(ListItem list in ddlYear.Items)
				{
					if(list.Value == DateTime.Now.Year.ToString())
					{
						list.Selected = true;
					}
				}

				for(int a = 0; a < ddlMon.Items.Count; a++)
				{
					if(DateTime.Now.Month == 12)
					{
						if(DateTime.Now.Day > 25)
						{
							for(int b = 0; b< ddlYear.Items.Count;b++)
							{
								ddlYear.Items[b].Selected = false;
								if(int.Parse(ddlYear.Items[b].Value) == DateTime.Now.Year + 1)
									ddlYear.Items[b].Selected = true;
							}
							ddlMon.Items[0].Selected = true;							
							break;
						}
						else
						{
							ddlMon.Items[DateTime.Now.Month-1].Selected = true;
							break;
						}
					}
					else
					{
						if(ddlMon.Items[a].Value == DateTime.Now.Month.ToString() )
						{
							if(DateTime.Now.Day > 25)
								ddlMon.Items[a+1].Selected = true;
							else
								ddlMon.Items[a].Selected = true;
							break;
						}
					}
				}

				
			}	
			
			
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.UltraWebGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.UltraWebGrid1_PageIndexChanged);
			this.btnRegistration.Click += new System.EventHandler(this.btnRegistration_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		//�������̵�
		private void UltraWebGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			UltraWebGrid1.DataSource =  Search();
			UltraWebGrid1.DataBind();
		}

		//�˻���ư
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			//�˻���ư�� ������ �˻����ǿ� �ش��ϴ� ������ �׸��忡 �ѷ���
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.UltraWebGrid1.DataSource = Search();
			this.UltraWebGrid1.DataBind();	


			this.TextBox_Reset();
			//this.txtDeliveryQuantity.Text = "0";//�˻� ��ư ���������� ��ǰ���� �ؽ�Ʈ�ڽ� �ʱ�ȭ
			this.btnRegistration.Enabled = true; //�˻��� �ٷ� �ϰ��� ��Ϲ�ư�� ��Ȱ��ȭ
		}

		//��Ϲ�ư
		private void btnRegistration_Click(object sender, System.EventArgs e)
		{
			if(HistoryIndex.Value.Trim() =="")
			{
				Response.Write("<script language='javascript'>");
				Response.Write("alert('ǰ���� �����ϼ���');");
				Response.Write("</script>");

			}
			else if(this.txtDeliveryQuantity.Text == "0" || this.txtDeliveryQuantity.Text.Trim() == "")
			{
				Response.Write("<script language='javascript'>");
				Response.Write("alert('��ǰ������ �Էµ��� �ʾҽ��ϴ�. �Է����ּ���');");
				Response.Write("</script>");
			}
			else
			{

				
				
				ArrayList BD_HTArraylist = new ArrayList();
				BD_HTArraylist.Add(int.Parse(IndexNum.Value));//�ش�����ȣ
				BD_HTArraylist.Add(decimal.Parse(txtDeliveryQuantity.Text));//��ǰ����
				
				
				//��ǰ���� �Է����� ������ ����� ��¥�� �ڵ� �Էµȴ�.
				if(this.wdcDeliveryDate.Value == null || wdcDeliveryDate.Text.Trim() == "")
				{
					BD_HTArraylist.Add(DateTime.Now.ToShortDateString());//�԰���
				}
				else
				{
					BD_HTArraylist.Add(DateTime.Parse(wdcDeliveryDate.Text));//�԰���
				}		
		
				BD_HTArraylist.Add(decimal.Parse(txtCost.Text));//�ܰ�
				BD_HTArraylist.Add(ddlYear.SelectedItem.Value);	//���Գ�
				BD_HTArraylist.Add(ddlMon.SelectedItem.Value);	//���Կ�
				BD_HTArraylist.Add(decimal.Parse(UnitCost.Value));//ǥ�شܰ�




				if(MonthClosing())
				{
				
					KIT_ERP.Register register = new KIT_ERP.Register(BD_HTArraylist,"SubBuyingDelivery",Session["ID"].ToString());
					register.Registration();
				}
				else
				{
					RegisterStartupScript("","<script>alert('�������� �Ǿ� �԰��� �Ұ��� �մϴ�!');</script>");
				}
					
				

				this.UltraWebGrid1.DataSource = Search();
				this.UltraWebGrid1.DataBind();	

				this.TextBox_Reset();
				
			}
		}

		/// <summary>
		/// ������ �ʱ�ȭ
		/// </summary>
		private void TextBox_Reset()
		{
			txtItemName.Text = "";
			txtItemNum.Text = "";
			hdItemDrawNum.Value = "";
			txtCashQuantity.Text  ="0";
			txtDeliveryQuantity.Text = "";
			txtOrderQuantity.Text = "";
			txtRemainQuantity.Text = "";
			txtCost.Text = "0";
			wdcDeliveryDate.Value = null;
		}

	

		//�˻��Լ�
		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() =="")
				search = new KIT_ERP.Search("SubBuyingDelivery",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,  wcStartDate, wcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			else
				search = new KIT_ERP.Search("SubBuyingDelivery",ItemSearchControl1.ItemNum,"", "",  wcStartDate, wcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			return search.DataSet_search();
		}

		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			if(year < int.Parse(ddlYear.SelectedItem.Value))
			{
				return true;
			}
			else if(year == int.Parse(ddlYear.SelectedItem.Value))
			{
				if(month < int.Parse(ddlMon.SelectedItem.Value))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		

			
		}
	}
}
