using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;


namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// SubBuyingDeliveryPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SubBuyingDeliveryPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgSBD_HT;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected System.Web.UI.WebControls.Literal Literal1;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdmon;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdyear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldCost;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdReason;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldMonth;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdquantity;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected System.Web.UI.WebControls.DropDownList ddlProperty;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			Literal1.Text = "";
			ItemSearchControl1.SubMaterials = true; //������ ���ε�
			ItemSearchControl1.Expendable = true;// �Ҹ�ǰ
			CSC1.UnitCostDistinction = "���Űŷ�ó";

			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			if(!Page.IsPostBack)
			{

				//��ҹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnCancel.Attributes.Add("onClick","return Confirm('������ ǰ��鿡 ���Ͽ� �԰��� ����Ͻðڽ��ϱ�?');");

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
			}	
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.uwgSBD_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgSBD_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgSBD_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgSBD_HT.DataSource = Search();

			this.uwgSBD_HT.DataBind();

			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			Literal1.Text += "�� �ݾ� : <b>\"";
			Literal1.Text += String.Format("{0:#,###}",TotalCost);
			Literal1.Text += "\"</b> ��" ;
		}

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() =="")
				search = new KIT_ERP.Search("SubBuyingDeliveryPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,wdcStartDate, ddlItemClassification1.SelectedItem.Value, wdcEndDate, CSC1.Company, CSC1.BusinessRegistrationNum, ddlProperty);
			else
				search = new KIT_ERP.Search("SubBuyingDeliveryPC",ItemSearchControl1.ItemNum, "", "",wdcStartDate, ddlItemClassification1.SelectedItem.Value, wdcEndDate, CSC1.Company, CSC1.BusinessRegistrationNum,ddlProperty);

			return search.DataSet_search();
		}

		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgSBD_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;


			this.uwgSBD_HT.DataSource = Search();
			this.uwgSBD_HT.DataBind();

			uwgExcel.Export(uwgSBD_HT);	
	
			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			KIT_ERP.Delete cancel = new Delete(uwgSBD_HT,"SubBuyingDeliveryPC",Session["UserName"].ToString(),Session["ID"].ToString());
			cancel.MainRowDelete();

			//������ư�� ���� �����͸� ������ �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgSBD_HT.DataSource = Search();
			this.uwgSBD_HT.DataBind();



			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
			
		}

		private void linkUpdate_Click(object sender, System.EventArgs e)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			
			try
			{
				if(MonthClosing())
				{
				
					SBD_HT_Update(conn,tr);//�������԰����� �����ϴ� �Լ� ȣ��
					SBO_HT_Update(conn,tr);//��������ֿ��� �����ϴ� �Լ� ȣ��
					SBSI_MT_Update(conn,tr);//���Ը������̺� �����ϴ� �Լ� ȣ��
					BOS_HTComUpdate(conn,tr);//�����籸���̷¿��� ���� �� �ܰ� ���� ������ �Լ� ȣ��

					tr.Commit();
					Response.Write("<script language=javascript>");
					Response.Write("alert('�����Ǿ����ϴ�!');");
					Response.Write("</script>");				
				}
				else
				{
					throw new Exception("�������� �Ǿ� ������ �Ұ��� �մϴ�!");
				}
			}				
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();

				this.uwgSBD_HT.DataSource = Search();
				this.uwgSBD_HT.DataBind();

				DataSet ds = new DataSet();
				ds = Search();

				decimal TotalCost = 0;
				foreach(DataRow dr in ds.Tables[0].Rows)
				{
					TotalCost += decimal.Parse(dr["TotalCost"].ToString());
				}

				
				//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
				Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
				
			}
		}

		private void uwgSBD_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgSBD_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			this.uwgSBD_HT.DataSource = Search();
			uwgSBD_HT.DataBind();
		}


		/// <summary>
		/// �����籸���԰����� ����
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void SBD_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			
			//���� ǰ���˻���忡�� ��ǰ������ ����
			string str1 =" UPDATE SBD_HT SET [Year] = @year, [Month] = @mon,DeliveryQuantity = @quantity , DeliveryDate = @DeliveryDate,  ApplyUnitCost = @cost, TotalCost = @totalcost,UpdatingPerson = @person, UpdatingPersonID = @id, UpdatingDate = @date WHERE SubBuyingDeliveryHistoryIndex= @INDEX";
			SqlCommand comm1 = new SqlCommand(str1,con);
			comm1.Transaction = trans;
			
			comm1.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@DeliveryDate",DateTime.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).ToShortDateString());
			comm1.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm1.Parameters.Add("@totalcost", SqlDbType.Decimal).Value = decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()) * decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("SubBuyingDeliveryHistoryIndex").Value.ToString());
			comm1.Parameters.Add("@person",SqlDbType.VarChar).Value = Session["UserName"].ToString();
			comm1.Parameters.Add("@id",SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm1.Parameters.Add("@date",SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();
			comm1.Parameters.Add("@year",SqlDbType.Int).Value = int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
			comm1.Parameters.Add("@mon",SqlDbType.Int).Value = int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
			comm1.ExecuteNonQuery();
		}

		
		/// <summary>
		/// ������ ���Ź��ֿ��� �����ϴ� �Լ�
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void SBO_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			//���� ���Ź��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
			int rowcount = int.Parse(hdRowIndex.Value);
			int index= int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("SubBuyingOrderHistoryIndex").Value.ToString());
			
			string str1 = "select DeliveryRemainQuantity from SBO_HT where SubBuyingOrderHistoryIndex= @INDEX";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;			
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
			comm.CommandText = str1;
			decimal requantity = decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			string str =" UPDATE SBO_HT SET DeliveryRemainQuantity = @requantity WHERE SubBuyingOrderHistoryIndex= @INDEX";
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@requantity", SqlDbType.Decimal).Value = requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
			comm.CommandText = str;
			comm.ExecuteNonQuery();	
			comm.Parameters.Clear();
			
			//�����ܷ��� + ������ǰ�� - �����ĳ�ǰ��
			if(requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())) == 0)
			{				
				str =" UPDATE SBO_HT SET ProgressCondition = @progress WHERE SubBuyingOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "�Ϸ�";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}
			else
			{			
				str =" UPDATE SBO_HT SET ProgressCondition = @progress WHERE SubBuyingOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "����";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}
		}


		/// <summary>
		/// ������ ���Աݾ� ���� �Լ�
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void SBSI_MT_Update(SqlConnection con,SqlTransaction trans)
		{
			//�������̺����� ������ǰ���� ���̳ʽ� ����
			int rowcount = int.Parse(hdRowIndex.Value);
			int year = int.Parse(hdyear.Value);
			int mon = int.Parse(hdmon.Value);

			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgSBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(decimal.Parse(hdOldCost.Value));
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			year = int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
			mon = int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
			Table table1 = new Table(year,mon);
			//���κ���Ǵ� ��ǰ�� ����
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgSBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()))*(decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));// ��ǰ�ݾ�
			comm.Parameters.Add("@year",year);
			comm.CommandText = table1.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		/// <summary>
		/// ������ �԰��̷¿��� ����
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void BOS_HTComUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,CompanyName, BusinessRegistrationNum,ProcessCode, ProcessName, Quantity,UnitCost,UpdateHistoryReason, [Date],UpdatePerson, UpdatePersonID,HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,@CompanyName,@BusinessRegistrationNum,'', '', @Quantity,@UnitCost,@UpdateHistoryReason, @Date,@Person, @PersonID,'�����籸���԰�',@HistoryIndex)";
				
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			
			comm.Parameters.Add("@itemnum", uwgSBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text);	//ǰ���ȣ
			comm.Parameters.Add("@itemdrawnum", uwgSBD_HT.Rows[rowcount].Cells.FromKey("ItemDrawNum").Text);								//�����ȣ
			comm.Parameters.Add("@itemname",uwgSBD_HT.Rows[rowcount].Cells.FromKey("ItemName").Text);									//ǰ���
			comm.Parameters.Add("@CompanyName",uwgSBD_HT.Rows[rowcount].Cells.FromKey("CompanyName").Text);								//��ü��
			comm.Parameters.Add("@BusinessRegistrationNum",uwgSBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Text);
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UnitCost",decimal.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UpdateHistoryReason",hdReason.Value.Trim());												//������
			comm.Parameters.Add("@Date", DateTime.Now.ToShortDateString());//�����������
			comm.Parameters.Add("@Person",Session["UserName"].ToString());
			comm.Parameters.Add("@PersonID", Session["ID"].ToString());	
			comm.Parameters.Add("@HistoryIndex",int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("SubBuyingDeliveryHistoryIndex").Text));												//�����ȣ

			comm.ExecuteNonQuery();
		}

		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			if(year < int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Year").Text))
			{
				return true;
			}
			else if(year == int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Year").Text)) 
			{
				if(month < int.Parse(uwgSBD_HT.Rows[rowcount].Cells.FromKey("Year").Text))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}	
			

			
		}
	}
}
