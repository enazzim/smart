using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// BuyingDeliveryPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BuyingDeliveryPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter UltraWebGridExcelExporter1;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdquantity;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgBD_HT;
		protected System.Web.UI.WebControls.Button btnStop;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Literal Literal1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldMonth;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdReason;
		
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldCost;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdmon;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdyear;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
			
		private void Page_Load(object sender, System.EventArgs e)
		{
			Literal1.Text = "";
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}


			//ǰ������ �ʱ�ȭ
			//btnInit.Attributes.Add("onClick","ResetTextBox()");

			ItemSearchControl1.RawMaterials = true; //������ ���ε�
			ItemSearchControl1.Commodity = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction = "���Űŷ�ó";

			if(!Page.IsPostBack)
			{

				// �ߴܹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnStop.Attributes.Add("onClick", "return Confirm('������ ǰ����� ���Ͽ� ��ǰ�� �ߴ��Ͻðڽ��ϱ�?');");
				//��ҹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnCancel.Attributes.Add("onClick","return Confirm('������ ǰ��鿡 ���Ͽ� ��ǰ�� ����Ͻðڽ��ϱ�?');");

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
			}	
		
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.uwgBD_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgBD_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		//�˻���ư Ŭ��
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgBD_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgBD_HT.DataSource = Search();

			this.uwgBD_HT.DataBind();

			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			Literal1.Text += "�� �ݾ� : <b>\"";
			Literal1.Text += String.Format("{0:#,###}",TotalCost);
			Literal1.Text += "\"</b> ��" ;
		}

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() =="")
                search = new KIT_ERP.Search("BuyingDeliveryPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,wdcStartDate, ddlItemClassification1.SelectedItem.Value, wdcEndDate, CSC1.Company, CSC1.BusinessRegistrationNum);
			else
				search = new KIT_ERP.Search("BuyingDeliveryPC",ItemSearchControl1.ItemNum, "", "",wdcStartDate, ddlItemClassification1.SelectedItem.Value, wdcEndDate, CSC1.Company, CSC1.BusinessRegistrationNum);

			return search.DataSet_search();
		}

		

		//�׸��忡 ���� ��Ÿ�� �׸��� ���� ���Ϸ� �ٿ�ε�
		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgBD_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;


			this.uwgBD_HT.DataSource = Search();
			this.uwgBD_HT.DataBind();

			uwgExcel.Export(uwgBD_HT);	
	
			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
		}

		//������ư Ŭ��
		private void btnStop_Click(object sender, System.EventArgs e)
		{
//			if(MonthClosing())
//			{
//				KIT_ERP.Stop stop = new Stop(uwgBD_HT,"BuyingDeliveryPC",Session["ID"].ToString());
//				stop.MainTableStop();
//
//			}
//			else
//			{
//				RegisterStartupScript("","<script>alert('�������� �Ǿ� �ߴ��� �Ұ��� �մϴ�!');</script>");
//			}
			

			KIT_ERP.Stop stop = new Stop(uwgBD_HT,"BuyingDeliveryPC",Session["ID"].ToString());
			stop.MainTableStop();

			//�ߴܹ�ư�� ���� �����͸� �ߴ��� �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgBD_HT.DataSource = Search();
			this.uwgBD_HT.DataBind();



			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
		}

		//������ư Ŭ��
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
//			if(MonthClosing())
//			{
//				KIT_ERP.Delete cancel = new Delete(uwgBD_HT,"BuyingDeliveryPC",Session["UserName"].ToString(),Session["ID"].ToString());
//				cancel.MainRowDelete();
//
//			}
//			else
//			{
//				RegisterStartupScript("","<script>alert('�������� �Ǿ� ������ �Ұ��� �մϴ�!');</script>");
//			}

			KIT_ERP.Delete cancel = new Delete(uwgBD_HT,"BuyingDeliveryPC",Session["UserName"].ToString(),Session["ID"].ToString());
			cancel.MainRowDelete();
			
			//������ư�� ���� �����͸� ������ �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgBD_HT.DataSource = Search();
			this.uwgBD_HT.DataBind();



			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
			
		}

		//Grid Paging ��� 
		private void uwgBD_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgBD_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			this.uwgBD_HT.DataSource = Search();
			uwgBD_HT.DataBind();
		}

		
		
		//Template Row ���� ������ �ϸ� �ٸ� ���忡�� ���� ����
		private void linkUpdate_Click(object sender, System.EventArgs e)
		{

			if(MonthClosing())
			{
				int rowcount = int.Parse(hdRowIndex.Value);
				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
				conn.Open();
				SqlTransaction tr = conn.BeginTransaction();
			
				try
				{
									
					BD_HT_Update(conn,tr);//��ǰ���� �����ϴ� �Լ� ȣ��(�˻�ǰ��� ���˻�ǰ�� ��� ��ǰ���� ����)

					//�����ϰ��� �ϴ� ǰ���� �˻� ǰ���� ���
					if(Check(conn,tr) == true)
					{	
						if(uwgBD_HT.Rows[rowcount].Cells.FromKey("ProgressCondition").ToString() != "�Ϸ�")
						{
							QI_HT_Update(conn,tr);//ǰ���˻���� �����ϴ� �Լ�ȣ��
							BO_HTWaitingQuantityUpdate(conn,tr);//���Ź��ֿ����� �԰������� ����
						}
						else
							throw new Exception("�̹� ǰ���˻簡 �Ϸ�� �׸��̶� ������ �Ұ��� �մϴ�!");
					}
					
						//�����ϰ��� �ϴ� ǰ���� ���˻� ǰ���� ���			
					else
					{
						BO_HT_Update(conn,tr);//���ֿ��� �����ϴ� �Լ� ȣ��(���˻�ǰ�̸鼭 ��ǰ�� ������ ��� ���ֿ��� ����)

						BSI_MT_Update(conn,tr);//���Ը������̺� �����ϴ� �Լ� ȣ��

						B_HT_Update(conn,tr);//���Կ��� �����ϴ� �Լ� ȣ��

						//�����ϰ��� �ϴ� ǰ���� ���˻�ǰ�̸鼭 �������ΰ��
						if(Division(conn,tr) == 1)
						{	
							NonQI_HT_Update(conn,tr);//���˻�ǰ�� ǰ���˻���� �����ϴ� �Լ�ȣ��	
							NonHistory(conn,tr);		//���˻�ǰ ������ �����Ǵ� �̷¿���
							RMS_MT_Update(conn,tr);//������â�� �����ϴ� �Լ� ȣ��	
							SH_HT_RMS_MTUpdate(conn,tr);	//	���˻� ��������� ����			
							BOS_HTRowUpdate(conn,tr);//�����̷¿��� ���� �� �ܰ� ���� ������ �Լ� ȣ��
						}
							//�����ϰ��� �ϴ� ǰ���� ���˻�ǰ�̸鼭 ��ǰ�ΰ��
						else if(Division(conn,tr) == 4)
						{	
							NonQI_HT_Update(conn,tr);//���˻�ǰ�� ǰ���˻���� �����ϴ� �Լ�ȣ��		
							ISR_HT_Update(conn,tr);//�԰��Ƿڿ��� �����ϴ� �Լ� ȣ��

							PS_MT_Update(conn,tr);//����â�� �����ϴ� �Լ� ȣ��
							SH_HT_PS_MTUpdate(conn,tr);
							BOS_HTComUpdate(conn,tr);//�����̷¿��� ���� �� �ܰ� ���� ������ �Լ� ȣ��
						}
					}			
				
				
					tr.Commit();
					Response.Write("<script language=javascript>");
					Response.Write("alert('�����Ǿ����ϴ�!');");
					Response.Write("</script>");
				}
				catch(Exception ee)
				{
				
					Response.Write("<script language=javascript>");
					Response.Write("alert('"+ee.Message+"');");
					Response.Write("</script>");

					tr.Rollback();
				}
				finally
				{
					conn.Close();

					this.uwgBD_HT.DataSource = Search();
					this.uwgBD_HT.DataBind();

					DataSet ds = new DataSet();
					ds = Search();

					decimal TotalCost = 0;
					foreach(DataRow dr in ds.Tables[0].Rows)
					{
						TotalCost += decimal.Parse(dr["TotalCost"].ToString());
					}

				
					//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
					Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
				
				}
			}
			else
			{
				RegisterStartupScript("","<script>alert('�������� �Ǿ� ������ �Ұ��� �մϴ�!');</script>");

				this.uwgBD_HT.DataSource = Search();
				this.uwgBD_HT.DataBind();

				DataSet ds = new DataSet();
				ds = Search();

				decimal TotalCost = 0;
				foreach(DataRow dr in ds.Tables[0].Rows)
				{
					TotalCost += decimal.Parse(dr["TotalCost"].ToString());
				}

				
				//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
				Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
				
			}
			
		}

		




		
		//�����ϰ��� �ϴ� ǰ���� �˻�ǰ������ ���˻� ǰ������ Check�ϴ� �Լ�
		private bool Check(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string aa = "";
			string str = "Select CheckDistinction From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["CheckDistinction"].ToString();			
			}
			dr.Close();

			if(aa.ToString() == "False")
				return false;
			else
				return true;
		}
		
		//�����ϰ��� �ϴ� ǰ���� ��ǰ���� ���������� �Ǵ��ϴ� �Լ�
		private int Division(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string aa="";

			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value =uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			dr.Close();

			if(aa.ToString() == "������")
				return 1;
			else if(aa.ToString() =="����ǰ")
				return 2;
			else if(aa.ToString() =="��ǰ")
				return 3;
			else if(aa.ToString() =="��ǰ")
				return 4;
			else 
				return 5;
		}

		//ǰ���˻���� �����ϴ� �Լ�
		private void QI_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			//���� ǰ���˻���忡�� ��ǰ������ Update
			int rowcount = int.Parse(hdRowIndex.Value);
			string str =" UPDATE QI_HT SET [Year]=@year, [Month] = @mon, RequestQuantity = @quantity, ApplyUnitCost = @cost, RegistrationDate = @date WHERE HistorySection1= '���ų�ǰ' and HistoryIndex1 = @INDEX";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;		
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm.Parameters.Add("@date", DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("RegistrationDate").Text).ToShortDateString());
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());
			comm.Parameters.Add("@year",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
			comm.Parameters.Add("@mon",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		private void SH_HT_RMS_MTUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str = "Update SH_HT Set Quantity=@Quantity, [Date] = @Date where HistoryDivision='���ų�ǰ' and  HistoryIndex=@index ";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@Date", DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Value.ToString()).ToShortDateString());//�����������
			comm.Parameters.Add("@index",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());//��������ε���
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		private void SH_HT_PS_MTUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str = "Update SH_HT Set Quantity=@Quantity, [Date] = @Date where HistoryDivision='���ų�ǰ' and  HistoryIndex=@index ";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@Date", DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Value.ToString()).ToShortDateString());//�����������
			comm.Parameters.Add("@index",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());//��������ε���
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		private void BOS_HTRowUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason, [Date],UpdatePerson, UpdatePersonID,HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,0,'14000000','����',@CompanyName,@BusinessRegistrationNum,@Quantity,@UnitCost,@UpdateHistoryReason, @Date,@Person, @PersonID,'���ų�ǰ',@HistoryIndex)";
				
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			
			comm.Parameters.Add("@itemnum", uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text);	//ǰ���ȣ
			comm.Parameters.Add("@itemdrawnum", uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemDrawNum").Text);								//�����ȣ
			comm.Parameters.Add("@itemname",uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemName").Text);									//ǰ���
			comm.Parameters.Add("@CompanyName",uwgBD_HT.Rows[rowcount].Cells.FromKey("CompanyName").Text);								//��ü��
			comm.Parameters.Add("@BusinessRegistrationNum",uwgBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Text);
			//comm.Parameters.Add("@ProcessSequenceNum",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessSequenceNum").Text);											//��������
			//comm.Parameters.Add("@ProcessCode",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Text);											//�����ڵ�
			//comm.Parameters.Add("@ProcessName",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessName").Text);												//������
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UnitCost",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UpdateHistoryReason",hdReason.Value.Trim());												//������
			comm.Parameters.Add("@Date", DateTime.Now.ToShortDateString());//�����������
			comm.Parameters.Add("@Person",Session["UserName"].ToString());
			comm.Parameters.Add("@PersonID", Session["ID"].ToString());	
			comm.Parameters.Add("@HistoryIndex",int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Text));												//�����ȣ

			comm.ExecuteNonQuery();
		}

		private void BOS_HTComUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason, [Date],UpdatePerson, UpdatePersonID,HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,99,'14009999','����ǰ',@CompanyName,@BusinessRegistrationNum,@Quantity,@UnitCost,@UpdateHistoryReason, @Date,@Person, @PersonID,'���ų�ǰ',@HistoryIndex)";
				
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			
			comm.Parameters.Add("@itemnum", uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text);	//ǰ���ȣ
			comm.Parameters.Add("@itemdrawnum", uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemDrawNum").Text);								//�����ȣ
			comm.Parameters.Add("@itemname",uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemName").Text);									//ǰ���
			comm.Parameters.Add("@CompanyName",uwgBD_HT.Rows[rowcount].Cells.FromKey("CompanyName").Text);								//��ü��
			comm.Parameters.Add("@BusinessRegistrationNum",uwgBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Text);
			//comm.Parameters.Add("@ProcessSequenceNum",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessSequenceNum").Text);											//��������
			//comm.Parameters.Add("@ProcessCode",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Text);											//�����ڵ�
			//comm.Parameters.Add("@ProcessName",uwgBD_HT.Rows[rowcount].Cells.FromKey("ProcessName").Text);												//������
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UnitCost",decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UpdateHistoryReason",hdReason.Value.Trim());												//������
			comm.Parameters.Add("@Date", DateTime.Now.ToShortDateString());//�����������
			comm.Parameters.Add("@Person",Session["UserName"].ToString());
			comm.Parameters.Add("@PersonID", Session["ID"].ToString());	
			comm.Parameters.Add("@HistoryIndex",int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Text));												//�����ȣ

			comm.ExecuteNonQuery();
		}
		

		/// <summary>
		/// ���Ź��ֿ��� �԰������� ����
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void BO_HTWaitingQuantityUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			decimal quantity = decimal.Parse(hdquantity.Value);

			string str =" UPDATE BO_HT SET InStoreWaitingQuantity = InStoreWaitingQuantity - @InStoreWaitingQuantity WHERE BuyingOrderHistoryIndex = @INDEX";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.CommandText = str;
			comm.Parameters.Add("@InStoreWaitingQuantity", quantity);
			comm.Parameters.Add("@INDEX",int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			str =" UPDATE BO_HT SET InStoreWaitingQuantity = InStoreWaitingQuantity + @InStoreWaitingQuantity WHERE BuyingOrderHistoryIndex = @INDEX";
			comm.CommandText = str;
			comm.Parameters.Add("@InStoreWaitingQuantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}



		//���˻�ǰ�� ǰ���˻���� �����ϴ� �Լ�
		private void NonQI_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;

			int rowcount = int.Parse(hdRowIndex.Value);
						
			int idx = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());
			int idx1 = 0;

			if(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryRequestHistoryIndex").Value == null)
			{
				idx1 = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());
				Non_QI_HTUpdatd(con,trans,idx,idx1,"���Ź���");
			}
			else
			{
				idx1 = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryRequestHistoryIndex").Value.ToString());
				Non_QI_HTUpdatd(con,trans,idx,idx1,"���ų�ǰ�Ƿ�");
			}		
		}


		private void NonHistory(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str=" UPDATE SH_HT SET Quantity = @Quantity, [Date] = @date WHERE HistoryDivision= '���ų�ǰ' and HistoryIndex = @index ";
			SqlCommand comm = new SqlCommand();	
			comm.Connection = con;			
			comm.Transaction = trans;
			comm.Parameters.Add("@date", DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Value.ToString()).ToShortDateString());
			comm.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@index",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());
			comm.CommandText = str;
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();			
		}


		private void Non_QI_HTUpdatd(SqlConnection conn, SqlTransaction tr, int index, int index1, string section)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string Condition="";
			SqlCommand comm = new SqlCommand();			
			string str  = @"Select * From QI_HT WHERE HistorySection1= '���ų�ǰ' and HistoryIndex1 = @index and HistorySection2= @section and HistoryIndex2 = @index1";
			comm.Connection = conn;			
			comm.Transaction = tr;
			comm.Parameters.Add("@index",SqlDbType.Int).Value = index;
			comm.Parameters.Add("@index1",SqlDbType.Int).Value = index1;
			comm.Parameters.Add("@section",SqlDbType.VarChar).Value = section;
			comm.CommandText = str;
			SqlDataAdapter daQI = new SqlDataAdapter(comm);
			DataSet dsQI = new DataSet();
			daQI.Fill(dsQI);
			comm.Parameters.Clear();

			foreach(DataRow dr in dsQI.Tables[0].Rows)
			{
				Condition = dr["ProgressCondition"].ToString();
			}

			if(Condition == "�԰��Ϸ�")
			{
				throw new Exception("�̹� �԰��Ϸ�� ǰ���Դϴ�!");
			}
			else
			{
				//���� ǰ���˻���忡�� ��ǰ������ Update
				str =" UPDATE QI_HT SET [Year] = @year, [Month] = @mon, RequestQuantity = @quantity, SuitabilityQuantity=@quantity,ApplyUnitCost = @cost, QualityInspectionCompleteDate = @QualityInspectionCompleteDate WHERE HistorySection1= '���ų�ǰ' and HistoryIndex1 = @index and HistorySection2= @section and HistoryIndex2 = @index1";
				comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
				comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
				comm.Parameters.Add("@QualityInspectionCompleteDate", DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).ToShortDateString());
				comm.Parameters.Add("@index",SqlDbType.Int).Value = index;
				comm.Parameters.Add("@index1",SqlDbType.Int).Value = index1;
				comm.Parameters.Add("@section",SqlDbType.VarChar).Value = section;
				comm.Parameters.Add("@year",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
				comm.Parameters.Add("@mon",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}


		}

		//���ų�ǰ���� �����ϴ� �Լ�
		private void BD_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			
			//���� ǰ���˻���忡�� ��ǰ������ ����
//			string str1 =" UPDATE BD_HT SET DeliveryQuantity = @quantity , TotalCost = @cost, LotNum = @LotNum, UpdatingPerson = @person, UpdatingPersonID = @id, UpdatingDate = @date WHERE BuyingDeliveryHistoryIndex= @INDEX";
			string str1 =" UPDATE BD_HT SET [Year] = @year, [Month] = @mon,DeliveryQuantity = @quantity , DeliveryDate = @DeliveryDate,  ApplyUnitCost = @cost, TotalCost = @totalcost,UpdatingPerson = @person, UpdatingPersonID = @id, UpdatingDate = @date WHERE BuyingDeliveryHistoryIndex= @INDEX";
			SqlCommand comm1 = new SqlCommand(str1,con);
			comm1.Transaction = trans;
			
		    comm1.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@DeliveryDate",DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).ToShortDateString());
			comm1.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm1.Parameters.Add("@totalcost", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()) * decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			//comm1.Parameters.Add("@LotNum", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("@LotNum").Value.ToString();
			comm1.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());
			comm1.Parameters.Add("@person",SqlDbType.VarChar).Value = Session["UserName"].ToString();
            comm1.Parameters.Add("@id",SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm1.Parameters.Add("@date",SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();
			comm1.Parameters.Add("@year",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
			comm1.Parameters.Add("@mon",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
			comm1.ExecuteNonQuery();
		}

		//���Ź��ֿ��� �����ϴ� �Լ�
		private void BO_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			//���� ���Ź��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
			int rowcount = int.Parse(hdRowIndex.Value);
			int index= int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());
			
			string str1 = "select RemainQuantity from BO_HT where BuyingOrderHistoryIndex= @INDEX";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;			
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
			comm.CommandText = str1;
			decimal requantity = decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			string str =" UPDATE BO_HT SET RemainQuantity = @requantity WHERE BuyingOrderHistoryIndex= @INDEX";
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@requantity", SqlDbType.Decimal).Value = requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
			comm.CommandText = str;
			comm.ExecuteNonQuery();	
			comm.Parameters.Clear();
			
			//�����ܷ��� + ������ǰ�� - �����ĳ�ǰ��
			if(requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())) == 0)
			{				
				str =" UPDATE BO_HT SET ProgressCondition = @progress WHERE BuyingOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "�Ϸ�";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}
			else
			{			
				str =" UPDATE BO_HT SET ProgressCondition = @progress WHERE BuyingOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "����";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}
		}

		//������â�� ���� �����ϴ� �Լ�
		private void RMS_MT_Update(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Text);
			
			//�������̺����� ���������� ���̳ʽ� ����
			int year = int.Parse(hdOldYear.Value);
			int mon = int.Parse(hdOldMonth.Value);
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -decimal.Parse(hdOldCost.Value);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.InRowTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
			mon = DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = unitcost*decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@year",year);
			Table table1 = new Table(year,mon);
			comm.CommandText = table1.InRowTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM RMS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = '14000000' and [Year] = @year";
				comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@year",DateTime.Now.Year);
				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
				comm.Parameters.Clear();
						
				string StockQuantity = "False";
				string ItemName = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ����� �������� ����� �Ұ��� �մϴ�.");
				}
			}
		}

		//���Ը�������� �ݾ� �����ϴ� �Լ�
		private void BSI_MT_Update(SqlConnection con,SqlTransaction trans)
		{
			//�������̺����� ������ǰ���� ���̳ʽ� ����
			int rowcount = int.Parse(hdRowIndex.Value);
			//int year = int.Parse(hdOldYear.Value);
			//int mon = int.Parse(hdOldMonth.Value);
			int year = int.Parse(hdyear.Value);
			int mon = int.Parse(hdmon.Value);

			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(decimal.Parse(hdOldCost.Value));
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			year = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString());
			mon = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString());
			Table table1 = new Table(year,mon);
			//���κ���Ǵ� ��ǰ�� ����
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()))*(decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));// ��ǰ�ݾ�
			comm.Parameters.Add("@year",year);
			comm.CommandText = table1.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		//���Կ����� �ݾװ� ���� �����ϴ� �Լ�
		private void B_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);

			//���� ����Ǵ� ǰ���˻���忡�� ��ǰ������ �ݾ��� Update
			string str1 =" UPDATE B_HT SET BuyingQuantity = @quantity,TotalCost = @cost WHERE HistorySection= '���ų�ǰ' and HistoryIndex = @INDEX";
			SqlCommand comm1 = new SqlCommand(str1,con);
			comm1.Transaction = trans;
			comm1.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@cost", SqlDbType.Decimal).Value = ((decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()))*(decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString())));
			comm1.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("BuyingDeliveryHistoryIndex").Value.ToString());
			comm1.ExecuteNonQuery();
		}

		//����â���� ������ �����ϴ� �Լ�
		private void PS_MT_Update(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Text);
			
			//�������̺����� ���������� ���̳ʽ� ����
		
			int year = int.Parse(hdOldYear.Value);
			int mon = int.Parse(hdOldMonth.Value);
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = -decimal.Parse(hdOldCost.Value);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = "14009999";
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			
			comm.CommandText = table.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			Table table1 = new Table(DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year, DateTime.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month);
			//���κ���Ǵ� ������ ������ ����
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = unitcost*decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = "14009999";
			comm.Parameters.Add("@year",year);

			comm.CommandText = table1.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM PS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = '14009999' and [Year] = @year";
				comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@year",DateTime.Now.Year);
				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
				comm.Parameters.Clear();
						
				string StockQuantity = "False";
				string ItemName = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ����� �������� ����� �Ұ��� �մϴ�.");
				}
			}


		}


		//�԰��Ƿڿ����� ������ �����ϴ� �Լ�
		private void ISR_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			//���� ǰ���˻���忡�� ��ǰ������ �ݾ��� Update
			int rowcount = int.Parse(hdRowIndex.Value);

			string str =" UPDATE ISR_HT SET InstorehouseRequestQuantity = @quantity WHERE ItemNum = @num";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;		
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value = uwgBD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			
			comm.ExecuteNonQuery();
		}


		/// <summary>
		/// ���̳ʽ� ��� ��뿩��
		/// </summary>
		/// <returns></returns>
		private bool MinusStore()
		{
			bool aa = true;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Day"]);
			conn.Open();
			string str = "Select MinusRowMaterialPermissionUsed From SCS_T";
			SqlCommand comm =  new SqlCommand(str,conn);
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = bool.Parse(dr["MinusRowMaterialPermissionUsed"].ToString());
			}
			dr.Close();
			conn.Close();

			return aa;
		}

		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			int count = int.Parse(hdRowIndex.Value);
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			if(year < int.Parse(uwgBD_HT.Rows[count].Cells.FromKey("Year").Text))
				return true;
			else if(year == int.Parse(uwgBD_HT.Rows[count].Cells.FromKey("Year").Text))
			{
				if(month < int.Parse(uwgBD_HT.Rows[count].Cells.FromKey("Month").Text))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		

			
		}
	}
}
