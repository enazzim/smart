					
										// ��Ϲ�ư�� ������� ���� üũ
					function RegistCheck() {
						if(QualityInspectionRegister.txtSuccessQuantity.value != "" && 
						QualityInspectionRegister.txtRequestQuantity_Result.value != "" && QualityInspectionRegister.txtIncongruityQuantity.value != 0)	{
							var frmSq = Number(QualityInspectionRegister.txtSuccessQuantity.value);
							var frmRq = Number(QualityInspectionRegister.txtRequestQuantity_Result.value);
							if(frmSq < frmRq)  { // ������ǰ�� �߻��Ͽ��ٸ�.
								if(QualityInspectionRegister.ddlIncongruityDecision.selectedIndex == 0) 	{
									alert("- ������ �׸� ���� �˻������� �����ϼ���."); return false;
								} else	if( QualityInspectionRegister.ddlIncongruityCause.selectedIndex == 0 ) {
									alert("- ������ �׸� ���� ������ ������ �����ϼ���."); return false;
								} else	if( QualityInspectionRegister.ddlIncongruityPhenomenon.selectedIndex == 0 )	{
									alert("- ������ �׸� ���� ������ ������ �����ϼ���."); return false;
								}
							}
						} else if(QualityInspectionRegister.txtIncongruityQuantity.value == 0 && 
						(QualityInspectionRegister.txtSuccessQuantity.value == QualityInspectionRegister.txtRequestQuantity_Result.value) )	{
							if(QualityInspectionRegister.ddlIncongruityDecision.selectedIndex != 0)  {
								alert("- �����հ��� ���� �˻����� �׸��� ������ �� �����ϴ�.");		return false;
							} else if(QualityInspectionRegister.ddlIncongruityCause.selectedIndex != 0)  {
								alert("- �����հ��� ���� ������ ���� �׸��� ������ �� �����ϴ�.");	return false;
							} else if( QualityInspectionRegister.ddlIncongruityPhenomenon.selectedIndex != 0 )  {
								alert("- �����հ��� ���� ������ ���� �׸��� ������ �� �����ϴ�.");	return false;
							} else if( QualityInspectionRegister.txtIncongruityDetailContent_Result.value != "" )  {
								alert("- �����հ��� ���� ������ ���γ��� �׸��� ������ �� �����ϴ�.");	return false;
							} else if ( QualityInspectionRegister.txtIncongruityMoney.value != "" )   {
								alert("- �����հ��� ���� ������ �ݾ��� ������ �� �����ϴ�.");	return false;
							}
						}		
						if(confirm("- �˻����� ��� �Ͻðڽ��ϱ�? ") )	return true;		else		return false;		
					} 
			
					// Body OnLoad�� ȣ���.
					function Reset()	{
						QualityInspectionRegister.txtSuccessQuantity.value = "";
						QualityInspectionRegister.txtIncongruityQuantity.value = "";
						QualityInspectionRegister.txtIncongruityMoney.value = "";
					}
					
					// �޸����� �Լ�
					function RemoveComma(Ovalue)
					{
						var array = new String(Ovalue).split(",");
						var Rvalue = new String();
						for ( var i = 0 ; i < array.length ; i++)	{
							Rvalue += array[i];
						}
						return Rvalue;
					}
					
					// �԰ݼ��� �Է½� onkeyup �̺�Ʈ �� �߻�.
					function Process()	
					{
								var txtIncongruityQuantity = QualityInspectionRegister.txtIncongruityQuantity;
								var value = Number(RemoveComma(QualityInspectionRegister.txtRequestQuantity_Result.value)) - Number(RemoveComma(QualityInspectionRegister.txtSuccessQuantity.value));
								var sqTxt = QualityInspectionRegister.txtSuccessQuantity;

										if(value < 0 )	{
											alert("- �հݼ����� �Ƿڵ� �������� �����ϴ�");
											sqTxt.value = ""//sqTxt.value.substring(0, sqTxt.value.length-1);
											sqTxt.focus();
										}else{
											txtIncongruityQuantity.value = MakeCommaSeparate((Math.round((value * 10000)) / 10000));
										}
					}
					

			
			
/*			
					function WindowOpen(flag) {
							var vlaue;
							if(flag == 'item') {
										value = document.QualityInspectionRegister.txtItemNumber.value;
										if( SearchCheck() ) {
												var arr = null
												arr = window.showModalDialog("popupItemNumberFinder.aspx?itemNum="+ value + "","f","dialogHeight: 400px; dialogWidth: 450px; center: yes; help: no; resizable: no; status: no;");
													if (arr != null) {
																		QualityInspectionRegister.txtItemNumber.value = arr["ItemNum"];
																		QualityInspectionRegister.txtDrawingNumber.value = arr["ItemDrawNum"];
																		QualityInspectionRegister.txtItemName.value = arr["ItemName"];
													}	
										}
							} else if ( flag == 'customer' ) {
										value = document.QualityInspectionRegister.txtCustomerName.value;
										if( SearchCheck() ) {
												var arr = null
												arr = window.showModalDialog("popupcustomerNameFinder.aspx?customerName="+ value + "","f","dialogHeight: 400px; dialogWidth: 450px; dialogTop=100 ; dialogLeft=300; center: yes; help: no; resizable: no; status: no;");
													if (arr != null) {
														QualityInspectionRegister.txtCustomerName.value = arr["companyName"];
														QualityInspectionRegister.hidden_businessCompanyNum.value = arr["businessCompanyNum"];
													}	
										}
							}						
					} // function WindowOpen(flag) 					
*/					
					
					// �ʱ�ȭ ��ư
					function ResettxtBox(){
						
						var frm = document.QualityInspectionRegister;
						frm.txtItemNumber.value="";
						frm.txtDrawingNumber.value="";
						frm.txtItemName.value="";
						frm.txtCustomerName.value="";
						frm.txtStartDate_input.value="";
						frm.txtEndDate_input.value="";
						frm.hidden_businessCompanyNum.value="";
					}
					
					
//////////////////////////////////////////////////////////////////////////////////////////
//															Float	        														//
//////////////////////////////////////////////////////////////////////////////////////////
					
					function OnKeyDown_Float(obj) {   
						if (event.ctrlKey || event.shiftKey || event.altKey)   {
							SetEventPass();
							return true;
						}
												
						// �հݼ��� TextBox ��ü�� value�� �迭�� �����.
						var sFieldValue = new String(obj.value);
						// ���ڰ˻� + Numeric Keypad ���ڰ˻�
						if( (event.keyCode<45 || event.keyCode>57) && (event.keyCode<96 || event.keyCode>105))  {
    						if( event.keyCode == 110 || event.keyCode == 190 ) {
    							// "." �� 2���ִ��� �˻�
	    						if( sFieldValue.indexOf(".") != -1 )	{
	    							SetEventCancel();
									return obj.value;
	    						}
							} else if( !IsNumericKey() ) {
	    						SetEventCancel();
								return obj.value;
							}	    
						} else {    
    						if( sFieldValue.indexOf(".") == -1 ) {
	    						// "0" �� �Է����� ��� "0" ������ "." �� �ƴϸ� �����Ͽ��� �Ѵ�.	
	    						// 48, 96(Numeric Keypad)
								if( sFieldValue.substr(0,1) == "0" && (event.keyCode == 48 || event.keyCode == 96) ) {
									SetEventCancel();
									return obj.value;
								}
							}
						}
						SetEventPass();
						return true;
					}

					function OnFocus_Obj(obj) {
						obj.select();
					}
					
					function ValidateFloat(a_sValue)	{	
						var s_FieldValue = new String(a_sValue);
						
						if (isNaN(s_FieldValue))
							return false;
							
						return true;
					}
					
//////////////////////////////////////////////////////////////////////////////////////////
//															Currency															//
//////////////////////////////////////////////////////////////////////////////////////////

					
					function OnKeyUp_Currency(obj)		{
						sFieldValue = new String(obj.value);
						sFieldValue = sFieldValue.replace(/,/gi,"");
						if ( IsNumericKey() )		{
							SetEventPass();
							return true;
						}
						obj.value = MakeCommaSeparate(sFieldValue);
					}
					
					function OnBlur_Cur(obj)	{
						if (ValidateCurrency(obj.value) == false) {
							obj.value = "";
    						return false;
						}
					}
					
					function ValidateCurrency( a_sValue ) {	
						var s_FieldValue = new String(a_sValue);
						
						if (isNaN(parseFloat(s_FieldValue)))
							return false;
							
						return true;
					}

					// OnKeyUp_Currency ���� ȣ���� �Ҽ��� ���
					function MakeCommaSeparate(a_Value)	{
						var fl = "";
						var nPointPos = 0;    
					    
						if(isNaN(a_Value)) 	{ 
    						event.returnValue = false;
    						this.value = "";
    						return "";
						}
					    
						if(a_Value == 0) return a_Value;
					    
						if(a_Value < 0) { 
							a_Value=a_Value*(-1);
							fl = "-";
						}else if(a_Value == 0)	{
    						// ó�� �Է°��� 0���� �����Ҷ� �̰��� �����Ѵ�.
    						a_Value = a_Value*1; 
						}
					    
						var a_Value = new String(a_Value);
						var temp = "";
						var sRemain = "";
						var co = 3;
					    
						nPointPos = a_Value.indexOf(".");

						if( nPointPos == -1 )  {
    						num_len = a_Value.length;
						}else{
    						// "." �� ���ԵǾ� ���� ��쿡 ����
    						if( parseInt(a_Value.substr(0,nPointPos)) == 0 )	{
    							a_Value = "0" + a_Value.substr(nPointPos);
    							nPointPos = a_Value.indexOf(".");
    						}
    						num_len = nPointPos;
    						sRemain = a_Value.substr(nPointPos);
						}
					    
						while (num_len>0)	{
							num_len = num_len - co;
					        
							if(num_len<0)	{
        						co=num_len+co;
        						num_len=0;
							}
					        temp = "," + a_Value.substr(num_len,co) + temp;
						}
						return fl + temp.substr(1) + sRemain;
					}
					
					function IsNumericKey()  {
						if (
							event.keyCode == 8 ||
							event.keyCode == 9 ||
							event.keyCode == 35 ||
							event.keyCode == 36 ||
							event.keyCode == 37 ||
							event.keyCode == 39 ||
							event.keyCode == 38 ||
							event.keyCode == 40 ||
							event.keyCode == 46 ||
							event.keyCode == 189 ||
							event.keyCode == 109 ||
							event.keyCode == 110 ||		// "."
							event.keyCode == 190			// Ű�е� "."
							)
    						return true;
						else
    						return false;
					}
										
					function SetEventPass() {
							event.cancelBubble = false;
							event.returnValue = true;
					}

					function SetEventCancel() {
							event.cancelBubble = true;
							event.returnValue = false;
					}
					
					function DataGrid1_AfterSelectChangeHandler(gridName, id) {
						// �ʱ�ȭ
						document.QualityInspectionRegister.txtSuccessQuantity.value = "";
						document.QualityInspectionRegister.txtIncongruityQuantity.value = "";
						document.QualityInspectionRegister.txtIncongruityDetailContent_Result.value = "";
						
						document.QualityInspectionRegister.ddlIncongruityDecision.selectedIndex = 0;
						document.QualityInspectionRegister.ddlIncongruityCause.selectedIndex = 0;
						document.QualityInspectionRegister.ddlIncongruityPhenomenon.selectedIndex = 0;
						//document.QualityInspectionRegister.ddlInspectionPost.selectedIndex = 0;
						
						document.QualityInspectionRegister.txtItemNumber_Result.value = document.getElementById(id).children[1].innerText;
						document.QualityInspectionRegister.txtDrawingNumber_Result.value = document.getElementById(id).children[2].innerText;
						document.QualityInspectionRegister.txtItemName_Result.value = document.getElementById(id).children[3].innerText;
						// �ŷ�ó��
						document.QualityInspectionRegister.txtCustomerName_Result.value = document.getElementById(id).children[4].innerText;
						
						// ������
						var value = document.getElementById(id).children[5].innerText;
						value += "(" + document.getElementById(id).children[6].innerText + ")";
						document.QualityInspectionRegister.txtBeginProcess_Result.value = value
						
						value = document.getElementById(id).children[7].innerText;
						value += "(" + document.getElementById(id).children[8].innerText +")";
						document.QualityInspectionRegister.txtEndProcess_Result.value = value
						
						// ǰ��ܰ�
						document.QualityInspectionRegister.txtPrice.value = document.getElementById(id).children[14].innerText;
						
						// ����ڵ�Ϲ�ȣ
						document.QualityInspectionRegister.txtBusinessRegistrationNum_Result.value = document.getElementById(id).children[10].innerText;
						// �Ƿڼ���
						document.QualityInspectionRegister.txtRequestQuantity_Result.value = document.getElementById(id).children[11].innerText;
						
						document.QualityInspectionRegister.txtSuccessQuantity.disabled = false;
						document.QualityInspectionRegister.txtSuccessQuantity.focus();
						document.QualityInspectionRegister.btnRegist.disabled = false;
						
						// Key
						document.QualityInspectionRegister.hidden_key.value = document.getElementById(id).children[16].innerText;
						// ���嵵�� - (���ų�ǰ, ���ֳ�ǰ, �۾��Ϻ�)
						document.QualityInspectionRegister.hidden_historySection1.value = document.getElementById(id).children[0].innerText;
						// ����� ����1�� �ε���
						document.QualityInspectionRegister.hidden_historyIndex1.value = document.getElementById(id).children[12].innerText;
						// ���嵵�� 2 - (���Ź��ֿ���, ���ֹ��ֿ���)
						document.QualityInspectionRegister.hidden_historySection2.value = document.getElementById(id).children[13].innerText;
						// ����� ����2 �� �ε���
						document.QualityInspectionRegister.hidden_historyIndex2.value = document.getElementById(id).children[14].innerText;
						// ������ȣ
						document.QualityInspectionRegister.hidden_ProgressNum.value = document.getElementById(id).children[6].innerText;
					}
