using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideDeliveryPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideDeliveryPC : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.Button btnStop;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdquantity;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOSD_HT;
		protected System.Web.UI.WebControls.Literal Literal1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldMonth;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdReason;
		
		protected System.Web.UI.WebControls.DropDownList ddlState;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdMonth;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdApplyCost;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hd_year;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdmon;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}


			ItemSearchControl1.HalfFinishedProducts = true; //����ǰ ���ε�
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction = "���ְŷ�ó";

			if(!Page.IsPostBack)
			{
			
				// �ߴܹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnStop.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ��ǰ�� �ߴܽðڽ��ϱ�?');");
				// ������ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnDelete.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ������ �Ͻðڽ��ϱ�?');");
				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
				
			}	
		

		
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.uwgOSD_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgOSD_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("OutSideDeliveryPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName, wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value,ddlItemClassification1.SelectedItem.Value);
			else
				search = new KIT_ERP.Search("OutSideDeliveryPC",ItemSearchControl1.ItemNum, "", "", wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value,ddlItemClassification1.SelectedItem.Value);
			return search.DataSet_search();
		}

		//�˻���ư
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgOSD_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgOSD_HT.DataSource = Search();
			this.uwgOSD_HT.DataBind();

			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

				
			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
		}

		//�ߴܹ�ư 
		private void btnStop_Click(object sender, System.EventArgs e)
		{
			
			if(MonthClosing())
			{
				KIT_ERP.Stop stop = new Stop(uwgOSD_HT,"OutSideDeliveryPC",Session["ID"].ToString());
				stop.MainTableStop();
			}
			else
			{
				RegisterStartupScript("","<script>alert('�������� �Ǿ� �ߴ��� �Ұ��� �մϴ�!');</script>");
			}

			

			//�ߴܹ�ư�� ���� �����͸� �ߴ��� �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgOSD_HT.DataSource = Search();
			this.uwgOSD_HT.DataBind();

			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

				
			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;


		}

		//������ư
		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			
//			if(MonthClosing())
//			{
//				KIT_ERP.Delete delete = new Delete(uwgOSD_HT,"OutSideDeliveryPC",Session["UserName"].ToString(), Session["ID"].ToString());
//				delete.MainRowDelete();
//			}
//			else
//			{
//				RegisterStartupScript("","<script>alert('�������� �Ǿ� ������ �Ұ��� �մϴ�!');</script>");
//			}


			KIT_ERP.Delete delete = new Delete(uwgOSD_HT,"OutSideDeliveryPC",Session["UserName"].ToString(), Session["ID"].ToString());
			delete.MainRowDelete();

			//������ư�� ���� �����͸� ������ �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgOSD_HT.DataSource = Search();
			this.uwgOSD_HT.DataBind();

			DataSet ds = new DataSet();
			ds = Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

				
			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
		}

		//���� �׸��忡 ��Ÿ���ִ� �����͸� �������Ϸ� �ٿ�ε�
		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgOSD_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;

			uwgOSD_HT.DataSource = Search();
			uwgExcelImport.DataBind();
			
			uwgExcel.Export(uwgExcelImport);
		}

		//Grid Paging ���
		private void uwgOSD_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgOSD_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			uwgOSD_HT.DataSource =  Search();
			uwgOSD_HT.DataBind();

			DataSet ds = new DataSet();
			ds =  Search();

			decimal TotalCost = 0;
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				TotalCost += decimal.Parse(dr["TotalCost"].ToString());
			}

				
			//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
			Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
		}



		/// <summary>
		/// Template Row ���� ������ �ϸ� �ٸ� ���忡�� ���� ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void linkUpdate_Click(object sender, System.EventArgs e)
		{
			

			int rowcount = int.Parse(hdRowIndex.Value);

			//�����ϴ� �Լ� ������ ����Լ��� Ʈ������ ó��
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			
			try
			{	
				if(MonthClosing())
				{
					OSD_HT_Update(conn,tr); //���ֳ�ǰ������ �����ϴ� �Լ� ȣ��(�˻�ǰ��� ���˻�ǰ�� ��� ���ֳ�ǰ���� ����)
		
					//�����ϰ��� �ϴ� ǰ���� �˻� ǰ���� ���
					if(Check(conn,tr) == true)
					{
						QI_HT_Update(conn,tr);//ǰ���˻���� �����ϴ� �Լ�ȣ��
						OO_HTWaitingQuantityUpdate(conn,tr);//���Ź��ֿ����� �԰������� ����
					}
					else//�����ϰ��� �ϴ� ǰ���� ���˻� ǰ���� ���
					{		
						NonQI_HT_Update(conn,tr);//ǰ���˻� ����
						PS_MT_Update(conn,tr);//����â�� �����ϴ� �Լ� ȣ��
						OO_HT_Update(conn,tr);//���ֹ��ֿ����� �����ϴ� �Լ� ȣ��
						BSI_MT_Update(conn,tr);//���Ը������̺��� �����ϴ� �Լ� ȣ��
						B_HT_Update(conn,tr);//���Կ����� �����ϴ� �Լ� ȣ��
						OS_MT_Update(conn,tr);//����â���� �����ϴ� �Լ� ȣ��
						BOS_HTUpdate(conn,tr);

						//�����ϰ��� �ϴ� ǰ���� ���˻�ǰ�̸鼭 ��ǰ�ΰ��
						if(Division(conn,tr) == 3)
						{	
							if(!Last(conn,tr,uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString(),int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessSequenceNum").Value.ToString())))
							{
								ISR_HT_Update(conn,tr);//�԰��Ƿڿ����� �����ϴ� �Լ� ȣ��
								BS_MTUpdate(conn,tr); //����â�� ���� ����
							}
						}
					

					}
				}
				else
				{
					throw new Exception("�������� �Ǿ� ������ �Ұ��� �մϴ�!");
				}

				
				
				tr.Commit();
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('�����Ͽ����ϴ�.');");
				Response.Write("</script>");
			}
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();

				this.uwgOSD_HT.DataSource = Search();
				this.uwgOSD_HT.DataBind();

				DataSet ds = new DataSet();
				ds = Search();

				decimal TotalCost = 0;
				foreach(DataRow dr in ds.Tables[0].Rows)
				{
					TotalCost += decimal.Parse(dr["TotalCost"].ToString());
				}

				
				//Literal1.Text = "�� �ݾ�<b>\" " + TotalCost + " \"</b> ��" ;
				Literal1.Text = "�� �ݾ�<b>\" " + TotalCost.ToString().Substring(0, TotalCost.ToString().IndexOf(".") + 2) + " \"</b> ��" ;
			}
		}


		private void BOS_HTUpdate(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason, [Date],UpdatePerson, UpdatePersonID,HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,@ProcessSequenceNum,@ProcessCode,@ProcessName,@CompanyName,@BusinessRegistrationNum,@Quantity,@UnitCost,@UpdateHistoryReason, @Date,@Person, @PersonID,'���ֳ�ǰ',@HistoryIndex)";
				
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			
			comm.Parameters.Add("@itemnum", uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text);	//ǰ���ȣ
			comm.Parameters.Add("@itemdrawnum", uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemDrawNum").Text);							//�����ȣ
			comm.Parameters.Add("@itemname",uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemName").Text);									//ǰ���
			comm.Parameters.Add("@CompanyName",uwgOSD_HT.Rows[rowcount].Cells.FromKey("CompanyName").Text);								//��ü��
			comm.Parameters.Add("@BusinessRegistrationNum",uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Text);
			comm.Parameters.Add("@ProcessSequenceNum",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessSequenceNum").Text));	//��������
			comm.Parameters.Add("@ProcessCode",uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Text);								//�����ڵ�
			comm.Parameters.Add("@ProcessName",uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessName").Text);								//������
			comm.Parameters.Add("@Quantity",decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UnitCost",decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()));//�հݼ���
			comm.Parameters.Add("@UpdateHistoryReason",hdReason.Value.Trim());												//������
			comm.Parameters.Add("@Date", DateTime.Now.ToShortDateString());//�����������
			comm.Parameters.Add("@Person",Session["UserName"].ToString());
			comm.Parameters.Add("@PersonID", Session["ID"].ToString());	
			comm.Parameters.Add("@HistoryIndex",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Text));												//�����ȣ

			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		//���˻��� ǰ���� ������������ �ľ��ϴ� �Լ�
		//false�̸� ��������
		private bool Last(SqlConnection conn, SqlTransaction tr, string itemnum, int sequence)
		{
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			string str  = "select count(*) From PSI_MT Where RecodingState = 1 and ItemNum = @item and ProcessSequenceNum > @num";
			comm.Parameters.Add("@item",itemnum);
			comm.Parameters.Add("@num",sequence);
			comm.CommandText = str;
			int count = int.Parse(comm.ExecuteScalar().ToString());
			if(count == 0)
				return false;
			else
				return true;
		}


		//�����ϰ��� �ϴ� ǰ���� �˻�ǰ������ ���˻� ǰ������ Check�ϴ� �Լ�
		private bool Check(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string aa = "";
			string str = "Select CheckDistinction From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			SqlDataReader dr = comm.ExecuteReader();

			if(dr.Read())
			{
				aa = dr["CheckDistinction"].ToString();
			}
			dr.Close();

			if(aa.ToString() == "False")
				return false;
			else
				return true;
		}
		
		//�����ϰ��� �ϴ� ǰ���� ��ǰ���� ���������� �Ǵ��ϴ� �Լ�
		private int Division(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string aa="";

			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value =uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			dr.Close();

			if(aa.ToString() == "������")
				return 1;
			else if(aa.ToString() =="����ǰ")
				return 2;
			else if(aa.ToString() =="��ǰ")
				return 3;
			else if(aa.ToString() =="��ǰ")
				return 4;
			else 
				return 5;
		}

		//���ֳ�ǰ������ �����ϴ� �Լ�
		private void OSD_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			//���� ǰ���˻���忡�� ��ǰ������ ����
			//string str1 =" UPDATE OSD_HT SET DeliveryQuantity = @quantity , TotalCost = @cost, LotNum = @LotNum  WHERE OutSideDeliveryHistoryIndex= @INDEX";
			string str1 =" UPDATE OSD_HT SET [Year] = @year, [Month] = @mon, DeliveryQuantity = @quantity , TotalCost = @cost, LotNum = @LotNum, DeliveryDate = @date WHERE OutSideDeliveryHistoryIndex= @INDEX";
			SqlCommand comm1 = new SqlCommand(str1,con);
			comm1.Transaction = trans;
					
			comm1.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()) * decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm1.Parameters.Add("@date", DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).ToShortDateString());
			comm1.Parameters.Add("@LotNum", uwgOSD_HT.Rows[rowcount].Cells.FromKey("LotNum").Text);
			comm1.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Value.ToString());
			comm1.Parameters.Add("@year",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString()));
			comm1.Parameters.Add("@mon",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString()));
			comm1.ExecuteNonQuery();
		}

		//ǰ���˻���� �����ϴ� �Լ�
		private void QI_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			
			//���� ǰ���˻���忡�� ��ǰ������ Update
			int rowcount = int.Parse(hdRowIndex.Value);
			string str =" UPDATE QI_HT SET [Year] = @year, [Month] = @mon,  RequestQuantity = @quantity, ApplyUnitCost = @cost, RegistrationDate = @date WHERE HistorySection1= '���ֳ�ǰ' and HistoryIndex1 = @INDEX";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm.Parameters.Add("@date", DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("RegistrationDate").Text).ToShortDateString());
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Value.ToString());
			comm.Parameters.Add("@year",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString()));
			comm.Parameters.Add("@mon",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString()));
			comm.ExecuteNonQuery();
		}

		/// <summary>
		/// ���ֹ��ֿ��� �԰������� ����
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void OO_HTWaitingQuantityUpdate(SqlConnection con,SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			decimal quantity = decimal.Parse(hdquantity.Value);

			string str =" UPDATE OO_HT SET InStoreWaitingQuantity = InStoreWaitingQuantity - @InStoreWaitingQuantity WHERE OutSideOrderHistoryIndex = @INDEX";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.CommandText = str;
			comm.Parameters.Add("@InStoreWaitingQuantity", quantity);
			comm.Parameters.Add("@INDEX",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			str =" UPDATE OO_HT SET InStoreWaitingQuantity = InStoreWaitingQuantity + @InStoreWaitingQuantity WHERE OutSideOrderHistoryIndex = @INDEX";
			comm.CommandText = str;
			comm.Parameters.Add("@InStoreWaitingQuantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}


		//���˻�ǰ�� ǰ���˻���� �����ϴ� �Լ�
		private void NonQI_HT_Update(SqlConnection con,SqlTransaction trans)
		{
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;

			int rowcount = int.Parse(hdRowIndex.Value);
			string Condition="";

			string str  = @"Select * From QI_HT WHERE HistorySection1= '���ֳ�ǰ' and HistoryIndex1 = @INDEX";
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Value.ToString());
			comm.CommandText = str;
			SqlDataAdapter daQI = new SqlDataAdapter(comm);
			DataSet dsQI = new DataSet();
			daQI.Fill(dsQI);
			comm.Parameters.Clear();

			foreach(DataRow dr in dsQI.Tables[0].Rows)
			{
				Condition = dr["ProgressCondition"].ToString();
			}

			if(Condition == "�԰��Ϸ�")
			{
				throw new Exception("�̹� �԰��Ϸ�� ǰ���Դϴ�!");
			}
			else
			{
				//���� ǰ���˻���忡�� ��ǰ������ Update
				str =" UPDATE QI_HT SET [Year] = @year, [Month] = @mon, RequestQuantity = @quantity, SuitabilityQuantity=@quantity,ApplyUnitCost = @cost, QualityInspectionCompleteDate = @QualityInspectionCompleteDate WHERE HistorySection1= '���ֳ�ǰ' and HistoryIndex1 = @INDEX";
				comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
				comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
				comm.Parameters.Add("@QualityInspectionCompleteDate", DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).ToShortDateString());
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Value.ToString());
				comm.Parameters.Add("@year",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Year").Value.ToString()));
				comm.Parameters.Add("@mon",int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Month").Value.ToString()));
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
			}

		}




		//����â���� ������ �����ϴ� �Լ�
		private void PS_MT_Update(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			int year = int.Parse(hdYear.Value);
			int mon = int.Parse(hdMonth.Value);
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = decimal.Parse(hdApplyCost.Value);
			
			//�������̺����� ���������� ���̳ʽ� ����
		
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = -(unitcost*decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
			mon = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Text)*decimal.Parse(hdquantity.Value.ToString());
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@year",year);
			Table table1 = new Table(year,mon);

			comm.CommandText = table1.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM RMS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code and [Year] = @year";
				comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text;
				comm.Parameters.Add("@code",uwgOSD_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Text);
				comm.Parameters.Add("@year",DateTime.Now.Year);

				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
				comm.Parameters.Clear();
						
				string StockQuantity = "False";
				string ItemName = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text;
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ����� �������� ����� �Ұ��� �մϴ�.");
				}
			}
		}

		//�԰��Ƿڿ����� ������ �����ϴ� �Լ�
		private void ISR_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			//���� ǰ���˻���忡�� ��ǰ������ �ݾ��� Update
			int rowcount = int.Parse(hdRowIndex.Value);

			string str =" UPDATE ISR_HT SET InstorehouseRequestQuantity = @quantity WHERE HistorySection ='���ֳ�ǰ' and HistoryIndex = @idx";
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;		
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@idx",SqlDbType.Int).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("HistoryIndex").Value.ToString();
			
			comm.ExecuteNonQuery();
		}

		/// <summary>
		/// ����â�� ���� ����
		/// </summary>
		/// <param name="con"></param>
		/// <param name="trans"></param>
		private void BS_MTUpdate(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			int year = int.Parse(hdYear.Value);
			int mon = int.Parse(hdMonth.Value);
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = decimal.Parse(hdApplyCost.Value);
			
			//�������̺����� ���������� ���̳ʽ� ����
		
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = -(unitcost*decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@storenum", SqlDbType.VarChar).Value = 1;
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.InBusinessTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
			mon = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Text)*decimal.Parse(hdquantity.Value.ToString());
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@storenum", SqlDbType.VarChar).Value = 1;
			comm.Parameters.Add("@year",year);
			Table table1 = new Table(year,mon);

			comm.CommandText = table1.InBusinessTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM BS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and BusinessStorehouseNum = 1 and [Year] = @year";
				comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text;
				comm.Parameters.Add("@year",DateTime.Now.Year);

				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
				comm.Parameters.Clear();
						
				string StockQuantity = "False";
				string ItemName = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text;
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ����� �������� ������ �Ұ��� �մϴ�.");
				}
			}
		}

		//���� ���ֹ��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
		private void OO_HT_Update(SqlConnection con, SqlTransaction trans)
		{			
			int rowcount = int.Parse(hdRowIndex.Value);
			int index= int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());;
			string str1 = "select RemainQuantity from OO_HT where OutSideOrderHistoryIndex= @INDEX";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.CommandText = str1;
			comm.Transaction = trans;
		
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
		
			decimal requantity = decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			string str =" UPDATE OO_HT SET RemainQuantity = @requantity WHERE OutSideOrderHistoryIndex= @INDEX";
			
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@requantity", SqlDbType.Decimal).Value = requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
			comm.CommandText = str;
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
			
		
			//�����ܷ��� + ������ǰ�� - �����ĳ�ǰ��
			if(requantity + (decimal.Parse(hdquantity.Value.ToString()))-(decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())) == 0)
			{				
				str =" UPDATE OO_HT SET ProgressCondition = @progress WHERE OutSideOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "�Ϸ�";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

			}
			else
			{			
				str =" UPDATE OO_HT SET ProgressCondition = @progress WHERE OutSideOrderHistoryIndex= @INDEX";
				comm.Parameters.Add("@progress",SqlDbType.VarChar).Value = "����";
				comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = index;
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

			}
		}

		//���Ը�������� �ݾ� �����ϴ� �Լ�
		private void BSI_MT_Update(SqlConnection con, SqlTransaction trans)
		{
			
			//�������̺����� ������ǰ���� ���̳ʽ� ����
			int rowcount = int.Parse(hdRowIndex.Value);
			int year = int.Parse(hd_year.Value);
			int mon = int.Parse(hdmon.Value);
			decimal total = decimal.Parse(hdApplyCost.Value)*decimal.Parse(hdquantity.Value);
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -total;
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ��ǰ�� ����
			year = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Year").Text);
			mon = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("Month").Text);
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString()))*(decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));// ��ǰ�ݾ�
			comm.Parameters.Add("@year",year);

			Table table1 = new Table(year,mon);
			comm.CommandText = table1.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
		}

		//���Կ����� �ݾװ� ���� �����ϴ� �Լ�
		private void B_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);

			//���� ����Ǵ� ǰ���˻���忡�� ��ǰ������ �ݾ��� Update
			string str =" UPDATE B_HT SET BuyingQuantity = @quantity,TotalCost = @cost WHERE HistorySection= '���ֳ�ǰ' and HistoryIndex = @INDEX";
			SqlCommand comm = new SqlCommand(str,con);
            comm.Transaction = trans;		
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = ((decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()))*(decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString())));
			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideDeliveryHistoryIndex").Value.ToString());
			comm.ExecuteNonQuery();
		}

		//����â���� ������ �����ϴ� �Լ�
		private void OS_MT_Update(SqlConnection con, SqlTransaction trans)
		{

			int rowcount = int.Parse(hdRowIndex.Value);
			//���۰����ڵ�,���۰�������
			string begincode = "";
			int beginsequence = 0;
			string itemnum = uwgOSD_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();

			//���ֿ��� �ε����� ������ ���� ã���� ���۰����� ã���� �ִ�.
			string str = @"Select ItemNum, BeginProcessCode, BusinessRegistrationNum  From OO_HT Where OutSideOrderHistoryIndex = @idx";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.Parameters.Add("@idx",SqlDbType.Int).Value = int.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("OutSideOrderHistoryIndex").Value.ToString());
			comm.CommandText = str;
			DataSet ds_code = new DataSet();
			SqlDataAdapter da_code = new SqlDataAdapter(comm);
			da_code.Fill(ds_code);
			comm.Parameters.Clear();

			foreach(DataRow dr_code in ds_code.Tables[0].Rows)
			{
				begincode = dr_code["BeginProcessCode"].ToString();
				str = "Select * From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessCode = @code";
				comm.Parameters.Add("@num", dr_code["ItemNum"].ToString());
				comm.Parameters.Add("@code",dr_code["BeginProcessCode"].ToString());
				comm.CommandText = str;
				SqlDataReader dr1 = comm.ExecuteReader();
				while(dr1.Read())
				{
					beginsequence = int.Parse(dr1["ProcessSequenceNum"].ToString());
				}
				dr1.Close();
				comm.Parameters.Clear();

			}
			
			//�ش� ǰ���� ���� ���� �����̸� ����ǰ����� �ֻ��������� �����ְ�
			//�׷��� ������ �ش������ �ٷ� �Ʒ�����ǰ�� ����â������ �����
			//�̶� ����ǰ���� �ڻ�з��� �������̸� �ش� ǰ���� �����ش�

			Decimal m_cost = 0;
			Decimal m_progressrate = 100;

			str = @"Select isnull(Min(ProcessSequenceNum),0) From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessSequenceNum < @sequence";
			comm.Parameters.Add("@num",itemnum);
			comm.Parameters.Add("@sequence",beginsequence);
			comm.CommandText = str;
			

			if(int.Parse(comm.ExecuteScalar().ToString()) == 0)
			{
				comm.Parameters.Clear();
				//���������� ���� �ش���ǰ���� �����ش�
				str = @"Select * From IOI_MT Where RecodingState = 1 and ParentItemNum = @num";
				comm.Parameters.Add("@num",itemnum);
				comm.CommandText = str;
				DataSet ds = new DataSet();
				SqlDataAdapter da = new SqlDataAdapter(comm);
				da.Fill(ds);
				comm.Parameters.Clear();
				foreach(DataRow dr in ds.Tables[0].Rows)
				{
					//����ǰ���� �������̸� �ٷ� �����ش�
					if(Division(dr["ChildItemNum"].ToString()) == 1)
					{
						// ǰ���� �ݾ�
						string str_cost = "Select StandardUnitCost From II_MT Where RecodingState = 1 and ItemNum = @num";
						SqlCommand comm_cost = new SqlCommand(str_cost,con);
						comm_cost.Transaction = trans;
						comm_cost.Parameters.Add("@num",SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						SqlDataReader dr_cost = comm_cost.ExecuteReader();
			
						if(dr_cost.Read())
							m_cost = Decimal.Parse(dr_cost["StandardUnitCost"].ToString());
						dr_cost.Close();

						
						decimal a = 0;
						str = @"Select * From IOI_MT Where RecodingState = 1 and ParentItemNum = @parent and ChildItemNum = @child";
						SqlCommand comm1 = new SqlCommand(str,con);
						comm1.Transaction = trans;
						comm1.Parameters.Add("@parent",itemnum);
						comm1.Parameters.Add("@child",dr["ChildItemNum"].ToString());
						SqlDataReader dr_1 =  comm1.ExecuteReader();
						while(dr_1.Read())
						{
							a = decimal.Parse(dr_1["NeedQuantityNumerator"].ToString())/decimal.Parse(dr_1["NeedQuantityDenominator"].ToString());
						}
						dr_1.Close();
						comm1.Parameters.Clear();

						if(a == 0)
							throw new Exception(itemnum + " ǰ���� ǰ�񱸼��� ���ų� �ùٸ��� �ʽ��ϴ�!");
						

						//�������̺����� ���������� ���̳ʽ� ����
						int year = int.Parse(hdYear.Value);
						int mon = int.Parse(hdMonth.Value);
						comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(a *decimal.Parse(hdquantity.Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
						comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(a* decimal.Parse(hdquantity.Value.ToString()));
						comm.Parameters.Add("@num", SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						comm.Parameters.Add("@code", SqlDbType.VarChar).Value = "14000000";
						comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
						comm.Parameters.Add("@year",year);

						Table table = new Table(year,mon);
						comm.CommandText = table.OutTable();
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();


						//���κ���Ǵ� ������ ������ ����
						year = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
						mon = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
						comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (a *decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
						comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = (a* decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
						comm.Parameters.Add("@num", SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						comm.Parameters.Add("@code", SqlDbType.VarChar).Value = "14000000";
						comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
						comm.Parameters.Add("@year",year);
						Table table1 = new Table(year,mon);
						comm.CommandText = table1.OutTable();
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();


						if(MinusStore() == false)
						{
							string strSQL = "SELECT StockQuantity12 FROM OS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code and BusinessRegistrationNum = @comnum and [Year] = @year";
							comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  dr["ChildItemNum"].ToString();
							comm.Parameters.Add("@code",SqlDbType.VarChar).Value = "14000000";
							comm.Parameters.Add("@comnum",SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
							comm.Parameters.Add("@year" ,DateTime.Now.Year);
							comm.CommandText = strSQL;
							SqlDataReader reader = comm.ExecuteReader();
						
							string StockQuantity = "False";
							string ItemName = dr["ChildItemNum"].ToString();
							if(reader.Read())
							{
								if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
								{
									StockQuantity = "True";
								}
							}
							reader.Close();

							if(StockQuantity == "True")
							{
								throw new Exception(ItemName + " �� ����� �������� ó���� �� �����ϴ�.");
							}

						}

					}
					else
					{
						//����ǰ�̸� ��ǰ���� �ִ������ �����ش�.
						string code = "";
						str = @"Select ProcessCode, ProcessSequenceNum From PSI_MT Where RecodingState = 1 and 
							ItemNum = @num and ProcessSequenceNum = (Select Max(ProcessSequenceNum) From PSI_MT 
							Where RecodingState = 1 and ItemNum = @num)";
						comm.Parameters.Add("@num",dr["ChildItemNum"].ToString());
						comm.CommandText = str;
						SqlDataReader dr_Code = comm.ExecuteReader();
						while(dr_Code.Read())
						{
							code = dr_Code["ProcessCode"].ToString();
						}
						dr_Code.Close();
						comm.Parameters.Clear();

						// ǰ���� �ݾ�
						string str_cost = "Select StandardUnitCost From II_MT Where RecodingState = 1 and ItemNum = @num";
						SqlCommand comm_cost = new SqlCommand(str_cost,con);
						comm_cost.Transaction = trans;
						comm_cost.Parameters.Add("@num",SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						SqlDataReader dr_cost = comm_cost.ExecuteReader();
			
						if(dr_cost.Read())
							m_cost = Decimal.Parse(dr_cost["StandardUnitCost"].ToString());
						dr_cost.Close();

						// ǰ���� ��ô��
						string str_rate = "Select ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessCode = @code";
						SqlCommand comm_rate = new SqlCommand(str_rate,con);
						comm_rate.Transaction = trans;
						comm_rate.Parameters.Add("@num",SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						comm_rate.Parameters.Add("@code",SqlDbType.VarChar).Value = code;
						SqlDataReader dr_rate = comm_rate.ExecuteReader();			
						if(dr_rate.Read())
							m_progressrate = Decimal.Parse(dr_rate["ProgressRate"].ToString());
						dr_rate.Close();
						comm_rate.Parameters.Clear();

						//��ǰ�����/�и�
						decimal a = 0;
						str = @"Select * From IOI_MT Where RecodingState = 1 and ParentItemNum = @parent and ChildItemNum = @child";
						SqlCommand comm1 = new SqlCommand(str,con);
						comm1.Transaction = trans;
						comm1.Parameters.Add("@parent",itemnum);
						comm1.Parameters.Add("@child",dr["ChildItemNum"].ToString());
						SqlDataReader dr_1 =  comm1.ExecuteReader();
						while(dr_1.Read())
						{
							a = decimal.Parse(dr_1["NeedQuantityNumerator"].ToString())/decimal.Parse(dr_1["NeedQuantityDenominator"].ToString());
						}
						dr_1.Close();
						comm1.Parameters.Clear();

						if(a == 0)
							throw new Exception(itemnum + " ǰ���� ǰ�񱸼��� ���ų� �ùٸ��� �ʽ��ϴ�!");

						//�������̺����� ���������� ���̳ʽ� ����		
						int year = int.Parse(hdYear.Value);
						int mon = int.Parse(hdMonth.Value);
						comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(a *decimal.Parse(hdquantity.Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
						comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(a* decimal.Parse(hdquantity.Value.ToString()));
						comm.Parameters.Add("@num", SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						comm.Parameters.Add("@code", SqlDbType.VarChar).Value = code;
						comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
						comm.Parameters.Add("@year",year);

						Table table = new Table(year,mon);
						comm.CommandText = table.OutTable();
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();


						//���κ���Ǵ� ������ ������ ����
						year = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
						mon = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
						comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (a *decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
						comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = (a* decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
						comm.Parameters.Add("@num", SqlDbType.VarChar).Value = dr["ChildItemNum"].ToString();
						comm.Parameters.Add("@code", SqlDbType.VarChar).Value = code;
						comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
						comm.Parameters.Add("@year",year);
						Table table1 = new Table(year,mon);
						comm.CommandText = table1.OutTable();
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();



						if(MinusStore() == false)
						{
							string strSQL = "SELECT StockQuantity12 FROM OS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code and BusinessRegistrationNum = @comnum and [Year] = @year";
							comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  dr["ChildItemNum"].ToString();
							comm.Parameters.Add("@code",SqlDbType.VarChar).Value = code;
							comm.Parameters.Add("@comnum",SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
							comm.Parameters.Add("@year" ,DateTime.Now.Year);
							comm.CommandText = strSQL;
							SqlDataReader reader = comm.ExecuteReader();
						
							string StockQuantity = "False";
							string ItemName = dr["ChildItemNum"].ToString();
							if(reader.Read())
							{
								if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
								{
									StockQuantity = "True";
								}
							}
							reader.Close();

							if(StockQuantity == "True")
							{
								throw new Exception(ItemName + " �� ����� �������� ó���� �� �����ϴ�.");
							}

						}

						

					}
				}
				

			}
			else
			{
				comm.Parameters.Clear();
				//�ش�ǰ���� �ٷ� �Ʒ� ������ �����ش�
				string code = "";
				str = @"Select ProcessCode, ProcessSequenceNum From PSI_MT Where RecodingState = 1 and 
							ItemNum = @num and ProcessSequenceNum = (Select Max(ProcessSequenceNum) From PSI_MT 
							Where RecodingState = 1 and ItemNum = @num and ProcessSequenceNum < @sequence)";
				comm.Parameters.Add("@num",itemnum);
				comm.Parameters.Add("@sequence",beginsequence);
				comm.CommandText = str;				
				SqlDataReader dr_Code = comm.ExecuteReader();
				while(dr_Code.Read())
				{
					code = dr_Code["ProcessCode"].ToString();
				}
				dr_Code.Close();
				comm.Parameters.Clear();

				// ǰ���� �ݾ�
				string str_cost = "Select StandardUnitCost From II_MT Where RecodingState = 1 and ItemNum = @num";
				SqlCommand comm_cost = new SqlCommand(str_cost,con);
				comm_cost.Transaction = trans;
				comm_cost.Parameters.Add("@num",SqlDbType.VarChar).Value = itemnum;
				SqlDataReader dr_cost = comm_cost.ExecuteReader();
			
				if(dr_cost.Read())
					m_cost = Decimal.Parse(dr_cost["StandardUnitCost"].ToString());
				dr_cost.Close();

				// ǰ���� ��ô��
				string str_rate = "Select ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessCode = @code";
				SqlCommand comm_rate = new SqlCommand(str_rate,con);
				comm_rate.Transaction = trans;
				comm_rate.Parameters.Add("@num",SqlDbType.VarChar).Value = itemnum;
				comm_rate.Parameters.Add("@code",SqlDbType.VarChar).Value = code;
				SqlDataReader dr_rate = comm_rate.ExecuteReader();			
				if(dr_rate.Read())
					m_progressrate = Decimal.Parse(dr_rate["ProgressRate"].ToString());
				dr_rate.Close();
				comm_rate.Parameters.Clear();

				//				//����â���� ������ ǰ��
				int year = int.Parse(hdYear.Value);
				int mon = int.Parse(hdMonth.Value);
				comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
				comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
				comm.Parameters.Add("@num", SqlDbType.VarChar).Value = itemnum;
				comm.Parameters.Add("@code", SqlDbType.VarChar).Value = code;
				comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
				comm.Parameters.Add("@year",year);

				Table table = new Table(year,mon);
				comm.CommandText = table.OutTable();
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();


				//���κ���Ǵ� ������ ������ ����
				year = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Year;
				mon = DateTime.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryDate").Text).Month;
				comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString())* Decimal.Parse(m_cost.ToString()) * Decimal.Parse(m_progressrate.ToString())/100);
				comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = (decimal.Parse(uwgOSD_HT.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString()));
				comm.Parameters.Add("@num", SqlDbType.VarChar).Value = itemnum;
				comm.Parameters.Add("@code", SqlDbType.VarChar).Value = code;
				comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
				comm.Parameters.Add("@year",year);
				Table table1 = new Table(year,mon);

				comm.CommandText = table1.OutTable();
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();


				if(MinusStore() == false)
				{
					string strSQL = "SELECT StockQuantity12 FROM OS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code and BusinessRegistrationNum = @comnum and [Year] = @year";
					comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  itemnum;
					comm.Parameters.Add("@code",SqlDbType.VarChar).Value = code;
					comm.Parameters.Add("@comnum",SqlDbType.VarChar).Value = uwgOSD_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
					comm.Parameters.Add("@year" ,DateTime.Now.Year);
					comm.CommandText = strSQL;
					SqlDataReader reader = comm.ExecuteReader();
						
					string StockQuantity = "False";
					string ItemName = itemnum;
					if(reader.Read())
					{
						if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
						{
							StockQuantity = "True";
						}
					}
					reader.Close();

					if(StockQuantity == "True")
					{
						throw new Exception(ItemName + " �� ����� �������� ó���� �� �����ϴ�.");
					}
				}
			}

		}


		/// <summary>
		/// ���̳ʽ� ��� ��뿩��
		/// </summary>
		/// <returns></returns>
		private bool MinusStore()
		{
			bool aa = true;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Day"]);
			conn.Open();
			string str = "Select MinusRowMaterialPermissionUsed From SCS_T";
			SqlCommand comm =  new SqlCommand(str,conn);
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = bool.Parse(dr["MinusRowMaterialPermissionUsed"].ToString());
			}
			dr.Close();
			conn.Close();

			return aa;
		}

		private int Division(string ItemNum)
		{
			string aa="";

			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value = ItemNum.ToString();
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			conn.Close();

			if(aa.ToString() == "������")
				return 1;
			else if(aa.ToString() =="����ǰ")
				return 2;
			else if(aa.ToString() =="��ǰ")
				return 3;
			else if(aa.ToString() =="��ǰ")
				return 4;
			else //if(aa.ToString() =="����")
				return 5;
		}

		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			int count = int.Parse(hdRowIndex.Value);
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			if(year < int.Parse(uwgOSD_HT.Rows[count].Cells.FromKey("Year").Text))
				return true;
			else if(year == int.Parse(uwgOSD_HT.Rows[count].Cells.FromKey("Year").Text))
			{
				if(month < int.Parse(uwgOSD_HT.Rows[count].Cells.FromKey("Month").Text))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		

			
		}

	}
}
