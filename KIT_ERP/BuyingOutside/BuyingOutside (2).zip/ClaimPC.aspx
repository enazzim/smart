<%@ Register TagPrefix="uc1" TagName="CompanySearchControl" Src="../Common/CompanySearchControl/CompanySearchControl.ascx" %>
<%@ Register TagPrefix="uc1" TagName="ItemSearchControl" Src="../Common/ItemSearchControl/ItemSearchControl.ascx" %>
<%@ Register TagPrefix="igtblexp" Namespace="Infragistics.WebUI.UltraWebGrid.ExcelExport" Assembly="Infragistics.WebUI.UltraWebGrid.ExcelExport.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igcmbo" Namespace="Infragistics.WebUI.WebCombo" Assembly="Infragistics.WebUI.WebCombo.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igsch" Namespace="Infragistics.WebUI.WebSchedule" Assembly="Infragistics.WebUI.WebDateChooser.v1.2, Version=1.2.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igtbl" Namespace="Infragistics.WebUI.UltraWebGrid" Assembly="Infragistics.WebUI.UltraWebGrid.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Page language="c#" Codebehind="ClaimPC.aspx.cs" AutoEventWireup="false" Inherits="KIT_ERP.BuyingOutside.ClaimPC" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>ClaimPC</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<LINK href="../StyleSheet2.css" type="text/css" rel="stylesheet">
		<SCRIPT type="text/javascript"><!--

		function ResettxtBox()
		{
			ResetTextBox();
			ResetBox();
			var objChooser1 = igdrp_getComboById("wdcFromDate");
			var objChooser2 = igdrp_getComboById("wdcToDate");
			objChooser1.setValue(null);
			objChooser2.setValue(null);
		}
		
		var GridName;
		
		
		function UltraWebGrid1_ColumnHeaderClickHandler(gridName, columnId, button)
		{
			GridName = gridName;
    			if(document.ClaimPC.chkAll.value == "true")
    			{
					AllCheck();
				}
				else
				{
					AllUncheck();
				}
		}
		
		function AllCheck() // ���� üũ�ϱ�
		{
			var grid = igtbl_getGridById(GridName);
			
			for(var i=0; i<grid.Rows.length; i++)
			{
				var row = grid.Rows.getRow(i);
				row.getCellFromKey("chk").setValue(true);
			}
			document.ClaimPC.chkAll.value = "false";
		}


		function AllUncheck() // ����üũ �����ϱ�
		{
			var grid = igtbl_getGridById(GridName);
			
			for(var i=0; i<grid.Rows.length; i++)
			{
				var row = grid.Rows.getRow(i);
				row.getCellFromKey("chk").setValue(false);
			}
			document.ClaimPC.chkAll.value = "true";
		}
		function UltraWebGrid1_MouseOverHandler(gridName, id, button)
		{
		
			//Add code to handle your event here.
			if(button == 0)
			{ // Are we over a cell
				var cell = igtbl_getElementById(id);
				cell.style.cursor = 'hand';
				//var label = igtbl_getElementById("lb_RowIndex");
				var parts = id.split("_");                                                                                                                                                                                                                       
				document.ClaimPC.lb_RowIndex.value = parts[1];
			}
		}
		
		// ����â�� �����鼭 ���� �Է��ϴ� �Լ�
		function UltraWebGrid1_AfterRowTemplateOpenHandler(gridName, rowId)
		{
			var objGrid = igtbl_getActiveRow(gridName)//���� ���õǾ��� ��ü�� ���� ������
			var row = igtbl_getRowById(rowId);
			
			
			//Add code to handle your event here.
			document.ClaimPC.lb_RowSelectIndex.value = document.ClaimPC.lb_RowIndex.value;
			
			
			//����ũ���ӱݾ�
			document.ClaimPC.lb_Cost.value = row.getCellFromKey("ClaimCost").getValue();//�����ݾ�
			
			document.ClaimPC.igtbl_TextBox_0_7.value = MakeCommaSeparate(row.getCellFromKey("ClaimQuantity").getValue());//����
			document.ClaimPC.igtbl_TextBox_0_8.value = MakeCommaSeparate(row.getCellFromKey("ClaimCost").getValue());//�ݾ�
			
			//Ŭ��������
			for(var i=0;i<document.ClaimPC.UltraWebGrid1__ctl0_DropDownList1.options.length;i++)
			{
				if(document.ClaimPC.UltraWebGrid1__ctl0_DropDownList1.options[i].innerText == row.getCellFromKey("ClaimStatusMeaning").getValue())
				{
					document.ClaimPC.UltraWebGrid1__ctl0_DropDownList1.options[i].selected=true;
					break;
				}
				else
					document.ClaimPC.UltraWebGrid1__ctl0_DropDownList1.options[0].selected=true;
			}
			
			//Ŭ���ӿ���
			for(var i=0;i<document.ClaimPC.UltraWebGrid1__ctl0_DropDownList2.options.length;i++)
			{
				if(document.ClaimPC.UltraWebGrid1__ctl0_DropDownList2.options[i].innerText == row.getCellFromKey("ClaimCauseMeaning").getValue())
				{
					document.ClaimPC.UltraWebGrid1__ctl0_DropDownList2.options[i].selected=true;
					break;
				}
				else
					document.ClaimPC.UltraWebGrid1__ctl0_DropDownList2.options[0].selected=true;
			}
			
			//��������, ��������1,2,3
			var date = igdrp_getComboById("UltraWebGrid1xxctl0xwdcDate");
			date.setValue(objGrid.getCellFromKey("ReceiptDate").getValue());
			var mon = date.getValue().getMonth() + 1
			var year = date.getValue().getFullYear();			
			document.ClaimPC.hdYear.value = year;
			document.ClaimPC.hdMon.value = mon;			
		}
		
		
		// ����â�� �����鼭 ���� �׸��忡 �ѷ��ִ� �Լ�
		function UltraWebGrid1_AfterRowTemplateCloseHandler(gridName, rowId, bSaveChanges){
			if(event.srcElement.id == "igtbl_reOkBtn")
			{
				var frm = document.ClaimPC;
				var row = igtbl_getRowById(rowId);
				
				//������
				var date = igdrp_getComboById("UltraWebGrid1xxctl0xwdcDate");
				row.getCellFromKey("ReceiptDate").setValue(date.getValue());
				
				//ũ��������
				row.getCellFromKey("ClaimStatusCode").setValue(frm.UltraWebGrid1__ctl0_DropDownList1.options[frm.UltraWebGrid1__ctl0_DropDownList1.selectedIndex].value);
				row.getCellFromKey("ClaimStatusMeaning").setValue(frm.UltraWebGrid1__ctl0_DropDownList1.options[frm.UltraWebGrid1__ctl0_DropDownList1.selectedIndex].innerText);
				
				//ũ���ӿ���
				row.getCellFromKey("ClaimCauseCode").setValue(frm.UltraWebGrid1__ctl0_DropDownList2.options[frm.UltraWebGrid1__ctl0_DropDownList2.selectedIndex].value);
				row.getCellFromKey("ClaimCauseMeaning").setValue(frm.UltraWebGrid1__ctl0_DropDownList2.options[frm.UltraWebGrid1__ctl0_DropDownList2.selectedIndex].innerText);
				
			}
		}
		
		function OnKeyDown_Float(obj) 
		{   
			if (event.ctrlKey || event.shiftKey || event.altKey)   {
				SetEventPass();
				return true;
			}
			var sFieldValue = new String(obj.value);
			// ���ڰ˻� + Numeric Keypad ���ڰ˻�
			if( (event.keyCode<45 || event.keyCode>57) && (event.keyCode<96 || event.keyCode>105))  {
    			if( event.keyCode == 110 || event.keyCode == 190 ) {
    				// "." �� 2���ִ��� �˻�
	    			if( sFieldValue.indexOf(".") != -1 )	{
	    				SetEventCancel();
						return obj.value;
	    			}
				} else if( !IsNumericKey() ) {
	    			SetEventCancel();
					return obj.value;
				}	    
			} else {    
    			if( sFieldValue.indexOf(".") == -1 ) {
	    			// "0" �� �Է����� ��� "0" ������ "." �� �ƴϸ� �����Ͽ��� �Ѵ�.	
	    			// 48, 96(Numeric Keypad)
					if( sFieldValue.substr(0,1) == "0" && (event.keyCode == 48 || event.keyCode == 96) ) {
						SetEventCancel();
						return obj.value;
					}
				}
			}
			SetEventPass();
			return true;
		}

		function OnFocus_Obj(obj) {
			obj.select();
		}
		
		function OnBlur_Float(obj) {
			if (ValidateFloat(obj.value) == false) {
				obj.value = "";
    			return false;
			}
		}
		
		function ValidateFloat(a_sValue)	{	
			var s_FieldValue = new String(a_sValue);
			
			if (isNaN(s_FieldValue))
				return false;
				
			return true;
		}

//////////////////////////////////////////////////////////////////////////////////////////
//					Currency															//
//////////////////////////////////////////////////////////////////////////////////////////
		function OnKeyDown_Currency(obj) {   
			if (event.ctrlKey || event.shiftKey || event.altKey) {
				SetEventPass();
				return true;
			}
			var sFieldValue = new String(obj.value);        
			if( (event.keyCode<45 || event.keyCode>57) && (event.keyCode<96 || event.keyCode>105))	 {
    			if( event.keyCode == 110 || event.keyCode == 190 )	// "."(��) �̶��
    			{
    				// "." �� 2���ִ��� �˻�
	    			if( sFieldValue.indexOf(".") != -1 ) 	{
	    				SetEventCancel();
						return obj.value;
	    			}
				} else if( !IsCurrencyKey() ){
	    			SetEventCancel();
					return obj.value;
				}	    
			}	else	{    
    			if( sFieldValue.indexOf(".") == -1 )	{
	    			// "0" �� �Է����� ��� "0" ������ "." �� �ƴϸ� �����Ͽ��� �Ѵ�.	
	    			// 48, 96(Numeric Keypad)
					if( sFieldValue.substr(0,1) == "0" && (event.keyCode == 48 || event.keyCode == 96) )	{
						SetEventCancel();
						return obj.value;
					}
				}
			}
			SetEventPass();
			return true;
		}
		
		function OnKeyUp_Currency(obj)		{
			sFieldValue = new String(obj.value);
			sFieldValue = sFieldValue.replace(/,/gi,"");
			if ( IsNumericKey() )		{
				SetEventPass();
				return true;
			}
			obj.value = MakeCommaSeparate(sFieldValue);
		}
		
		function OnBlur_Cur(obj)	{
			if (ValidateCurrency(obj.value) == false) {
				obj.value = "";
    			return false;
			}
		}
		
		function ValidateCurrency( a_sValue ) {	
			var s_FieldValue = new String(a_sValue);
			
			if (isNaN(parseFloat(s_FieldValue)))
				return false;
				
			return true;
		}
		
		// OnKeyUp_Currency ���� ȣ���� �Ҽ��� ���
		function MakeCommaSeparate(a_Value)	{
			var fl = "";
			var nPointPos = 0;    
			
			if(isNaN(a_Value)) 	{ 
    			event.returnValue = false;
    			this.value = "";
    			return "";
			}
			
			if(a_Value == 0) return a_Value;
			
			if(a_Value < 0) { 
				a_Value=a_Value*(-1);
				fl = "-";
			}else if(a_Value == 0)	{
    			// ó�� �Է°��� 0���� �����Ҷ� �̰��� �����Ѵ�.
    			a_Value = a_Value*1; 
			}
			
			var a_Value = new String(a_Value);
			var temp = "";
			var sRemain = "";
			var co = 3;
			
			nPointPos = a_Value.indexOf(".");

			if( nPointPos == -1 )  {
    			num_len = a_Value.length;
			}else{
    			// "." �� ���ԵǾ� ���� ��쿡 ����
    			if( parseInt(a_Value.substr(0,nPointPos)) == 0 )	{
    				a_Value = "0" + a_Value.substr(nPointPos);
    				nPointPos = a_Value.indexOf(".");
    			}
    			num_len = nPointPos;
    			sRemain = a_Value.substr(nPointPos);
			}
			
			while (num_len>0)	{
				num_len = num_len - co;
				
				if(num_len<0)	{
        			co=num_len+co;
        			num_len=0;
				}
				temp = "," + a_Value.substr(num_len,co) + temp;
			}
			return fl + temp.substr(1) + sRemain;
		}
		
		function IsNumericKey()  {
			if (
				event.keyCode == 8 ||
				event.keyCode == 9 ||
				event.keyCode == 35 ||
				event.keyCode == 36 ||
				event.keyCode == 37 ||
				event.keyCode == 39 ||
				event.keyCode == 38 ||
				event.keyCode == 40 ||
				event.keyCode == 46 ||
				event.keyCode == 189 ||
				event.keyCode == 109 ||
				event.keyCode == 110 ||		// "."
				event.keyCode == 190			// Ű�е� "."
				)
    			return true;
			else
    			return false;
		}
							
		function SetEventPass() {
				event.cancelBubble = false;
				event.returnValue = true;
		}

		function SetEventCancel() {
				event.cancelBubble = true;
				event.returnValue = false;
		}
		
		
		
--></SCRIPT>
	</HEAD>
	<body style="FONT-SIZE: x-small" MS_POSITIONING="GridLayout" bgColor="#f7f6f6">
		<form id="ClaimPC" method="post" runat="server">
			<TABLE id="Table1" style="Z-INDEX: 101; LEFT: 10px; POSITION: absolute; TOP: 10px" height="550"
				cellSpacing="0" cellPadding="0" width="800" border="0">
				<TR>
					<TD vAlign="top" align="center" width="800"><FONT face="����">
							<FIELDSET style="BORDER-RIGHT: #696969 2px solid; BORDER-TOP: #696969 2px solid; BORDER-LEFT: #696969 2px solid; WIDTH: 800px; BORDER-BOTTOM: #696969 2px solid; HEIGHT: 48px"><LEGEND align="top">[�˻�����]</LEGEND>
								<TABLE id="Table2" style="HEIGHT: 28px" cellSpacing="0" cellPadding="0" width="800">
									<TR>
										<TD align="left" width="200" height="30" colSpan="2"><FONT face="����">
												<uc1:CompanySearchControl id="CSC1" runat="server"></uc1:CompanySearchControl></FONT>
										</TD>
										<TD width="600" colSpan="3" height="30">
											<uc1:ItemSearchControl id="ItemSearchControl1" runat="server"></uc1:ItemSearchControl></TD>
									</TR>
									<TR>
										<td colspan="5" width="800">
											<table id="t" cellpadding="0" cellspacing="0" border="0" width="800">
												<tr>
													<td width="70" height="30" align="right"><FONT face="����">������&nbsp; </FONT>
													</td>
													<td width="110" align="left"><igsch:webdatechooser id="wdcFromDate" runat="server" BorderStyle="Solid" BackColor="#EEEEE9" Height="20px"
															BorderColor="DimGray" Width="115px" Font-Size="9pt" Text=" " NullDateLabel=" ">
															<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
																ShowTitle="False" ShowFooter="False">
																<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
																<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
																<DropDownStyle BackColor="White"></DropDownStyle>
																<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
															</CalendarLayout>
															<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid"></DropDownStyle>
															<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
															<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
														</igsch:webdatechooser></td>
													<td width="10" align="center">~</td>
													<td width="150" align="left"><igsch:webdatechooser id="wdcToDate" runat="server" BorderStyle="Solid" BackColor="#EEEEE9" Height="20px"
															BorderColor="DimGray" Width="115px" Font-Size="9pt" Text=" " NullDateLabel=" ">
															<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
																ShowTitle="False" ShowFooter="False">
																<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
																<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
																<DropDownStyle BackColor="White"></DropDownStyle>
																<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
															</CalendarLayout>
															<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid"></DropDownStyle>
															<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
															<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
														</igsch:webdatechooser></td>
													<td align="right" width="460"><INPUT id="btnReset" style="WIDTH: 65px; HEIGHT: 20px" onclick="javascript:ResettxtBox()"
															type="button" value="�ʱ�ȭ" name="btnReset">&nbsp;
														<asp:button id="bt_Search" runat="server" Height="20px" Width="60px" Font-Size="10pt" Text="�˻�"></asp:button>&nbsp;</td>
												</tr>
											</table>
										</td>
									</TR>
								</TABLE>
							</FIELDSET>
						</FONT>
					</TD>
				</TR>
				<TR>
					<TD vAlign="top" align="center" width="800">
						<FIELDSET style="BORDER-RIGHT: #696969 2px solid; BORDER-TOP: #696969 2px solid; BORDER-LEFT: #696969 2px solid; WIDTH: 800px; BORDER-BOTTOM: #696969 2px solid; HEIGHT: 432px"><LEGEND align="top" style="FONT-SIZE: 9pt">[�˻����]</LEGEND>
							<TABLE id="Table4" cellSpacing="0" cellPadding="0" width="800">
								<tr>
									<td style="HEIGHT: 389px" colSpan="2"><igtbl:ultrawebgrid id="UltraWebGrid1" runat="server" Width="800px" Height="386px">
											<DisplayLayout StationaryMargins="Header" AutoGenerateColumns="False" AllowSortingDefault="Yes"
												RowHeightDefault="20px" Version="3.00" SelectTypeRowDefault="Single" AllowColumnMovingDefault="OnServer"
												HeaderClickActionDefault="SortMulti" BorderCollapseDefault="Separate" AllowColSizingDefault="Free"
												RowSelectorsDefault="No" Name="UltraWebGrid1" TableLayout="Fixed" CellClickActionDefault="RowSelect"
												AllowUpdateDefault="RowTemplateOnly">
												<AddNewBox>
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													</Style>
												</AddNewBox>
												<Pager PageSize="16" StyleMode="ComboBox" AllowPaging="True">
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													</Style>
												</Pager>
												<HeaderStyleDefault Cursor="Hand" BorderStyle="Solid" BackColor="Silver">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</HeaderStyleDefault>
												<RowSelectorStyleDefault Cursor="Hand" BackColor="#E0E5DE"></RowSelectorStyleDefault>
												<FrameStyle Width="800px" BorderWidth="1px" Font-Size="8pt" Font-Names="Verdana" BorderStyle="Solid"
													BackColor="Silver" Height="386px"></FrameStyle>
												<FooterStyleDefault BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</FooterStyleDefault>
												<ClientSideEvents ColumnHeaderClickHandler="UltraWebGrid1_ColumnHeaderClickHandler" AfterRowTemplateOpenHandler="UltraWebGrid1_AfterRowTemplateOpenHandler"
													AfterRowTemplateCloseHandler="UltraWebGrid1_AfterRowTemplateCloseHandler" MouseOverHandler="UltraWebGrid1_MouseOverHandler"></ClientSideEvents>
												<EditCellStyleDefault BorderWidth="0px" BorderStyle="None"></EditCellStyleDefault>
												<SelectedRowStyleDefault Cursor="Hand" ForeColor="White" BackColor="Navy"></SelectedRowStyleDefault>
												<RowAlternateStyleDefault Cursor="Hand" BackColor="LightSteelBlue"></RowAlternateStyleDefault>
												<RowStyleDefault Cursor="Hand" BorderWidth="1px" BorderColor="Gray" BorderStyle="Solid" BackColor="#EBEFF6">
													<Padding Left="3px"></Padding>
													<BorderDetails WidthLeft="0px" WidthTop="0px"></BorderDetails>
												</RowStyleDefault>
											</DisplayLayout>
											<Bands>
												<igtbl:UltraGridBand>
													<Columns>
														<igtbl:UltraGridColumn HeaderText="��ü" Key="chk" Width="30px" Type="CheckBox" HeaderClickAction="Select"
															BaseColumnName="chk" AllowUpdate="Yes">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center" Height="25px"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǰ���ȣ" Key="ItemNum" HeaderClickAction="SortMulti" BaseColumnName="ItemNum">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Left"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ȣ" Key="ItemDrawNum" HeaderClickAction="SortMulti" BaseColumnName="ItemDrawNum">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Left"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǰ���" Key="ItemName" HeaderClickAction="SortMulti" BaseColumnName="ItemName">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Left"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ŷ�ó��" Key="CompanyName" HeaderClickAction="SortMulti" BaseColumnName="CompanyName">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����ڵ�Ϲ�ȣ" Key="BusinessRegistrationNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="BusinessRegistrationNum">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������" Key="ReceiptDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="ReceiptDate">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Ŭ���Ӽ���" Key="ClaimQuantity" Format="###,###,###.##" HeaderClickAction="SortMulti"
															BaseColumnName="ClaimQuantity">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ݾ�" Key="ClaimCost" Format="\ ###,###,##0" HeaderClickAction="SortMulti"
															BaseColumnName="ClaimCost">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Ŭ���� ����" Key="ClaimStatusMeaning" HeaderClickAction="SortMulti" BaseColumnName="ClaimStatusMeaning">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Ŭ���� �����ڵ�" Key="ClaimStatusCode" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ClaimStatusCode">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Ŭ���� ����" Key="ClaimCauseMeaning" HeaderClickAction="SortMulti" BaseColumnName="ClaimCauseMeaning">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Ŭ���� �����ڵ�" Key="ClaimCauseCode" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ClaimCauseCode">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationPerson" HeaderClickAction="SortMulti" BaseColumnName="RegistrationPerson">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ID" Key="RegistrationPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationPersonID">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationDate">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������" Key="UpdatingPerson" HeaderClickAction="SortMulti" BaseColumnName="UpdatingPerson">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������ID" Key="UpdatingPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingPersonID">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������" Key="UpdatingDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingDate">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Right"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="��ȣ" Key="ClameHistoryIndex" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ClameHistoryIndex">
															<CellButtonStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellButtonStyle>
															<CellStyle VerticalAlign="Middle" HorizontalAlign="Center"></CellStyle>
															<HeaderStyle VerticalAlign="Middle" HorizontalAlign="Center"></HeaderStyle>
														</igtbl:UltraGridColumn>
													</Columns>
													<RowTemplateStyle BorderColor="White" BorderStyle="Ridge" BackColor="White">
														<BorderDetails WidthLeft="3px" WidthTop="3px" WidthRight="3px" WidthBottom="3px"></BorderDetails>
													</RowTemplateStyle>
													<RowEditTemplate>
														<P align="center">
															<TABLE id="Table3" style="HEIGHT: 80px" cellSpacing="0" cellPadding="0" width="800" border="0">
																<TR>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">ǰ���ȣ</FONT></TD>
																	<TD align="left"><FONT face="����"><INPUT id="igtbl_TextBox_0_1" style="WIDTH: 150px; BACKGROUND-COLOR: #eeeee9" readOnly
																				type="text" columnKey="ItemNum"></FONT></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">�����ȣ</FONT></TD>
																	<TD align="left"><FONT face="����"><INPUT id="igtbl_TextBox_0_2" style="WIDTH: 150px; BACKGROUND-COLOR: #eeeee9" readOnly
																				type="text" columnKey="ItemDrawNum"></FONT></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">ǰ���</FONT></TD>
																	<TD align="left"><INPUT id="igtbl_TextBox_0_3" style="WIDTH: 150px; BACKGROUND-COLOR: #eeeee9" readOnly
																			type="text" columnKey="ItemName"></TD>
																</TR>
																<TR>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">�ŷ�ó��</FONT></TD>
																	<TD align="left"><INPUT id="igtbl_TextBox_0_4" style="WIDTH: 150px; BACKGROUND-COLOR: #eeeee9" readOnly
																			type="text" columnKey="CompanyName"></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">Ŭ���Ӽ���</FONT></TD>
																	<TD align="left"><FONT face="����"><INPUT id="igtbl_TextBox_0_7" onkeydown="OnKeyDown_Float(this);" onkeyup="OnKeyUp_Currency(this);"
																				onblur="OnBlur_Cur(this);" onfocus="OnFocus_Obj(this);" style="TEXT-ALIGN: right; WIDTH: 150px; BACKGROUND-COLOR: #eeeee9"
																				type="text" columnKey="ClaimQuantity"></FONT></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">�ݾ�</FONT></TD>
																	<TD align="left"><FONT face="����"><INPUT id="igtbl_TextBox_0_8" onkeydown="OnKeyDown_Float(this);" onkeyup="OnKeyUp_Currency(this);"
																				onblur="OnBlur_Cur(this);" onfocus="OnFocus_Obj(this);" style="TEXT-ALIGN: right; WIDTH: 150px; BACKGROUND-COLOR: #eeeee9"
																				type="text" columnKey="ClaimCost"></FONT></TD>
																</TR>
																<TR>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">������</FONT></TD>
																	<TD align="left">
																		<igsch:WebDateChooser id="wdcDate" runat="server" NullDateLabel=" " Text="Null" Width="116px" BorderColor="DimGray"
																			Height="20px" BorderStyle="Solid">
																			<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
																				ShowTitle="False" ShowFooter="False">
																				<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
																				<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
																				<DropDownStyle BackColor="White"></DropDownStyle>
																				<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
																			</CalendarLayout>
																			<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid"></DropDownStyle>
																			<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
																			<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
																		</igsch:WebDateChooser></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small" face="����">Ŭ��������</FONT></TD>
																	<TD align="left">
																		<asp:DropDownList id=DropDownList1 runat="server" Width="142px" BackColor="#EEEEE9" columnKey="ClaimStatusMeaning" DataSource="<%# ClaimStatus %>" DataValueField="SmallClassificationCode" DataTextField="SmallClassificationName">
																		</asp:DropDownList></TD>
																	<TD align="right"><FONT style="FONT-SIZE: x-small; TEXT-ALIGN: right" face="����">Ŭ���ӿ���</FONT></TD>
																	<TD align="left">
																		<asp:DropDownList id=DropDownList2 runat="server" Width="151px" BackColor="#EEEEE9" columnKey="ClaimCauseMeaning" DataSource="<%# ClaimCause %>" DataValueField="SmallClassificationCode" DataTextField="SmallClassificationName">
																		</asp:DropDownList></TD>
																</TR>
															</TABLE>
														</P>
														<P align="center">&nbsp;</P>
														<P align="center"><FONT face="����"></FONT>&nbsp;</P>
														<P align="center"><FONT face="����"></FONT>&nbsp;</P>
														<P align="center"><FONT face="����"></FONT>&nbsp;</P>
														<P style="TEXT-ALIGN: center" align="center"><INPUT id="igtbl_reOkBtn" style="WIDTH: 50px" onclick="igtbl_gRowEditButtonClick(event);__doPostBack('lnk_Update','');"
																type="button" value="�� ��">&nbsp; <INPUT id="igtbl_reCancelBtn" style="WIDTH: 50px" onclick="igtbl_gRowEditButtonClick(event);"
																type="button" value="�� ��"></P>
													</RowEditTemplate>
												</igtbl:UltraGridBand>
											</Bands>
										</igtbl:ultrawebgrid></td>
								</tr>
								<TR>
									<TD style="WIDTH: 432px" height="30"><FONT face="����">&nbsp;</FONT><asp:button id="bt_Excel" runat="server" Width="60px" Height="20px" Text="Excel"></asp:button><INPUT id="lb_RowIndex" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" name="Hidden1"
											runat="server"><INPUT id="lb_RowSelectIndex" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" name="Hidden1"
											runat="server"><INPUT id="lb_Cost" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" name="Hidden1" runat="server"><INPUT id="hdYear" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" name="Hidden1" runat="server"><INPUT id="hdMon" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" name="Hidden1" runat="server"></TD>
									<TD align="right" height="30"><asp:linkbutton id="lnk_Update" runat="server"></asp:linkbutton><INPUT id="chkAll" style="WIDTH: 50px; HEIGHT: 20px" type="hidden" value="true">
										<asp:button id="bt_Delete" runat="server" Width="60px" Height="20px" Text="����"></asp:button>&nbsp;</TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
			</TABLE>
			<igtblexp:ultrawebgridexcelexporter id="UltraWebGridExcelExporter1" runat="server"></igtblexp:ultrawebgridexcelexporter></form>
	</body>
</HTML>
