using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// InferiorIndemnity�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InferiorIndemnity : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcDate;
		protected System.Web.UI.WebControls.TextBox tbQuantity;
		protected System.Web.UI.WebControls.TextBox tb_Cost;
		protected System.Web.UI.WebControls.Button bt_Delete;
		protected System.Web.UI.WebControls.Button bt_Update;
		protected System.Web.UI.WebControls.Button bt_Register;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_OldCost;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_Index;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected System.Web.UI.WebControls.DropDownList ddlInferiorStatus;
		protected System.Web.UI.WebControls.DropDownList ddlInferiorCause;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			ItemSearchControl1.HalfFinishedProducts=true;
			ItemSearchControl1.RawMaterials = true;
			CSC1.UnitCostDistinction = "���ſ���";
			
			if(Session["ID"] == null)
			{	
				//Session.Abandon();
				//Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Homepage/default.htm';</script>");
			}
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if(!Page.IsPostBack)
			{
				bt_Delete.Attributes.Add("onClick", "return OK('������ �׸��� ����');");
				
				tbQuantity.Attributes.Add("OnKeyDown", "OnKeyDown_Float(this);");
				tbQuantity.Attributes.Add("OnFocus", "OnFocus_Obj(this);");
				tbQuantity.Attributes.Add("OnBlur", "OnBlur_Float(this);");

				tb_Cost.Attributes.Add("OnKeyDown", "OnKeyDown_Float(this);");
				tb_Cost.Attributes.Add("OnFocus", "OnFocus_Obj(this);");
				tb_Cost.Attributes.Add("OnBlur", "OnBlur_Float(this);");
				

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
				conn.Open();


				/////////////////////////////////////////
				/// Ŭ���� ���� �ڵ� ����
				/////////////////////////////////////////
				string str = "SELECT SmallClassificationCode, SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '1000' and SmallClassificationName != '' order by SmallClassificationName";
				SqlCommand comm =  new SqlCommand(str,conn);
				SqlDataAdapter da = new SqlDataAdapter(comm) ;
				DataSet ds = new DataSet() ;
				da.Fill(ds,"Code");

				ddlInferiorStatus.DataSource = ds;
				ddlInferiorStatus.DataMember = "Code";
				ddlInferiorStatus.DataTextField = "SmallClassificationName";
				ddlInferiorStatus.DataValueField = "SmallClassificationCode";
				ddlInferiorStatus.DataBind();
				ddlInferiorStatus.Items.Insert(0, "---����---");
				ddlInferiorStatus.Items[0].Value = "";

				/////////////////////////////////////////
				/// Ŭ���� ���� �ڵ� ����
				/////////////////////////////////////////
				string str1 = "SELECT SmallClassificationCode, SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '1010' and SmallClassificationName != '' order by SmallClassificationName";
				SqlCommand comm1 =  new SqlCommand(str1,conn);
				SqlDataAdapter da1 = new SqlDataAdapter(comm1) ;
				DataSet ds1 = new DataSet() ;
				da1.Fill(ds1,"Code");

				ddlInferiorCause.DataSource = ds1;
				ddlInferiorCause.DataMember = "Code";
				ddlInferiorCause.DataTextField = "SmallClassificationName";
				ddlInferiorCause.DataValueField = "SmallClassificationCode";
				ddlInferiorCause.DataBind();
				ddlInferiorCause.Items.Insert(0, "---����---");
				ddlInferiorCause.Items[0].Value = "";


				wdcDate.NullDateLabel = DateTime.Now.ToShortDateString();


				conn.Close();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_Register.Click += new System.EventHandler(this.bt_Register_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_Register_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
