<%@ Register TagPrefix="igsch" Namespace="Infragistics.WebUI.WebSchedule" Assembly="Infragistics.WebUI.WebDateChooser.v1.2, Version=1.2.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="igcmbo" Namespace="Infragistics.WebUI.WebCombo" Assembly="Infragistics.WebUI.WebCombo.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="uc1" TagName="ItemSearchControl" Src="../Common/ItemSearchControl/ItemSearchControl.ascx" %>
<%@ Register TagPrefix="igtblexp" Namespace="Infragistics.WebUI.UltraWebGrid.ExcelExport" Assembly="Infragistics.WebUI.UltraWebGrid.ExcelExport.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Register TagPrefix="uc1" TagName="CompanySearchControl" Src="../Common/CompanySearchControl/CompanySearchControl.ascx" %>
<%@ Register TagPrefix="igtbl" Namespace="Infragistics.WebUI.UltraWebGrid" Assembly="Infragistics.WebUI.UltraWebGrid.v3.1, Version=3.1.20042.26, Culture=neutral, PublicKeyToken=7dd5c3163f2cd0cb" %>
<%@ Page language="c#" Codebehind="BuyingDeliveryPC.aspx.cs" AutoEventWireup="false" Inherits="KIT_ERP.BuyingOutside.BuyingDeliveryPC" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>BuyingDeliveryPC</title>
		<meta http-equiv="Content-Type" content="text/html; charset=ks_c_5601-1987">
		<meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
		<script language="javascript" src="../GridCheck.js"></script>
		<script language="javascript" src="../MessageWindows.js"></script>
		<LINK href="../StyleSheet2.css" type="text/css" rel="stylesheet">
		<SCRIPT type="text/javascript"><!--
		function ResettxtBox()
		{
			
			ResetTextBox();
			ResetBox();
			var objChooser1 = igdrp_getComboById("wdcStartDate");
			var objChooser2 = igdrp_getComboById("wdcEndDate");
			objChooser1.setValue(null);
			objChooser2.setValue(null);	
			document.Form1.ddlItemClassification1.options[0].selected=true;
		}
		
		function uwgBD_HT_BeforeRowTemplateOpenHandler(gridName, rowId, templateId)
		{
			var frm = document.Form1;
			var row = igtbl_getRowById(rowId);
			if((row.getCellFromKey("ProgressCondition").getValue() == "���") )
			{
				//�����ϱ� ������ ��ǰ����
				frm.hdquantity.value = row.getCellFromKey("DeliveryQuantity").getValue();
			}
			else
			{
				if(row.getCellFromKey("CheckDistinction").getValue() == '0')
				{
					frm.hdquantity.value = row.getCellFromKey("DeliveryQuantity").getValue();
				}
				else
				{
					alert("������°� �Ϸ��� �׸��� ������ �� �����ϴ�.!");
					return true;
				}
			}
			
			//���Գ⵵����
			for(var i=0;i<document.Form1.uwgBD_HT__ctl0_ddlYear.options.length;i++)
			{
				if(document.Form1.uwgBD_HT__ctl0_ddlYear.options[i].value == row.getCellFromKey("Year").getValue())
				{
					document.Form1.uwgBD_HT__ctl0_ddlYear.options[i].selected=true
				}
			}
			//���Կ� ����
			for(var i=0;i<document.Form1.uwgBD_HT__ctl0_ddlMon.options.length;i++)
			{
				if(document.Form1.uwgBD_HT__ctl0_ddlMon.options[i].value == row.getCellFromKey("Month").getValue())
				{
					
					document.Form1.uwgBD_HT__ctl0_ddlMon.options[i].selected=true
				}
			}
		}
		function uwgBD_HT_AfterRowTemplateOpenHandler(gridName, rowId){
			//Add code to handle your event here.
			
			var frm = document.Form1;
			var row = igtbl_getRowById(rowId);
			///////////RowIndex Hidden �� ����////////////////
			var num = rowId.split('_');
			document.Form1.hdRowIndex.value = num[1];
			/////////////////////////////////////////////////
			
			
			//���������
			var date1 = igdrp_getComboById("uwgBDxHTxxctl0xwdcInDate");
			if(row.getCellFromKey("DeliveryDate").getValue() !=null)
			{
					date1.setValue(row.getCellFromKey("DeliveryDate").getValue());
			}
			document.Form1.hdOldMonth.value = date1.getValue().getUTCMonth()+1;
			document.Form1.hdOldYear.value = date1.getValue().getFullYear();
			document.Form1.hdquantity.value = row.getCellFromKey("DeliveryQuantity").getValue();
			document.Form1.hdOldCost.value = row.getCellFromKey("TotalCost").getValue();
			document.Form1.hdyear.value = row.getCellFromKey("Year").getValue();
			document.Form1.hdmon.value = row.getCellFromKey("Month").getValue();
		}
		function uwgBD_HT_AfterRowTemplateCloseHandler(gridName, rowId, bSaveChanges){
			var row = igtbl_getRowById(rowId);
			var date1 = igdrp_getComboById("uwgBDxHTxxctl0xwdcInDate");			
			row.getCellFromKey("DeliveryDate").setValue(date1.getValue());
			document.Form1.hdReason.value = document.Form1.uwgBD_HT__ctl0_txtReason.value;
			
			row.getCellFromKey("Year").setValue(document.Form1.uwgBD_HT__ctl0_ddlYear.value);
			row.getCellFromKey("Month").setValue(document.Form1.uwgBD_HT__ctl0_ddlMon.value);			
		}
		function uwgBD_HT_ColumnHeaderClickHandler(gridName, columnId, button){
			GridName = gridName;
    			if(document.Form1.chkAll.value == "true")
    			{
					AllCheck();
				}
				else
				{
					AllUncheck();
				}
		}
		
		function AllCheck() // ���� üũ�ϱ�
		{
			var grid = igtbl_getGridById(GridName);
			
			for(var i=0; i<grid.Rows.length; i++)
			{
				var row = grid.Rows.getRow(i);
				row.getCellFromKey("chk").setValue(true);
			}
			document.Form1.chkAll.value = "false";
		}


		function AllUncheck() // ����üũ �����ϱ�
		{
			var grid = igtbl_getGridById(GridName);
			
			for(var i=0; i<grid.Rows.length; i++)
			{
				var row = grid.Rows.getRow(i);
				row.getCellFromKey("chk").setValue(false);
			}
			document.Form1.chkAll.value = "true";
		}
		
--></SCRIPT>
	</HEAD>
	<body bottomMargin="0" bgColor="#f7f6f6" leftMargin="0" topMargin="0" rightMargin="0"
		MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<TABLE id="Table1" style="POSITION: absolute; TOP: 10px; LEFT: 10px" cellSpacing="0" cellPadding="0"
				width="800" border="0">
				<TR>
					<TD style="HEIGHT: 92px"><FONT face="����"></FONT></TD>
					<TD style="WIDTH: 800px; HEIGHT: 92px" height="92">
						<FIELDSET style="BORDER-BOTTOM: dimgray 2px solid; BORDER-LEFT: dimgray 2px solid; WIDTH: 800px; HEIGHT: 20px; BORDER-TOP: dimgray 2px solid; BORDER-RIGHT: dimgray 2px solid"
							align="middle"><LEGEND style="FONT-SIZE: 10pt" align="left">[ �˻� ]
							</LEGEND>
							<TABLE id="Table3" cellSpacing="0" cellPadding="0" width="800" align="center" border="0">
								<TR height="35">
									<TD align="left" width="800" colSpan="8" height="30">
										<table id="table4" cellSpacing="0" cellPadding="0" width="800" align="center" border="0">
											<tr>
												<td style="HEIGHT: 24px" width="200"><uc1:companysearchcontrol id="CSC1" runat="server"></uc1:companysearchcontrol></td>
												<td style="HEIGHT: 24px" width="600"><uc1:itemsearchcontrol id="ItemSearchControl1" runat="server"></uc1:itemsearchcontrol></td>
											</tr>
										</table>
									</TD>
								</TR>
								<TR>
									<TD align="right" width="70" height="30">�԰�����&nbsp;</TD>
									<TD align="left" width="100" height="30"><igsch:webdatechooser id="wdcStartDate" runat="server" BorderColor="DimGray" Height="20px" BorderStyle="Solid"
											BackColor="#EEEEE9" Width="100px" Text=" " NullDateLabel=" ">
											<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
												ShowTitle="False" ShowFooter="False">
												<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
												<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
												<DropDownStyle BackColor="White"></DropDownStyle>
												<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
											</CalendarLayout>
											<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid" BackColor="#EEEEE9"></DropDownStyle>
											<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
											<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
										</igsch:webdatechooser></TD>
									<TD align="center" width="5" height="30">~</TD>
									<TD width="100" height="30"><igsch:webdatechooser id="wdcEndDate" runat="server" BorderColor="DimGray" Height="20px" BorderStyle="Solid"
											BackColor="#EEEEE9" Width="100px" Text=" " NullDateLabel=" ">
											<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
												ShowTitle="False" ShowFooter="False">
												<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
												<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
												<DropDownStyle BackColor="White"></DropDownStyle>
												<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
											</CalendarLayout>
											<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid" BackColor="#EEEEE9"></DropDownStyle>
											<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
											<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
										</igsch:webdatechooser></TD>
									<td align="right" width="70">��ǰ��&nbsp;</td>
									<td align="left" width="100"><asp:dropdownlist id="ddlItemClassification1" runat="server" BackColor="#EEEEE9" Width="115px"></asp:dropdownlist></td>
									<TD align="right" width="355" colSpan="2" height="30"><INPUT id="btnReset" style="WIDTH: 65px; HEIGHT: 20px" onclick="javascript:ResettxtBox()"
											type="button" value="�ʱ�ȭ" name="btnReset">&nbsp;
										<asp:button id="btnSearch" runat="server" Height="20px" Width="65px" Text="��   ��" Font-Size="9pt"></asp:button>&nbsp;
									</TD>
								</TR>
								<TR>
									<TD align="right" colSpan="8" height="8"></TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
				<TR>
					<TD style="HEIGHT: 400px" width="20"></TD>
					<TD style="WIDTH: 800px; HEIGHT: 400px" vAlign="top">
						<FIELDSET style="BORDER-BOTTOM: dimgray 2px solid; BORDER-LEFT: dimgray 2px solid; BORDER-TOP: dimgray 2px solid; BORDER-RIGHT: dimgray 2px solid"
							align="top"><LEGEND style="FONT-SIZE: 10pt" align="left">[ �˻���� ]
							</LEGEND>
							<TABLE id="Table4" height="400" cellSpacing="0" cellPadding="0" width="800" align="right">
								<TR>
									<TD vAlign="middle" align="center" height="400"><igtbl:ultrawebgrid id="uwgBD_HT" runat="server" Height="407px" Width="800px" UseAccessibleHeader="True">
											<DisplayLayout StationaryMargins="Header" AutoGenerateColumns="False" AllowSortingDefault="Yes"
												RowHeightDefault="20px" Version="3.00" SelectTypeRowDefault="Single" AllowColumnMovingDefault="OnServer"
												HeaderClickActionDefault="SortMulti" BorderCollapseDefault="Separate" AllowColSizingDefault="Free"
												RowSelectorsDefault="No" Name="uwgBDxHT" TableLayout="Fixed" CellClickActionDefault="RowSelect"
												NoDataMessage="�ش� ����Ÿ�� �����ϴ�." AllowUpdateDefault="RowTemplateOnly">
												<AddNewBox>
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">

<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White">
</BorderDetails>

													</Style>
												</AddNewBox>
												<Pager QuickPages="5" PageSize="17" StyleMode="ComboBox" AllowPaging="True">
													<Style BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">

<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White">
</BorderDetails>

													</Style>
												</Pager>
												<HeaderStyleDefault Cursor="Hand" BorderStyle="Solid" BackColor="LightGray" Height="25px">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</HeaderStyleDefault>
												<RowSelectorStyleDefault Cursor="Hand" BackColor="LightGray"></RowSelectorStyleDefault>
												<FrameStyle Width="800px" BorderWidth="1px" Font-Size="9pt" Font-Names="����" BorderColor="DimGray"
													BorderStyle="Solid" BackColor="Silver" Height="407px"></FrameStyle>
												<FooterStyleDefault BorderWidth="1px" BorderStyle="Solid" BackColor="LightGray">
													<BorderDetails ColorTop="White" WidthLeft="1px" WidthTop="1px" ColorLeft="White"></BorderDetails>
												</FooterStyleDefault>
												<ClientSideEvents ColumnHeaderClickHandler="uwgBD_HT_ColumnHeaderClickHandler" BeforeRowTemplateOpenHandler="uwgBD_HT_BeforeRowTemplateOpenHandler"
													AfterRowTemplateOpenHandler="uwgBD_HT_AfterRowTemplateOpenHandler" AfterRowTemplateCloseHandler="uwgBD_HT_AfterRowTemplateCloseHandler"></ClientSideEvents>
												<EditCellStyleDefault BorderWidth="0px" BorderStyle="None"></EditCellStyleDefault>
												<SelectedRowStyleDefault Cursor="Hand" BorderStyle="Dotted" ForeColor="White" BackColor="Navy"></SelectedRowStyleDefault>
												<RowAlternateStyleDefault Cursor="Hand" BackColor="LightSteelBlue"></RowAlternateStyleDefault>
												<RowStyleDefault Cursor="Hand" BorderWidth="1px" Font-Size="9pt" Font-Names="����" BorderColor="Gray"
													BorderStyle="Solid" BackColor="#EBEFF6">
													<Padding Left="3px"></Padding>
													<BorderDetails WidthLeft="0px" WidthTop="0px"></BorderDetails>
												</RowStyleDefault>
											</DisplayLayout>
											<Bands>
												<igtbl:UltraGridBand>
													<Columns>
														<igtbl:UltraGridColumn HeaderText="����" Key="chk" Width="30px" Type="CheckBox" HeaderClickAction="Select"
															BaseColumnName="" AllowUpdate="Yes">
															<CellStyle HorizontalAlign="Center"></CellStyle>
															<HeaderStyle Height="25px"></HeaderStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǰ���ȣ" Key="ItemNum" Width="150px" HeaderClickAction="SortMulti" BaseColumnName="ItemNum">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ȣ" Key="ItemDrawNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="ItemDrawNum">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǰ���" Key="ItemName" Width="150px" HeaderClickAction="SortMulti" BaseColumnName="ItemName">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����" Key="Unit" Width="35px" BaseColumnName="Unit">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�� ��" Key="Standard" BaseColumnName="Standard"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ȸ���̸�" Key="CompanyName" HeaderClickAction="SortMulti" BaseColumnName="CompanyName">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="����ڵ�Ϲ�ȣ" Key="BusinessRegistrationNum" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="BusinessRegistrationNum">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="NowStockQuantity" Width="70px" Format="###,###,###.##" BaseColumnName="NowStockQuantity">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�԰�����" Key="DeliveryQuantity" Width="70px" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="DeliveryQuantity">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�԰�����" Key="DeliveryDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="DeliveryDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="ǥ�شܰ�" Key="StandardUnitCost" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="StandardUnitCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ܰ�" Key="ApplyUnitCost" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="ApplyUnitCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="Lot��ȣ" Key="LotNum" Hidden="True" BaseColumnName="LotNum"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�ѱݾ�" Key="TotalCost" Format="###,###,##0.00" HeaderClickAction="SortMulti"
															BaseColumnName="TotalCost">
															<CellStyle HorizontalAlign="Right">
																<Padding Right="4px"></Padding>
															</CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�������" Key="ProgressCondition" HeaderClickAction="SortMulti" BaseColumnName="ProgressCondition">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationPerson" HeaderClickAction="SortMulti" BaseColumnName="RegistrationPerson">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����ID" Key="RegistrationPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationPersonID">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����" Key="RegistrationDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="RegistrationDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�˻���" Key="UpdatingPerson" HeaderClickAction="SortMulti" BaseColumnName="UpdatingPerson">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="������ID" Key="UpdatingPersonID" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingPersonID">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�˻���" Key="UpdatingDate" Format="yyyy-MM-dd" HeaderClickAction="SortMulti"
															BaseColumnName="UpdatingDate">
															<CellStyle HorizontalAlign="Center"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���Ź��ֿ����ȣ" Key="BuyingOrderHistoryIndex" HeaderClickAction="SortMulti"
															BaseColumnName="BuyingOrderHistoryIndex">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�����Ƿڳ�ǰ�����ȣ" Key="BuyingDeliveryRequestHistoryIndex" Hidden="True" HeaderClickAction="SortMulti"
															BaseColumnName="BuyingDeliveryRequestHistoryIndex">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���ų�ǰ�����ȣ" Key="BuyingDeliveryHistoryIndex" HeaderClickAction="SortMulti"
															BaseColumnName="BuyingDeliveryHistoryIndex">
															<CellStyle HorizontalAlign="Right"></CellStyle>
														</igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�԰���ⷮ" Key="InStoreWaitingQuantity" Hidden="True" BaseColumnName="InStoreWaitingQuantity"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="�˻翩��" Key="CheckDistinction" Hidden="True" BaseColumnName="CheckDistinction"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���Գ⵵" Key="Year" Width="60px" BaseColumnName="Year"></igtbl:UltraGridColumn>
														<igtbl:UltraGridColumn HeaderText="���Կ�" Key="Month" Width="50px" BaseColumnName="Month"></igtbl:UltraGridColumn>
													</Columns>
													<RowTemplateStyle BorderColor="White" BorderStyle="Ridge" BackColor="White">
														<BorderDetails WidthLeft="3px" WidthTop="3px" WidthRight="3px" WidthBottom="3px"></BorderDetails>
													</RowTemplateStyle>
													<RowEditTemplate>
														<FONT face="����">
															<P align="center"><FONT face="����">
																	<TABLE id="Table2" style="WIDTH: 700px" cellSpacing="1" cellPadding="1" width="700" border="0">
																		<TR>
																			<TD align="right"><FONT face="����">ǰ���ȣ:</FONT></TD>
																			<TD><FONT face="����">
																					<asp:TextBox id="txtItemNum" tabIndex="1" runat="server" Width="100px" Enabled="False" columnKey="ItemNum"></asp:TextBox></FONT></TD>
																			<TD align="right"><FONT face="����">�����ȣ:</FONT></TD>
																			<TD><FONT face="����">
																					<asp:TextBox id="txtItemDrawNum" runat="server" Width="100px" Enabled="False" columnKey="ItemDrawNum"></asp:TextBox></FONT></TD>
																			<TD align="right"><FONT face="����">ǰ���:</FONT></TD>
																			<TD>
																				<asp:TextBox id="txtItemName" runat="server" Width="100px" Enabled="False" columnKey="ItemName"></asp:TextBox></TD>
																			<TD align="right">�԰�����:&nbsp;
																			</TD>
																			<TD>
																				<igsch:webdatechooser id="wdcInDate" runat="server" NullDateLabel=" " Text=" " Width="100px" BackColor="#EEEEE9"
																					BorderStyle="Solid" Height="20px" BorderColor="DimGray">
																					<CalendarLayout DayNameFormat="FirstLetter" FooterFormat="Today: {0:d}" ShowNextPrevMonth="False"
																						ShowTitle="False" ShowFooter="False">
																						<SelectedDayStyle ForeColor="White" BackColor="#0A246A"></SelectedDayStyle>
																						<OtherMonthDayStyle ForeColor="White"></OtherMonthDayStyle>
																						<DropDownStyle BackColor="White"></DropDownStyle>
																						<DayHeaderStyle ForeColor="#D4D0C8" BackColor="Gray"></DayHeaderStyle>
																					</CalendarLayout>
																					<DropDownStyle BorderWidth="1px" BorderColor="DimGray" BorderStyle="Solid" BackColor="#EEEEE9"></DropDownStyle>
																					<DropButton ImageUrl2="/ig_common/webschedule1/ig_cmboDown2.bmp" ImageUrl1="/ig_common/webschedule1/ig_cmboDown1.bmp"></DropButton>
																					<ExpandEffects ShadowColor="LightGray"></ExpandEffects>
																				</igsch:webdatechooser></TD>
																		</TR>
																		<TR>
																			<TD align="right"><FONT face="����">��ǰ��:</FONT></TD>
																			<TD>
																				<asp:TextBox id="txtDeliveryQuantity" style="TEXT-ALIGN: right" runat="server" Width="100px"
																					columnKey="DeliveryQuantity"></asp:TextBox></TD>
																			<TD align="right">��&nbsp; ��&nbsp;:</TD>
																			<TD><FONT face="����">
																					<asp:TextBox id="txtCost" style="TEXT-ALIGN: right" runat="server" Width="100px" columnKey="ApplyUnitCost"></asp:TextBox></FONT></TD>
																			<TD align="right"><FONT face="����">����:</FONT></TD>
																			<TD><INPUT id="txtReason" style="WIDTH: 100px" type="text" runat="server"></TD>
																			<TD align="right">Lot ��ȣ :&nbsp;
																			</TD>
																			<TD>
																				<asp:TextBox id="txtLot" runat="server" Width="100px" columnKey="LotNum"></asp:TextBox></TD>
																		</TR>
																		<TR>
																			<TD align="right"><FONT face="����">���Գ⵵:</FONT></TD>
																			<TD>
																				<asp:DropDownList id="ddlYear" runat="server" columnKey="[Year]">
																					<asp:ListItem Value="2019">2019</asp:ListItem>
																					<asp:ListItem Value="2020">2020</asp:ListItem>
																					<asp:ListItem Value="2021">2021</asp:ListItem>
																					<asp:ListItem Value="2022">2022</asp:ListItem>
																					<asp:ListItem Value="2023">2023</asp:ListItem>
																					<asp:ListItem Value="2024">2024</asp:ListItem>
																					<asp:ListItem Value="2025">2025</asp:ListItem>
																					<asp:ListItem Value="2026">2026</asp:ListItem>
																					<asp:ListItem Value="2027">2027</asp:ListItem>
																					<asp:ListItem Value="2028">2028</asp:ListItem>
																					<asp:ListItem Value="2029">2029</asp:ListItem>
																				</asp:DropDownList></TD>
																			<TD align="right">��&nbsp;��&nbsp;��&nbsp;:</TD>
																			<TD>
																				<asp:DropDownList id="ddlMon" runat="server" columnKey="[Month]">
																					<asp:ListItem Value="1">1��</asp:ListItem>
																					<asp:ListItem Value="2">2��</asp:ListItem>
																					<asp:ListItem Value="3">3��</asp:ListItem>
																					<asp:ListItem Value="4">4��</asp:ListItem>
																					<asp:ListItem Value="5">5��</asp:ListItem>
																					<asp:ListItem Value="6">6��</asp:ListItem>
																					<asp:ListItem Value="7">7��</asp:ListItem>
																					<asp:ListItem Value="8">8��</asp:ListItem>
																					<asp:ListItem Value="9">9��</asp:ListItem>
																					<asp:ListItem Value="10">10��</asp:ListItem>
																					<asp:ListItem Value="11">11��</asp:ListItem>
																					<asp:ListItem Value="12">12��</asp:ListItem>
																				</asp:DropDownList></TD>
																			<TD colSpan="4"></TD>
																		</TR>
																		<TR height="200">
																			<TD colSpan="8"></TD>
																		</TR>
																		<TR>
																			<TD align="center" colSpan="8"><INPUT id="igtbl_reOkBtn" style="WIDTH: 60px" onclick="igtbl_gRowEditButtonClick(event);__doPostBack('linkUpdate','');"
																					type="button" value="��   ��">&nbsp;</TD>
																		</TR>
																	</TABLE>
																</FONT>
															</P>
														</FONT>
													</RowEditTemplate>
												</igtbl:UltraGridBand>
											</Bands>
										</igtbl:ultrawebgrid></TD>
								</TR>
							</TABLE>
						</FIELDSET>
					</TD>
				</TR>
				<TR>
					<TD width="20"></TD>
					<TD>
						<TABLE id="Table6" style="HEIGHT: 20px" cellSpacing="0" cellPadding="0" width="100%">
							<TR>
								<TD style="WIDTH: 100px" align="left" height="10"></TD>
								<TD style="WIDTH: 514px" align="right" height="10"></TD>
								<TD style="WIDTH: 60px" align="right" height="10"></TD>
								<TD style="WIDTH: 203px" align="right" height="10"></TD>
							</TR>
							<TR>
								<TD style="WIDTH: 100px" align="left"><asp:button id="btnExcel" runat="server" Height="20px" Width="65px" Text="Excel" Font-Size="9pt"></asp:button></TD>
								<TD align="right"><INPUT id="chkAll" style="WIDTH: 48px; HEIGHT: 22px" type="hidden" size="2" value="true"
										name="chkAll"><INPUT id="hdmon" style="WIDTH: 21px; HEIGHT: 21px" type="hidden" size="1" name="hdOldMonth"
										runat="server"><INPUT id="hdyear" style="WIDTH: 21px; HEIGHT: 21px" type="hidden" size="1" name="hdOldYear"
										runat="server"><INPUT id="hdOldCost" style="WIDTH: 18px; HEIGHT: 21px" type="hidden" size="1" name="hdOldYear"
										runat="server"><INPUT id="hdReason" style="WIDTH: 18px; HEIGHT: 21px" type="hidden" size="1" name="hdOldYear"
										runat="server"><INPUT id="hdOldYear" style="WIDTH: 22px; HEIGHT: 21px" type="hidden" size="1" name="hdOldYear"
										runat="server"><INPUT id="hdOldMonth" style="WIDTH: 21px; HEIGHT: 21px" type="hidden" size="1" name="hdOldMonth"
										runat="server">&nbsp;<INPUT id="hdquantity" style="WIDTH: 22px; HEIGHT: 21px" type="hidden" size="1" name="Hidden1"
										runat="server"><INPUT id="hdRowIndex" style="WIDTH: 24px; HEIGHT: 21px" type="hidden" size="1" name="Hidden1"
										runat="server">
									<asp:linkbutton id="linkUpdate" runat="server" Visible="False">linkUpdate</asp:linkbutton><asp:literal id="Literal1" runat="server"></asp:literal></TD>
								<TD align="right" colSpan="2"><asp:button id="btnCancel" runat="server" Height="20px" Width="65px" Text="��   ��" Font-Size="9pt"></asp:button>&nbsp;
									<asp:button id="btnStop" runat="server" Height="20px" Width="65px" Text="��   ��" Font-Size="9pt"></asp:button></TD>
							</TR>
						</TABLE>
						<igtblexp:ultrawebgridexcelexporter id="uwgExcel" runat="server"></igtblexp:ultrawebgridexcelexporter></TD>
				</TR>
			</TABLE>
			&nbsp;
			<P align="center"><FONT face="����"></FONT>&nbsp;</P>
		</form>
	</body>
</HTML>
