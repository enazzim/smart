using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Infragistics.WebUI.WebCombo;
using System.Configuration;
using Microsoft.Win32;
using Infragistics.WebUI;
using Infragistics.WebUI.UltraWebGrid;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// BuyingOrderPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BuyingOrderPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgBO_HT;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Button btnPre;
		protected System.Web.UI.WebControls.Button btnNow;
		protected System.Web.UI.WebControls.Button btnNext;
		protected System.Web.UI.HtmlControls.HtmlInputHidden BuyingOrderHistoryIndex;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;	
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;	
		private static int Division;		
		private DataSet ds;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Volum;
		protected System.Web.UI.WebControls.Button btEnd;
		protected System.Web.UI.WebControls.Button btEndCancel;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button btnStop;
		protected System.Web.UI.WebControls.Button btnCancle;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected System.Web.UI.WebControls.DropDownList ddlState;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
	

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			ItemSearchControl1.RawMaterials = true; //������ ���ε�
			ItemSearchControl1.Commodity = true;	//��ǰ ���ε�
			CSC1.UnitCostDistinction="���Űŷ�ó";
			if(!Page.IsPostBack)
			{


				// �ߴܹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnStop.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ���ָ� �ߴ� �Ͻðڽ��ϱ�?');");
				// ��ҹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnCancle.Attributes.Add("onClick","return Confirm('���ָ� ��� �Ͻðڽ��ϱ�?');");
				// ������ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnDelete.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ������ �Ͻðڽ��ϱ�?');");
			
				FirstBind();
				

				Volnum();
			}			
			//�׸��忡 �׸��� ���� ���� ��ҹ�ư ��Ȱ��ȭ
			if(uwgBO_HT.Rows.Count == 0)
				btnCancle.Enabled = false;
		}

		private void FirstBind()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
			//	*************************************************
			//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
			//	*************************************************
			//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
			string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
			SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
			SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
			DataSet ds_ItemClassification1 = new DataSet() ;
			da_ItemClassification1.Fill(ds_ItemClassification1);
				
			ddlItemClassification1.DataSource = ds_ItemClassification1;
			ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
			ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
			ddlItemClassification1.DataBind();
			ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
			ddlItemClassification1.Items[0].Value = "";
		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e); 
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{     
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.btnPre.Click += new System.EventHandler(this.btnPre_Click);
			this.btnNow.Click += new System.EventHandler(this.btnNow_Click);
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			this.uwgBO_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgBO_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.btEnd.Click += new System.EventHandler(this.btEnd_Click);
			this.btEndCancel.Click += new System.EventHandler(this.btEndCancel_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		
		


		// ���Ź��ֿ��忡�� �˻����ǿ� �ش��ϴ� ǰ����� �˻�
		private void btnSearch_Click(object sender, System.EventArgs e)
		{	
			uwgBO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
			uwgBO_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgBO_HT.DataSource = Search();
			this.uwgBO_HT.DataBind();

			Division = 0;
			btnCancle.Enabled = false;

		}

		//Excel�� ������
		private void btnExcel_Click(object sender, System.EventArgs e)
		{

			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgBO_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;

			if(Division == 0)
			{
				uwgBO_HT.DataSource = Search();
			}
			else
			{
				VideoButton vol = new VideoButton(uwgBO_HT,"BuyingOrderPC",Volum.Value);
				uwgBO_HT.DataSource = vol.FindVolum();
			}

			uwgExcelImport.DataBind();
			
			uwgExcel.Export(uwgExcelImport);
		}

		//�ߴܹ�ư�� Ŭ��
		private void btnStop_Click(object sender, System.EventArgs e)
		{
			if(this.uwgBO_HT.Rows.Count ==0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('�ߴ��� ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				KIT_ERP.Stop stop = new KIT_ERP.Stop(uwgBO_HT, "BuyingOrderPC", Session["ID"].ToString());
				stop.MainTableStop();
				
				if(Division == 0)
				{
					uwgBO_HT.DataSource =Search();
				}
				else
				{
					VideoButton video = new VideoButton(uwgBO_HT,"BuyingOrderPC", Volum.Value);
					uwgBO_HT.DataSource = video.FindVolum();
				}
				uwgBO_HT.DataBind();			
			}			
					
			
		}

		//������ư�� Ŭ��
		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			if(this.uwgBO_HT.Rows.Count ==0)
			{				
				Response.Write("<script language=javascript>");
				Response.Write("alert('������ ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				KIT_ERP.Delete delete = new KIT_ERP.Delete(uwgBO_HT,"BuyingOrderPC");
				delete.MainRowDelete();

				if(Division == 0)
				{
					uwgBO_HT.DataSource = Search();
				}
				else
				{
					VideoButton video = new VideoButton(uwgBO_HT,"BuyingOrderPC", Volum.Value);
					uwgBO_HT.DataSource = video.FindVolum();
				}
				uwgBO_HT.DataBind();						
			}			
		}

		//��ҹ�ư�� Ŭ��
		private void btnCancle_Click(object sender, System.EventArgs e)
		{
			if(this.uwgBO_HT.Rows.Count ==0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('����� ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
//				Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgCancle = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
//				uwgCancle = uwgBO_HT;
//				uwgCancle.DisplayLayout.Pager.AllowPaging = false;

				uwgBO_HT.DisplayLayout.Pager.AllowPaging = false;
				VideoButton aa = new VideoButton(uwgBO_HT,"BuyingOrderPC", Volum.Value);
				uwgBO_HT.DataSource = aa.FindVolum();
				uwgBO_HT.DataBind();
				// ��Ұ�ü ����
				KIT_ERP.Cancel cancle = new KIT_ERP.Cancel(uwgBO_HT, "BuyingOrderPC", Volum.Value);
				cancle.MainRowCancel();
				Volnum();
				uwgBO_HT.DisplayLayout.Pager.AllowPaging = true;
				VideoButton video = new VideoButton(uwgBO_HT,"BuyingOrderPC", Volum.Value);
				uwgBO_HT.DataSource = video.FindVolum();
				uwgBO_HT.DataBind();
					
			}
		}
		
		//�׸��� Paging
		private void uwgBO_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgBO_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			uwgBO_HT.DataSource =  Search();
			uwgBO_HT.DataBind();
		}

		/// <summary>
		/// ������ȣ ã�� �Լ�
		/// </summary>
		/// <returns></returns>
		private void Volnum()
		{
			///////////////////////////////////////
			// ������ư�� ����
			// Volum�� ������ȣ �ְ����� �־�д�.
			//////////////////////////////////////
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();	
			string str_Vol = "Select Max(VolumNum) From BO_HT";
			SqlCommand comm_Vol = new SqlCommand(str_Vol,conn);
			if(!Convert.IsDBNull(comm_Vol.ExecuteScalar()))
				Volum.Value = Convert.ToString(comm_Vol.ExecuteScalar());
			else
				Volum.Value = "0";
			conn.Close();

			if(Volum.Value == "0")
			{
				btnNext.Enabled = false;
				btnPre.Enabled = false;
			}
		}

		/// <summary>
		/// ������ư Ŭ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnPre_Click(object sender, System.EventArgs e)
		{
			uwgBO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancle.Enabled = true;
			vol_Pre();

			VideoButton vol = new VideoButton(uwgBO_HT,"BuyingOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgBO_HT.DataSource = ds;
			uwgBO_HT.DataBind();
			Division = 1;
		}


		/// <summary>
		/// ��� ������ư
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNow_Click(object sender, System.EventArgs e)
		{
			uwgBO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancle.Enabled = true;
			vol_Now();
			VideoButton vol = new VideoButton(uwgBO_HT,"BuyingOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgBO_HT.DataSource = ds;
			uwgBO_HT.DataBind();
			Volnum();
			Division = 1;
		}

		/// <summary>
		/// ������ư Ŭ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNext_Click(object sender, System.EventArgs e)
		{
			uwgBO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.No;
			btnCancle.Enabled = true;
			vol_Next();
			
			VideoButton vol = new VideoButton(uwgBO_HT,"BuyingOrderPC",Volum.Value);
			ds = vol.FindVolum();
			uwgBO_HT.DataSource = ds;
			uwgBO_HT.DataBind();
			Division = 1;
		}


		/// <summary>
		/// ������Ǿ��ȣ ã�� �Լ�
		/// </summary>
		private void vol_Pre()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Max(VolumNum) as VolumNum From BO_HT where VolumNum < @num";
			comm.Parameters.Add("@num",SqlDbType.Int).Value = int.Parse(Volum.Value);
							
			if(comm.ExecuteScalar() != Convert.DBNull)
			{
				SqlDataReader dr = comm.ExecuteReader();
				if(dr.Read())
					Volum.Value = dr["VolumNum"].ToString();
			}
			else
			{
				RegisterStartupScript("","<script>alert('�� ó���Դϴ�!')</script>");
				btnPre.Enabled = false;
				btnNext.Enabled = true;
			}
			
			conn.Close();	
			
			
		}

		/// <summary>
		/// ���� ������ȣ ã�� �Լ�
		/// </summary>
		private void vol_Now()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Max(VolumNum) as VolumNum From BO_HT";
							
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
				Volum.Value = dr["VolumNum"].ToString();
			dr.Close();

			if(Volum.Value == "")
			{
				RegisterStartupScript("","<script>alert('������ȣ�� �����ϴ�!')</script>");
				Volum.Value = "0";
				btnCancle.Enabled = false;
				btnPre.Enabled = false;
				btnNext.Enabled = false;
			}
			else
			{			
				btnPre.Enabled = true;
				btnNext.Enabled = true;
			}
			conn.Close();
		}

		/// <summary>
		/// ���ĺ�����ȣ ã�� �Լ�
		/// </summary>
		private void vol_Next()
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = "Select Min(VolumNum) as VolumNum From BO_HT where VolumNum > @num";
			comm.Parameters.Add("@num",SqlDbType.Int).Value = int.Parse(Volum.Value);
							
			if(comm.ExecuteScalar() != Convert.DBNull)
			{
				SqlDataReader dr = comm.ExecuteReader();
				if(dr.Read())
					Volum.Value = dr["VolumNum"].ToString();
			}
			else
			{
				RegisterStartupScript("","<script>alert('�� ���Դϴ�!');</script>");
				btnPre.Enabled = true;
				btnNext.Enabled = false;
			}
			
			conn.Close();	
			
		}

		//������ ������ DataBase�� Update
		private void linkUpdate_Click(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			
			try
			{			
				BO_HT_Update(conn,tr); //���ֿ��� �����ϴ� �Լ�
				
				tr.Commit();
				Response.Write("<script language=javascript>");
				Response.Write("alert('�����Ǿ����ϴ�!');");
				Response.Write("</script>");
			}
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();
			}
		}

		//���Ź��ֿ��� �����ϴ� �Լ�
		private void BO_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			//���� ���Ź��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
			int rowcount = int.Parse(hdRowIndex.Value);

			string str =" UPDATE BO_HT SET " +
				" FirstDeliveryDemandQuantity = @firstorderquantity,FirstDeliveryDemandDate=@firstdate,"+
				" SecondDeliveryDemandQuantity=@secondorderquantity ,SecondDeliveryDemandDate=@seconddate, " +
				" ThirdDeliveryDemandQuantity=@thirdorderquantity ,ThirdDeliveryDemandDate=@thirddate, " +
				" FourthDeliveryDemandQuantity=@fourthorderquantity ,FourthDeliveryDemandDate=@fourthdate, " +
				" FifthDeliveryDemandQuantity=@fifthorderquantity ,FifthDeliveryDemandDate=@fifthdate, " +
				" ApplyUnitCost = @applyunitcost,TotalCost = @totalcost, " +
				" OrderQuantity = @orderquantity, RemainQuantity = @requantity, "+
				" UpdatingPerson = @person,"+
				" UpdatingPersonID = @personid, "+
				" UpdatingDate = @date "+
				"WHERE BuyingOrderHistoryIndex= @INDEX ";
		
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@firstorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FirstDeliveryDemandQuantity").Value.ToString());
			comm.Parameters.Add("@firstdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FirstDeliveryDemandDate").Value.ToString());
			comm.Parameters.Add("@secondorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandQuantity").Value.ToString());
						
			if(uwgBO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value == null || uwgBO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@seconddate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
			comm.Parameters.Add("@seconddate", SqlDbType.DateTime).Value = DateTime.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("SecondDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			
			comm.Parameters.Add("@thirdorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandQuantity").Value.ToString());
			
			if(uwgBO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value == null || uwgBO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@thirddate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
			comm.Parameters.Add("@thirddate", SqlDbType.DateTime).Value = DateTime.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("ThirdDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			
			comm.Parameters.Add("@fourthorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandQuantity").Value.ToString());
			
			if(uwgBO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value == null || uwgBO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@fourthdate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
			comm.Parameters.Add("@fourthdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FourthDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
		
			comm.Parameters.Add("@fifthorderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandQuantity").Value.ToString());
			
			if(uwgBO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value == null || uwgBO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value.ToString().Trim() == "")
				comm.Parameters.Add("@fifthdate", SqlDbType.DateTime).Value = Convert.DBNull;
			else
				comm.Parameters.Add("@fifthdate", SqlDbType.DateTime).Value = DateTime.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("FifthDeliveryDemandDate").Value.ToString()).ToShortDateString();
			
			comm.Parameters.Add("@applyunitcost", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm.Parameters.Add("@totalcost", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("TotalCost").Value.ToString());
			
			comm.Parameters.Add("@orderquantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("OrderQuantity").Value.ToString());
			comm.Parameters.Add("@requantity", SqlDbType.Decimal).Value = decimal.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("OrderQuantity").Value.ToString());
		
			comm.Parameters.Add("@person", SqlDbType.VarChar).Value = Session["UserName"].ToString();
			comm.Parameters.Add("@personid", SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm.Parameters.Add("@date", SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();

			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(uwgBO_HT.Rows[rowcount].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());
						
			comm.ExecuteNonQuery();	
		}

		//�Ϸ��ư Ŭ��
		private void btEnd_Click(object sender, System.EventArgs e)
		{
			if ( this.SelectedRow_IsEnd() )
			{
				bool bRowRegist = false;
			
			
				for( int i = 0 ; i < uwgBO_HT.Rows.Count ; i ++)
				{
					if (Convert.ToBoolean( uwgBO_HT.Rows[i].Cells.FromKey("chk").Value ))
					{
						int index = int.Parse(uwgBO_HT.Rows[i].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());		// �����ε���
					
						DB_End( index ) ;
					

						bRowRegist = true;
					}
				}
				if ( bRowRegist )
				{
					Response.Write("<script>alert('�Ϸ� �Ǿ����ϴ�.')</script>");
					
					uwgBO_HT.DataSource = Search();
					uwgBO_HT.DataBind();
				}
				else
					Response.Write("<script>alert('���õ� ǰ���� �����ϴ�.')</script>");
			}
			else
			{
				Response.Write("<script>alert('���� �׸�� �� ������°� �Ϸ��Ҽ� ���� �׸��� �ֽ��ϴ�!')</script>");
			}
		}

		/// <summary>
		/// �Ϸ��Ҽ� �ִ� �׸��� �ִ��� �ľ��ϴ� �Լ�
		/// </summary>
		/// <returns>üũ�� �׸�� �߿� ������°� �ߴܵǾ��ų� �Ϸ�Ȱ��� �Ϸ��� �� ����. �׷��Ƿ� false�� �����Ѵ�</returns>
		private bool SelectedRow_IsEnd()
		{
			bool bReturnValue = true;

			for( int i = 0 ; i < uwgBO_HT.Rows.Count ; i ++)
			{
				if (Convert.ToBoolean( uwgBO_HT.Rows[i].Cells.FromKey("chk").Value ) 
					&& (uwgBO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() == "�ߴ�" || uwgBO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() == "�Ϸ�"))
				{
					bReturnValue = false;
					break;
				}
			}
			return bReturnValue;
		}

		/// <summary>
		/// DB�� ������¸� �Ϸ����� ������Ų��
		/// </summary>
		/// <param name="idx"></param>
		private void DB_End(int idx)
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = con;
			try
			{
				con.Open();
				
				string str = "Update BO_HT Set ProgressCondition = '�Ϸ�', UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where BuyingOrderHistoryIndex = @BuyingOrderHistoryIndex";
				
				cmd.Transaction = con.BeginTransaction();
				cmd.CommandText = str;
				cmd.Parameters.Add("@BuyingOrderHistoryIndex", idx);
				cmd.Parameters.Add("@Person", Session["UserName"].ToString());
				cmd.Parameters.Add("@PersonID", Session["ID"].ToString());
				cmd.Parameters.Add("@date", DateTime.Now.ToShortDateString());
				cmd.ExecuteNonQuery();
				cmd.Transaction.Commit();
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				cmd.Transaction.Rollback();
			}
			finally
			{
				con.Close();
			}
		}

		private void btEndCancel_Click(object sender, System.EventArgs e)
		{
			if ( this.SelectedRow_IsEndCancle() )
			{
				bool bRowRegist = false;
			
			
				for( int i = 0 ; i < uwgBO_HT.Rows.Count ; i ++)
				{
					if (Convert.ToBoolean( uwgBO_HT.Rows[i].Cells.FromKey("chk").Value ))
					{
						int index = int.Parse(uwgBO_HT.Rows[i].Cells.FromKey("BuyingOrderHistoryIndex").Value.ToString());		// �����ε���
					
						DB_EndCancle( index ) ;
					

						bRowRegist = true;
					}
				}
				if ( bRowRegist )
				{
					Response.Write("<script>alert('�Ϸ���� �Ǿ����ϴ�.')</script>");
			
					uwgBO_HT.DataSource = Search();
					uwgBO_HT.DataBind();
				}
				else
					Response.Write("<script>alert('���õ� ǰ���� �����ϴ�.')</script>");
			}
			else
			{
				Response.Write("<script>alert('���� �׸�� �� ������°� �Ϸᰡ �ƴ� �׸��� �־� ����� �� �����ϴ�!')</script>");
			}
		}


		/// <summary>
		/// �Ϸ�����Ҽ� �ִ� �׸��� �ִ��� �ľ��ϴ� �Լ�
		/// </summary>
		/// <returns>üũ�� �׸�� �߿� ������°� �Ϸ�Ȱ���̿ܿ��� ����� �� ����. �׷��Ƿ� false�� �����Ѵ�</returns>
		private bool SelectedRow_IsEndCancle()
		{
			bool bReturnValue = true;

			for( int i = 0 ; i < uwgBO_HT.Rows.Count ; i ++)
			{
				if (Convert.ToBoolean( uwgBO_HT.Rows[i].Cells.FromKey("chk").Value) == true 
					&& uwgBO_HT.Rows[i].Cells.FromKey("ProgressCondition").Value.ToString() != "�Ϸ�")
				{
					bReturnValue = false;
					break;
				}
			}
			return bReturnValue;
		}

		/// <summary>
		/// DB�� ������¸� ����Ǵ� ���÷� �����Ų��
		/// </summary>
		/// <param name="idx"></param>
		private void DB_EndCancle(int idx)
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			decimal order = 0;
			decimal remain = 0;
			string str  = @"select OrderQuantity,RemainQuantity From BO_HT Where BuyingOrderHistoryIndex = @BuyingOrderHistoryIndex ";
			SqlCommand cmd = new SqlCommand();
			cmd.CommandText = str;
			cmd.Connection = con;
			con.Open();
			cmd.Parameters.Add("@BuyingOrderHistoryIndex", idx);
			SqlDataReader dr = cmd.ExecuteReader();
			while(dr.Read())
			{
				order = decimal.Parse(dr["OrderQuantity"].ToString());
				remain = decimal.Parse(dr["RemainQuantity"].ToString());
			}
			con.Close();

			if(order - remain == 0 || order - (order - remain) < 0 )
				str = "Update BO_HT Set ProgressCondition = '���',UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where BuyingOrderHistoryIndex = @BuyingOrderHistoryIndex ";
			else
				str = "Update BO_HT Set ProgressCondition = '����',UpdatingPerson = @Person, UpdatingPersonID = @PersonID, UpdatingDate = @date  where BuyingOrderHistoryIndex = @BuyingOrderHistoryIndex";
			
			try
			{
				con.Open();
				cmd.Transaction = con.BeginTransaction();
				cmd.CommandText = str;
				cmd.Parameters.Add("@Person", Session["UserName"].ToString());
				cmd.Parameters.Add("@PersonID", Session["ID"].ToString());
				cmd.Parameters.Add("@date", DateTime.Now.ToShortDateString());
				cmd.ExecuteNonQuery();
				cmd.Parameters.Clear();
				cmd.Transaction.Commit();
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				cmd.Transaction.Rollback();
			}
			finally
			{
				con.Close();
			}
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = uwgBO_HT;
			bool check = true;
			for(int count = uwgBO_HT.Rows.Count-1 ; count >=0 ; count--)
			{
				if(UWG.Rows[count].Cells.FromKey("chk").Value == null || UWG.Rows[count].Cells.FromKey("chk").Value.ToString() == "false")
					UWG.Rows[count].Delete();
			}

			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count > 12)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
					
				Session["Grid"] = UWG;
				RegisterStartupScript("","<script>window.open('./Popup/Purchase.aspx','','width=1200, heigth=800,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
							
			}
			else
			{
				uwgBO_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
				uwgBO_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
				this.uwgBO_HT.DataSource = Search();
				this.uwgBO_HT.DataBind();
			}
			
			
		}

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("BuyingOrderPC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName, wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value, ddlItemClassification1.SelectedItem.Value);
			else
				search = new KIT_ERP.Search("BuyingOrderPC",ItemSearchControl1.ItemNum, "", "", wdcStartDate,wdcEndDate,CSC1.Company, CSC1.BusinessRegistrationNum, ddlState.SelectedItem.Value, ddlItemClassification1.SelectedItem.Value);

			return search.DataSet_search();
		}
	}
}
