using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideOutStorehouse�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideOutStorehouse : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebCombo.WebCombo wdcItem;
		protected System.Web.UI.WebControls.Button btnRegister;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOOS_HT;
		protected System.Web.UI.WebControls.LinkButton lnk;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_RowIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_RowSelectIndex;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOO_HT;
		protected System.Data.SqlClient.SqlDataAdapter OOS_HTAdapter;
		protected System.Web.UI.WebControls.LinkButton preOutStorehouse;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.TextBox txtThisOrderQuantity;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcDeliveryDate;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected KIT_ERP.BuyingOutside.dsOOS_HT dsOOS_HT1;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;

		
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}
			sqlConnection1.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["DSN"] ;


			
			ItemSearchControl1.RawMaterials = true; //������ ���ε�
			ItemSearchControl1.HalfFinishedProducts = true; //����ǰ ���ε�
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction = "���ְŷ�ó";

			if(!Page.IsPostBack)
			{
				OOS_HTAdapter.Fill(dsOOS_HT1);
				uwgOOS_HT.DataSource = dsOOS_HT1;
				uwgOOS_HT.DataBind();

				Session["dsOOS_HT1"] = dsOOS_HT1 ;

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";


				txtThisOrderQuantity.Attributes.Add("OnKeyDown", "OnKeyDown_Float(this);");
				txtThisOrderQuantity.Attributes.Add("OnKeyUp", "Process(); OnKeyUp_Currency(this);");
				txtThisOrderQuantity.Attributes.Add("OnFocus", "OnFocus_Obj(this);");
				txtThisOrderQuantity.Attributes.Add("OnBlur", "OnBlur_Cur(this);");

			}
			else
			{
				dsOOS_HT1= (dsOOS_HT)Session["dsOOS_HT1"] ;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.OOS_HTAdapter = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.dsOOS_HT1 = new KIT_ERP.BuyingOutside.dsOOS_HT();
			((System.ComponentModel.ISupportInitialize)(this.dsOOS_HT1)).BeginInit();
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.preOutStorehouse.Click += new System.EventHandler(this.preOutStorehouse_Click);
			this.uwgOO_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgOO_HT_PageIndexChanged);
			this.uwgOO_HT.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.uwgOO_HT_DblClick);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
			// 
			// OOS_HTAdapter
			// 
			this.OOS_HTAdapter.DeleteCommand = this.sqlDeleteCommand1;
			this.OOS_HTAdapter.InsertCommand = this.sqlInsertCommand1;
			this.OOS_HTAdapter.SelectCommand = this.sqlSelectCommand1;
			this.OOS_HTAdapter.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									new System.Data.Common.DataTableMapping("Table", "OOS_HT", new System.Data.Common.DataColumnMapping[] {
																																																			  new System.Data.Common.DataColumnMapping("ItemNum", "ItemNum"),
																																																			  new System.Data.Common.DataColumnMapping("ItemDrawNum", "ItemDrawNum"),
																																																			  new System.Data.Common.DataColumnMapping("ItemName", "ItemName"),
																																																			  new System.Data.Common.DataColumnMapping("OrderRate", "OrderRate"),
																																																			  new System.Data.Common.DataColumnMapping("ProgressRate", "ProgressRate"),
																																																			  new System.Data.Common.DataColumnMapping("ProcessSequenceNum", "ProcessSequenceNum"),
																																																			  new System.Data.Common.DataColumnMapping("ProcessCode", "ProcessCode"),
																																																			  new System.Data.Common.DataColumnMapping("ProcessName", "ProcessName"),
																																																			  new System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"),
																																																			  new System.Data.Common.DataColumnMapping("BusinessRegistrationNum", "BusinessRegistrationNum"),
																																																			  new System.Data.Common.DataColumnMapping("ThistimeOutStorehouseQuantity", "ThistimeOutStorehouseQuantity"),
																																																			  new System.Data.Common.DataColumnMapping("OutStorehouseDate", "OutStorehouseDate"),
																																																			  new System.Data.Common.DataColumnMapping("ProgressCondition", "ProgressCondition"),
																																																			  new System.Data.Common.DataColumnMapping("RegistrationPerson", "RegistrationPerson"),
																																																			  new System.Data.Common.DataColumnMapping("RegistrationPersonID", "RegistrationPersonID"),
																																																			  new System.Data.Common.DataColumnMapping("RegistrationDate", "RegistrationDate"),
																																																			  new System.Data.Common.DataColumnMapping("UpdatingPerson", "UpdatingPerson"),
																																																			  new System.Data.Common.DataColumnMapping("UpdatingPersonID", "UpdatingPersonID"),
																																																			  new System.Data.Common.DataColumnMapping("UpdatingDate", "UpdatingDate"),
																																																			  new System.Data.Common.DataColumnMapping("OutSideOrderHistoryIndex", "OutSideOrderHistoryIndex"),
																																																			  new System.Data.Common.DataColumnMapping("OutSideOutStorehouseHistoryIndex", "OutSideOutStorehouseHistoryIndex"),
																																																			  new System.Data.Common.DataColumnMapping("ThisOrderQuantity", "ThisOrderQuantity"),
																																																			  new System.Data.Common.DataColumnMapping("ThisDeliveryDate", "ThisDeliveryDate")})});
			this.OOS_HTAdapter.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = "DELETE FROM OOS_HT WHERE (OutSideOutStorehouseHistoryIndex = @Original_OutSideOut" +
				"StorehouseHistoryIndex) AND (BusinessRegistrationNum = @Original_BusinessRegistr" +
				"ationNum OR @Original_BusinessRegistrationNum IS NULL AND BusinessRegistrationNu" +
				"m IS NULL) AND (CompanyName = @Original_CompanyName OR @Original_CompanyName IS " +
				"NULL AND CompanyName IS NULL) AND (ItemDrawNum = @Original_ItemDrawNum OR @Origi" +
				"nal_ItemDrawNum IS NULL AND ItemDrawNum IS NULL) AND (ItemName = @Original_ItemN" +
				"ame OR @Original_ItemName IS NULL AND ItemName IS NULL) AND (ItemNum = @Original" +
				"_ItemNum OR @Original_ItemNum IS NULL AND ItemNum IS NULL) AND (OrderRate = @Ori" +
				"ginal_OrderRate OR @Original_OrderRate IS NULL AND OrderRate IS NULL) AND (OutSi" +
				"deOrderHistoryIndex = @Original_OutSideOrderHistoryIndex OR @Original_OutSideOrd" +
				"erHistoryIndex IS NULL AND OutSideOrderHistoryIndex IS NULL) AND (OutStorehouseD" +
				"ate = @Original_OutStorehouseDate OR @Original_OutStorehouseDate IS NULL AND Out" +
				"StorehouseDate IS NULL) AND (ProcessCode = @Original_ProcessCode OR @Original_Pr" +
				"ocessCode IS NULL AND ProcessCode IS NULL) AND (ProcessName = @Original_ProcessN" +
				"ame OR @Original_ProcessName IS NULL AND ProcessName IS NULL) AND (ProcessSequen" +
				"ceNum = @Original_ProcessSequenceNum OR @Original_ProcessSequenceNum IS NULL AND" +
				" ProcessSequenceNum IS NULL) AND (ProgressCondition = @Original_ProgressConditio" +
				"n OR @Original_ProgressCondition IS NULL AND ProgressCondition IS NULL) AND (Pro" +
				"gressRate = @Original_ProgressRate OR @Original_ProgressRate IS NULL AND Progres" +
				"sRate IS NULL) AND (RegistrationDate = @Original_RegistrationDate OR @Original_R" +
				"egistrationDate IS NULL AND RegistrationDate IS NULL) AND (RegistrationPerson = " +
				"@Original_RegistrationPerson OR @Original_RegistrationPerson IS NULL AND Registr" +
				"ationPerson IS NULL) AND (RegistrationPersonID = @Original_RegistrationPersonID " +
				"OR @Original_RegistrationPersonID IS NULL AND RegistrationPersonID IS NULL) AND " +
				"(ThisDeliveryDate = @Original_ThisDeliveryDate OR @Original_ThisDeliveryDate IS " +
				"NULL AND ThisDeliveryDate IS NULL) AND (ThisOrderQuantity = @Original_ThisOrderQ" +
				"uantity OR @Original_ThisOrderQuantity IS NULL AND ThisOrderQuantity IS NULL) AN" +
				"D (ThistimeOutStorehouseQuantity = @Original_ThistimeOutStorehouseQuantity OR @O" +
				"riginal_ThistimeOutStorehouseQuantity IS NULL AND ThistimeOutStorehouseQuantity " +
				"IS NULL) AND (UpdatingDate = @Original_UpdatingDate OR @Original_UpdatingDate IS" +
				" NULL AND UpdatingDate IS NULL) AND (UpdatingPerson = @Original_UpdatingPerson O" +
				"R @Original_UpdatingPerson IS NULL AND UpdatingPerson IS NULL) AND (UpdatingPers" +
				"onID = @Original_UpdatingPersonID OR @Original_UpdatingPersonID IS NULL AND Upda" +
				"tingPersonID IS NULL)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutSideOutStorehouseHistoryIndex", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutSideOutStorehouseHistoryIndex", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_BusinessRegistrationNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "BusinessRegistrationNum", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemDrawNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemDrawNum", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemName", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemNum", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OrderRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "OrderRate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutSideOrderHistoryIndex", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutSideOrderHistoryIndex", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutStorehouseDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutStorehouseDate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessCode", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessCode", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessName", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessSequenceNum", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessSequenceNum", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressCondition", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgressCondition", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ProgressRate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationDate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationPerson", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationPerson", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationPersonID", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationPersonID", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThisDeliveryDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ThisDeliveryDate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThisOrderQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThisOrderQuantity", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThistimeOutStorehouseQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThistimeOutStorehouseQuantity", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingDate", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingPerson", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingPerson", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingPersonID", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingPersonID", System.Data.DataRowVersion.Original, null));
			// 
			// sqlConnection1
			// 

			this.sqlConnection1.ConnectionString = "workstation id=\"EZSYS-ERP01\";packet size=4096;user id=sa;data source=\"220.66.115.9\";persist " +
				"security info=True;initial catalog=Sindong_ERP;password=\"ezsys#0509\"";
			//this.sqlConnection1.ConnectionString = "workstation id=FREESRV05;packet size=4096;user id=sa;data source=\"220.66.115.10\";" +
			//	"persist security info=True;initial catalog=Shindong_ERP;password=\"ezsys#0509\"";
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO OOS_HT(ItemNum, ItemDrawNum, ItemName, OrderRate, ProgressRate, ProcessSequenceNum, ProcessCode, ProcessName, CompanyName, BusinessRegistrationNum, ThistimeOutStorehouseQuantity, OutStorehouseDate, ProgressCondition, RegistrationPerson, RegistrationPersonID, RegistrationDate, UpdatingPerson, UpdatingPersonID, UpdatingDate, OutSideOrderHistoryIndex, ThisOrderQuantity, ThisDeliveryDate) VALUES (@ItemNum, @ItemDrawNum, @ItemName, @OrderRate, @ProgressRate, @ProcessSequenceNum, @ProcessCode, @ProcessName, @CompanyName, @BusinessRegistrationNum, @ThistimeOutStorehouseQuantity, @OutStorehouseDate, @ProgressCondition, @RegistrationPerson, @RegistrationPersonID, @RegistrationDate, @UpdatingPerson, @UpdatingPersonID, @UpdatingDate, @OutSideOrderHistoryIndex, @ThisOrderQuantity, @ThisDeliveryDate); SELECT ItemNum, ItemDrawNum, ItemName, OrderRate, ProgressRate, ProcessSequenceNum, ProcessCode, ProcessName, CompanyName, BusinessRegistrationNum, ThistimeOutStorehouseQuantity, OutStorehouseDate, ProgressCondition, RegistrationPerson, RegistrationPersonID, RegistrationDate, UpdatingPerson, UpdatingPersonID, UpdatingDate, OutSideOrderHistoryIndex, OutSideOutStorehouseHistoryIndex, ThisOrderQuantity, ThisDeliveryDate FROM OOS_HT WHERE (OutSideOutStorehouseHistoryIndex = @@IDENTITY)";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemNum", System.Data.SqlDbType.NVarChar, 50, "ItemNum"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemDrawNum", System.Data.SqlDbType.NVarChar, 50, "ItemDrawNum"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemName", System.Data.SqlDbType.NVarChar, 50, "ItemName"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrderRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "OrderRate", System.Data.DataRowVersion.Current, null));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ProgressRate", System.Data.DataRowVersion.Current, null));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessSequenceNum", System.Data.SqlDbType.Int, 4, "ProcessSequenceNum"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessCode", System.Data.SqlDbType.NVarChar, 50, "ProcessCode"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessName", System.Data.SqlDbType.NVarChar, 50, "ProcessName"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 50, "CompanyName"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BusinessRegistrationNum", System.Data.SqlDbType.NVarChar, 50, "BusinessRegistrationNum"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThistimeOutStorehouseQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThistimeOutStorehouseQuantity", System.Data.DataRowVersion.Current, null));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OutStorehouseDate", System.Data.SqlDbType.DateTime, 4, "OutStorehouseDate"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressCondition", System.Data.SqlDbType.NVarChar, 50, "ProgressCondition"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationPerson", System.Data.SqlDbType.NVarChar, 50, "RegistrationPerson"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationPersonID", System.Data.SqlDbType.NVarChar, 50, "RegistrationPersonID"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationDate", System.Data.SqlDbType.DateTime, 4, "RegistrationDate"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingPerson", System.Data.SqlDbType.NVarChar, 50, "UpdatingPerson"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingPersonID", System.Data.SqlDbType.NVarChar, 50, "UpdatingPersonID"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingDate", System.Data.SqlDbType.DateTime, 4, "UpdatingDate"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OutSideOrderHistoryIndex", System.Data.SqlDbType.Int, 4, "OutSideOrderHistoryIndex"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThisOrderQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThisOrderQuantity", System.Data.DataRowVersion.Current, null));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThisDeliveryDate", System.Data.SqlDbType.DateTime, 4, "ThisDeliveryDate"));
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = @"SELECT ItemNum, ItemDrawNum, ItemName, OrderRate, ProgressRate, ProcessSequenceNum, ProcessCode, ProcessName, CompanyName, BusinessRegistrationNum, ThistimeOutStorehouseQuantity, OutStorehouseDate, ProgressCondition, RegistrationPerson, RegistrationPersonID, RegistrationDate, UpdatingPerson, UpdatingPersonID, UpdatingDate, OutSideOrderHistoryIndex, OutSideOutStorehouseHistoryIndex, ThisOrderQuantity, ThisDeliveryDate FROM OOS_HT WHERE (ItemNum IS NULL)";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = "UPDATE OOS_HT SET ItemNum = @ItemNum, ItemDrawNum = @ItemDrawNum, ItemName = @Ite" +
				"mName, OrderRate = @OrderRate, ProgressRate = @ProgressRate, ProcessSequenceNum " +
				"= @ProcessSequenceNum, ProcessCode = @ProcessCode, ProcessName = @ProcessName, C" +
				"ompanyName = @CompanyName, BusinessRegistrationNum = @BusinessRegistrationNum, T" +
				"histimeOutStorehouseQuantity = @ThistimeOutStorehouseQuantity, OutStorehouseDate" +
				" = @OutStorehouseDate, ProgressCondition = @ProgressCondition, RegistrationPerso" +
				"n = @RegistrationPerson, RegistrationPersonID = @RegistrationPersonID, Registrat" +
				"ionDate = @RegistrationDate, UpdatingPerson = @UpdatingPerson, UpdatingPersonID " +
				"= @UpdatingPersonID, UpdatingDate = @UpdatingDate, OutSideOrderHistoryIndex = @O" +
				"utSideOrderHistoryIndex, ThisOrderQuantity = @ThisOrderQuantity, ThisDeliveryDat" +
				"e = @ThisDeliveryDate WHERE (OutSideOutStorehouseHistoryIndex = @Original_OutSid" +
				"eOutStorehouseHistoryIndex) AND (BusinessRegistrationNum = @Original_BusinessReg" +
				"istrationNum OR @Original_BusinessRegistrationNum IS NULL AND BusinessRegistrati" +
				"onNum IS NULL) AND (CompanyName = @Original_CompanyName OR @Original_CompanyName" +
				" IS NULL AND CompanyName IS NULL) AND (ItemDrawNum = @Original_ItemDrawNum OR @O" +
				"riginal_ItemDrawNum IS NULL AND ItemDrawNum IS NULL) AND (ItemName = @Original_I" +
				"temName OR @Original_ItemName IS NULL AND ItemName IS NULL) AND (ItemNum = @Orig" +
				"inal_ItemNum OR @Original_ItemNum IS NULL AND ItemNum IS NULL) AND (OrderRate = " +
				"@Original_OrderRate OR @Original_OrderRate IS NULL AND OrderRate IS NULL) AND (O" +
				"utSideOrderHistoryIndex = @Original_OutSideOrderHistoryIndex OR @Original_OutSid" +
				"eOrderHistoryIndex IS NULL AND OutSideOrderHistoryIndex IS NULL) AND (OutStoreho" +
				"useDate = @Original_OutStorehouseDate OR @Original_OutStorehouseDate IS NULL AND" +
				" OutStorehouseDate IS NULL) AND (ProcessCode = @Original_ProcessCode OR @Origina" +
				"l_ProcessCode IS NULL AND ProcessCode IS NULL) AND (ProcessName = @Original_Proc" +
				"essName OR @Original_ProcessName IS NULL AND ProcessName IS NULL) AND (ProcessSe" +
				"quenceNum = @Original_ProcessSequenceNum OR @Original_ProcessSequenceNum IS NULL" +
				" AND ProcessSequenceNum IS NULL) AND (ProgressCondition = @Original_ProgressCond" +
				"ition OR @Original_ProgressCondition IS NULL AND ProgressCondition IS NULL) AND " +
				"(ProgressRate = @Original_ProgressRate OR @Original_ProgressRate IS NULL AND Pro" +
				"gressRate IS NULL) AND (RegistrationDate = @Original_RegistrationDate OR @Origin" +
				"al_RegistrationDate IS NULL AND RegistrationDate IS NULL) AND (RegistrationPerso" +
				"n = @Original_RegistrationPerson OR @Original_RegistrationPerson IS NULL AND Reg" +
				"istrationPerson IS NULL) AND (RegistrationPersonID = @Original_RegistrationPerso" +
				"nID OR @Original_RegistrationPersonID IS NULL AND RegistrationPersonID IS NULL) " +
				"AND (ThisDeliveryDate = @Original_ThisDeliveryDate OR @Original_ThisDeliveryDate" +
				" IS NULL AND ThisDeliveryDate IS NULL) AND (ThisOrderQuantity = @Original_ThisOr" +
				"derQuantity OR @Original_ThisOrderQuantity IS NULL AND ThisOrderQuantity IS NULL" +
				") AND (ThistimeOutStorehouseQuantity = @Original_ThistimeOutStorehouseQuantity O" +
				"R @Original_ThistimeOutStorehouseQuantity IS NULL AND ThistimeOutStorehouseQuant" +
				"ity IS NULL) AND (UpdatingDate = @Original_UpdatingDate OR @Original_UpdatingDat" +
				"e IS NULL AND UpdatingDate IS NULL) AND (UpdatingPerson = @Original_UpdatingPers" +
				"on OR @Original_UpdatingPerson IS NULL AND UpdatingPerson IS NULL) AND (Updating" +
				"PersonID = @Original_UpdatingPersonID OR @Original_UpdatingPersonID IS NULL AND " +
				"UpdatingPersonID IS NULL); SELECT ItemNum, ItemDrawNum, ItemName, OrderRate, Pro" +
				"gressRate, ProcessSequenceNum, ProcessCode, ProcessName, CompanyName, BusinessRe" +
				"gistrationNum, ThistimeOutStorehouseQuantity, OutStorehouseDate, ProgressConditi" +
				"on, RegistrationPerson, RegistrationPersonID, RegistrationDate, UpdatingPerson, " +
				"UpdatingPersonID, UpdatingDate, OutSideOrderHistoryIndex, OutSideOutStorehouseHi" +
				"storyIndex, ThisOrderQuantity, ThisDeliveryDate FROM OOS_HT WHERE (OutSideOutSto" +
				"rehouseHistoryIndex = @OutSideOutStorehouseHistoryIndex)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemNum", System.Data.SqlDbType.NVarChar, 50, "ItemNum"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemDrawNum", System.Data.SqlDbType.NVarChar, 50, "ItemDrawNum"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ItemName", System.Data.SqlDbType.NVarChar, 50, "ItemName"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrderRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "OrderRate", System.Data.DataRowVersion.Current, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ProgressRate", System.Data.DataRowVersion.Current, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessSequenceNum", System.Data.SqlDbType.Int, 4, "ProcessSequenceNum"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessCode", System.Data.SqlDbType.NVarChar, 50, "ProcessCode"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProcessName", System.Data.SqlDbType.NVarChar, 50, "ProcessName"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 50, "CompanyName"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BusinessRegistrationNum", System.Data.SqlDbType.NVarChar, 50, "BusinessRegistrationNum"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThistimeOutStorehouseQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThistimeOutStorehouseQuantity", System.Data.DataRowVersion.Current, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OutStorehouseDate", System.Data.SqlDbType.DateTime, 4, "OutStorehouseDate"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ProgressCondition", System.Data.SqlDbType.NVarChar, 50, "ProgressCondition"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationPerson", System.Data.SqlDbType.NVarChar, 50, "RegistrationPerson"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationPersonID", System.Data.SqlDbType.NVarChar, 50, "RegistrationPersonID"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RegistrationDate", System.Data.SqlDbType.DateTime, 4, "RegistrationDate"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingPerson", System.Data.SqlDbType.NVarChar, 50, "UpdatingPerson"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingPersonID", System.Data.SqlDbType.NVarChar, 50, "UpdatingPersonID"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@UpdatingDate", System.Data.SqlDbType.DateTime, 4, "UpdatingDate"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OutSideOrderHistoryIndex", System.Data.SqlDbType.Int, 4, "OutSideOrderHistoryIndex"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThisOrderQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThisOrderQuantity", System.Data.DataRowVersion.Current, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ThisDeliveryDate", System.Data.SqlDbType.DateTime, 4, "ThisDeliveryDate"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutSideOutStorehouseHistoryIndex", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutSideOutStorehouseHistoryIndex", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_BusinessRegistrationNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "BusinessRegistrationNum", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemDrawNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemDrawNum", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemName", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ItemNum", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ItemNum", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OrderRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "OrderRate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutSideOrderHistoryIndex", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutSideOrderHistoryIndex", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_OutStorehouseDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "OutStorehouseDate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessCode", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessCode", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessName", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProcessSequenceNum", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProcessSequenceNum", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressCondition", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ProgressCondition", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ProgressRate", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ProgressRate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationDate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationPerson", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationPerson", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_RegistrationPersonID", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "RegistrationPersonID", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThisDeliveryDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ThisDeliveryDate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThisOrderQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThisOrderQuantity", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ThistimeOutStorehouseQuantity", System.Data.SqlDbType.Decimal, 13, System.Data.ParameterDirection.Input, false, ((System.Byte)(20)), ((System.Byte)(2)), "ThistimeOutStorehouseQuantity", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingDate", System.Data.SqlDbType.DateTime, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingDate", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingPerson", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingPerson", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_UpdatingPersonID", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "UpdatingPersonID", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OutSideOutStorehouseHistoryIndex", System.Data.SqlDbType.Int, 4, "OutSideOutStorehouseHistoryIndex"));
			// 
			// dsOOS_HT1
			// 
			this.dsOOS_HT1.DataSetName = "dsOOS_HT";
			this.dsOOS_HT1.Locale = new System.Globalization.CultureInfo("ko-KR");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dsOOS_HT1)).EndInit();

		}
		#endregion

		/// <summary>
		/// �˻��Լ�
		/// </summary>
		/// <returns></returns>
		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("OutSideOutStorehouse",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,wdcStartDate,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum,"���",ddlItemClassification1.SelectedItem.Value);
			else
				search = new KIT_ERP.Search("OutSideOutStorehouse",ItemSearchControl1.ItemNum, "", "",wdcStartDate,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum,"���",ddlItemClassification1.SelectedItem.Value);
			return search.DataSet_search();
		}

		//�˻���ư Ŭ��
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgOO_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			uwgOO_HT.DataSource = Search();
			uwgOO_HT.DataBind();
		}

		//��Ϲ�ư Ŭ��
		private void btnRegister_Click(object sender, System.EventArgs e)
		{
			if(dsOOS_HT1.Tables[0].Rows.Count == 0)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('����� �׸��� �����ϴ�!');");
				Response.Write("</script>");
			}
			else
			{

				//��������� 0�ΰ��� ����
				for(int count = uwgOOS_HT.Rows.Count -1 ; count >=0 ; count--)
				{
					if(decimal.Parse(uwgOOS_HT.Rows[count].Cells.FromKey("ThistimeOutStorehouseQuantity").Text.Trim()) == 0)
					uwgOOS_HT.Rows[count].Delete();
				}

				Register rg = new Register(uwgOOS_HT,"OutSideOutStorehouse",Session["ID"].ToString());
				rg.GridRegistration();

				dsOOS_HT1.Tables[0].Rows.Clear();
				uwgOOS_HT.DataSource = dsOOS_HT1;
				uwgOOS_HT.DataBind();

				//�˻�
				uwgOO_HT.DataSource = Search();
				uwgOO_HT.DataBind();
			}

			Session["dsOOS_HT1"] = dsOOS_HT1 ;

		}

		/// <summary>
		/// ���� ���� ���ý�
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void uwgOO_HT_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{

			if(txtThisOrderQuantity.Text .Trim() == "" || txtThisOrderQuantity.Text.Trim() == "0")
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('�ݹ����ּ����� �Է��ϼ���!');");
				Response.Write("</script>");
			}
			else if(wdcDeliveryDate.Text.Trim() == "" || wdcDeliveryDate.Value ==null)
			{
				Response.Write("<script language=javascript>");
				Response.Write("alert('�ݹ��������� �Է��ϼ���!');");
				Response.Write("</script>");
			}
			else
			{
				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
				conn.Open();

				// �ϴ� ���ֿ����� ���۰��� �Ʒ��ܰ谡 � �������� �˾ƾ� �Ѵ�
				// ���������� ���� ���� ���̸� �ٷ� �Ʒ��ܰ� ǰ���� ������ �ϰ�
				// �׷��� ������ �׾Ʒ� �������� ǰ���� ������ �Ѵ�.
				// �׷��Ƿ� �Ʒ��ܰ迡 ������ �ִ��� ������ Ȯ���ϴ°��� �켱�̴�

				// �ϴ� ���� ���۰����� ���������� ���Ѵ��� �׾Ʒ� �� �ִ��� Ȯ���Ѵ�
				int sequence = 0;

				string str = "Select ProcessSequenceNum From PSI_MT Where RecodingState = 1 and ProcessCode = @code and ItemNum = @itemnum";
				SqlCommand comm = new SqlCommand(str,conn);
				comm.Parameters.Add("@code",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BeginProcessCode").Text;//.Substring(0,8).Trim();
				comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;;

				SqlDataReader dr_num = comm.ExecuteReader();
				while(dr_num.Read())
				{
					sequence = int.Parse(dr_num["ProcessSequenceNum"].ToString());
				}
				dr_num.Close();
			
				//���� ������������ �Ʒ��� ���������� �ִ��� �������� ���Ѵ�
				int sequence1 = 0;	//��������
				string Code = "";	// �����ڵ�
				string Name = "";	// ������
				str = "Select Max(ProcessSequenceNum) From PSI_MT Where RecodingState = 1 and ProcessSequenceNum < @num and ItemNum = @itemnum";
				SqlCommand comm1 = new SqlCommand(str,conn);
				comm1.Parameters.Add("@num",SqlDbType.Int).Value = sequence;
				comm1.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;
				if(comm1.ExecuteScalar() == null || comm1.ExecuteScalar().ToString().Trim() == "")
					sequence1 = 0;
				else
					sequence1 = int.Parse(comm1.ExecuteScalar().ToString());

			
				str = "Select ProcessCode From PSI_MT Where RecodingState = 1 and ProcessSequenceNum = @num and ItemNum = @itemnum";
				SqlCommand comm2 = new SqlCommand(str,conn);
				comm2.Parameters.Add("@num",SqlDbType.Int).Value = sequence1;
				comm2.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;
				SqlDataReader dr2 = comm2.ExecuteReader();
				while(dr2.Read())
				{
					Code = dr2["ProcessCode"].ToString();
				}
				dr2.Close();

			


				str = "Select SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and SmallClassificationCode = @code";

				SqlCommand comm3 = new SqlCommand(str,conn);
				comm3.Parameters.Add("@code",SqlDbType.VarChar).Value = Code;
				SqlDataReader dr3 = comm3.ExecuteReader();
				while(dr3.Read())
				{
					Name = dr3["SmallClassificationName"].ToString();
				}
				dr3.Close();
		

			

				// �Ʒ� ����������ȣ�� �����Ҷ���(���������� 0�� �ƴ� ���) �ٷ� �� ǰ���� �����Ų��.
				// ���� ����ִ� ����������ȣ�� ǰ���� �����Ų��.
				string st_ItemNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;

				if(sequence1 != 0)
				{
					// ��ô������ ���ؾ� �Ѵ�
					decimal rate = 0;	//���ֺ���(���������� �ִ� ���ֺ����� �ܰ����̺��� �ִ� ���ֺ����� ���ϸ� ���� ����Ǿ�� �� ���ֺ���
					decimal rate1 = 0;	//��ô����(���������� �ִ� ��ô������ �־�д�.

					str = "Select OutsideOrderRate, ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @item and ProcessSequenceNum = @num";
					SqlCommand comm4 = new SqlCommand(str,conn);
					comm4.Parameters.Add("@item",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;
					comm4.Parameters.Add("@num",SqlDbType.Int).Value = sequence1;
					SqlDataReader dr_Rate = comm4.ExecuteReader();
					while(dr_Rate.Read())
					{
						rate = decimal.Parse(dr_Rate["OutsideOrderRate"].ToString());
						rate1 = decimal.Parse(dr_Rate["ProgressRate"].ToString());
					}
					dr_Rate.Close();

				

				
				

					// �����ͼ¿� �߰��ϱ����� Row
					dsOOS_HT.OOS_HTRow dr = (dsOOS_HT.OOS_HTRow)dsOOS_HT1.OOS_HT.NewOOS_HTRow();

					dr.ItemNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemNum").Text;
					dr.ItemDrawNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemDrawNum").Text;
					dr.ItemName = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("ItemName").Text;
					dr.OrderRate = decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderRate").Text);//�ܰ����̺��� �ִ� �ŷ�ó�� ���ֺ���
					dr.ProgressRate = rate1;//��ô����
					dr.ProcessSequenceNum = sequence1;//��������
					dr.ProcessCode = Code;//�����ڵ�
					dr.ProcessName = Name;//������
					dr.CompanyName = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("CompanyName").Text;
					dr.BusinessRegistrationNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BusinessRegistrationNum").Text;
					dr.ThistimeOutStorehouseQuantity = decimal.Parse(txtThisOrderQuantity.Text);//decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderQuantity").Text);// �ŷ�ó�� �ݹ������
					dr.ProgressCondition = "���";
					dr.OutStorehouseDate = DateTime.Parse(DateTime.Now.ToShortDateString());
					dr.RegistrationPerson = Session["UserName"].ToString();
					dr.RegistrationPersonID = Session["ID"].ToString();
					dr.RegistrationDate = DateTime.Parse(DateTime.Now.ToShortDateString());
					dr.OutSideOrderHistoryIndex = int.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OutSideOrderHistoryIndex").Text);// ���ֹ��ֿ����ȣ
					dr.ThisOrderQuantity = decimal.Parse(txtThisOrderQuantity.Text);
					dr.ThisDeliveryDate = DateTime.Parse(wdcDeliveryDate.Text);

					dsOOS_HT1.OOS_HT.AddOOS_HTRow(dr);

				}
				else
				{
					// ������ȣ�� 0 �̸� ����ǰ���� ã�� ���ÿ� Push�Ѵ�
					Stack st = new Stack();	

					string item = "";
					//����ǰ���� ã�����ؼ��� ǰ�񱸼������� ���� ǰ���� ��ǰ���� �ϴ� ��� ���ڵ带 ���ÿ� �ִ´�
					//str = "Select ChildItemNum, ItemDrawNum, Item From IOI_MT JOIN ON II_MT Where RecodingState = 1 and ParentItemNum = @itemnum";
					str = @"SELECT ItemNum, ItemDrawNum, ItemName, NeedQuantityNumerator, NeedQuantityDenominator FROM II_MT INNER JOIN IOI_MT ON II_MT.ItemNum = IOI_MT.ChildItemNum 	WHERE (II_MT.RecodingState = 1) AND (IOI_MT.RecodingState = 1) AND (IOI_MT.ParentItemNum = @itemnum) ";
					SqlCommand comm5 = new SqlCommand(str,conn);
					comm5.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = st_ItemNum;
					SqlDataReader dr_Child = comm5.ExecuteReader();
					while(dr_Child.Read())
					{
						st.Push(dr_Child["ItemNum"].ToString());
					}
					dr_Child.Close();
				
				
					// ���ÿ� ǰ���� �ִ��� Ȯ���Ѵ�.
					if(st.Count != 0)
					{
						// ������ ������ ������ �� ���������� ��� Pop�Ѵ�
						while(st.Count > 0)
						{	
							item =st.Pop().ToString();
							decimal quantity = 1;

							// ����ǰ���� ���������� ����1�� �ִ´�
							Stack st1 = new Stack();					
							int sequencenum=0;

							//���� ǰ���� ���������� �־�д�.
							str = "Select ProcessSequenceNum from PSI_MT where RecodingState = 1 AND ItemNum = @itemnum  order by ProcessSequenceNum";
							SqlCommand comm6 = new SqlCommand();
							comm6.Connection = conn;
							comm6.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
							comm6.CommandText = str;
							SqlDataReader dr_Sequence = comm6.ExecuteReader();
							while(dr_Sequence.Read())
							{
								//��������
								st1.Push(int.Parse(dr_Sequence["ProcessSequenceNum"].ToString()));
							
							}
							dr_Sequence.Close();
							comm6.Parameters.Clear();

							//����ǰ���� �ҿ䷮�� �־�д�
							str = "select * From IOI_MT Where ParentItemNum = @num and ChildItemNum = @item and RecodingState = 1 ";
							comm6.Parameters.Add("@num",st_ItemNum);
							comm6.Parameters.Add("@item",item);
							comm6.CommandText = str;
							SqlDataReader dr1 = comm6.ExecuteReader();
							while(dr1.Read())
							{
								//quantity = Math.Round(decimal.Parse(dr1["NeedQuantityNumerator"].ToString())/decimal.Parse(dr1["NeedQuantityDenominator"].ToString()));
								quantity = decimal.Round(decimal.Parse(dr1["NeedQuantityNumerator"].ToString())/decimal.Parse(dr1["NeedQuantityDenominator"].ToString()),2);
							}
							dr1.Close();
							comm6.Parameters.Clear();

							//���������� ������ ���� ǰ���� �������̹Ƿ� �̸� �����Ų��.
							if(st1.Count == 0)
							{
								//ǰ��,����,ǰ�� ���Ѵ�
								string itemdraw=""; string name="";
								str = "Select * From II_MT Where ItemNum = @num and RecodingState = 1";
								SqlCommand comm7 = new SqlCommand(str,conn);
								comm7.Parameters.Add("@num",SqlDbType.VarChar).Value = item;
								SqlDataReader dr_Item = comm7.ExecuteReader();
								while(dr_Item.Read())
								{
									itemdraw = dr_Item["ItemDrawNum"].ToString();
									name = dr_Item["ItemName"].ToString();
								}
								dr_Item.Close();

								// �����ͼ¿� �߰��ϱ����� Row
								dsOOS_HT.OOS_HTRow dr = (dsOOS_HT.OOS_HTRow)dsOOS_HT1.OOS_HT.NewOOS_HTRow();

								dr.ItemNum = item;
								dr.ItemDrawNum = itemdraw;
								dr.ItemName = name;
								dr.OrderRate = decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderRate").Text);//�ܰ����̺��� �ִ� �ŷ�ó�� ���ֺ���
								dr.ProgressRate = 100;//��ô����
								dr.ProcessSequenceNum = sequence1;//��������
								dr.ProcessCode = "14000000";//�����ڵ�(������)
								dr.ProcessName = "����";//������(������)
								dr.CompanyName = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("CompanyName").Text;
								dr.BusinessRegistrationNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BusinessRegistrationNum").Text;
								dr.ThistimeOutStorehouseQuantity = decimal.Parse(txtThisOrderQuantity.Text)*quantity;//decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderQuantity").Text)*quantity;//*decimal.Parse(arr[3].ToString());// �ŷ�ó�� �ݹ������*����ǰ�񱸼���
								dr.ProgressCondition = "���";
								dr.OutStorehouseDate = DateTime.Parse(DateTime.Now.ToShortDateString());
								dr.RegistrationPerson = Session["UserName"].ToString();
								dr.RegistrationPersonID = Session["ID"].ToString();
								dr.RegistrationDate = DateTime.Parse(DateTime.Now.ToShortDateString());
								dr.OutSideOrderHistoryIndex = int.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OutSideOrderHistoryIndex").Text);// ���ֹ��ֿ����ȣ
								dr.ThisOrderQuantity = decimal.Parse(txtThisOrderQuantity.Text);
								dr.ThisDeliveryDate = DateTime.Parse(wdcDeliveryDate.Text);


								dsOOS_HT1.OOS_HT.AddOOS_HTRow(dr);
							}
							else //�׷��� ������ �� ǰ���� �ֻ��� ���������� ã�Ƽ� �� ������ �������� �Ǵ��Ѵ�. ī��Ʈ�� 0�̸� ���ְ� �ƴϹǷ� �����Ų��.
							{
								// ����1�� �ִ� ���������� �ϳ���������.
								while(st1.Count > 0)
								{
									sequencenum = int.Parse(st1.Pop().ToString());
									str = " SELECT  count(*) FROM PSI_MT WHERE RecodingState = 1 and WorkDistinction <> '����' and ItemNum = @item and ProcessSequenceNum = @num";
									SqlCommand comm8 = new SqlCommand(str,conn);
									comm8.Parameters.Add("@item",SqlDbType.VarChar).Value = item;//ǰ���ȣ
									comm8.Parameters.Add("@num",SqlDbType.VarChar).Value = sequencenum;//��������
									int aaa = int.Parse(comm8.ExecuteScalar().ToString());
								

									//ǰ��,����,ǰ�� ���Ѵ�
									string itemdraw=""; string name="";
									str = "Select * From II_MT Where ItemNum = @num";
									SqlCommand comm9 = new SqlCommand(str,conn);
									comm9.Parameters.Add("@num",SqlDbType.VarChar).Value = item;
									SqlDataReader dr_Item = comm9.ExecuteReader();
									while(dr_Item.Read())
									{
										itemdraw = dr_Item["ItemDrawNum"].ToString();
										name = dr_Item["ItemName"].ToString();
									}
									dr_Item.Close();

									//�����ڵ�� �������� ���Ѵ�
									string processcode="";string processname="";
									str = " SELECT  ProcessSequenceNum, ProcessCode, SmallClassificationName " +
										" FROM      PSI_MT INNER JOIN " +
										" PUC_MT ON ProcessCode = SmallClassificationCode " +
										" WHERE PSI_MT.RecodingState = 1 AND ItemNum = @itemnum and ProcessSequenceNum = @num";
									SqlCommand comm10 = new SqlCommand(str,conn);
									comm10.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
									comm10.Parameters.Add("@num",SqlDbType.VarChar).Value = sequencenum;
									SqlDataReader dr_code = comm10.ExecuteReader();
									while(dr_code.Read())
									{
										processcode = dr_code["ProcessCode"].ToString();//�����ڵ�
										processname = dr_code["SmallClassificationName"].ToString();//������
									}
									dr_code.Close();


									// ���ְ� �ƴϸ� ���
									if(aaa != 0)
									{
										// �����ͼ¿� �߰��ϱ����� Row
										dsOOS_HT.OOS_HTRow dr = (dsOOS_HT.OOS_HTRow)dsOOS_HT1.OOS_HT.NewOOS_HTRow();

										dr.ItemNum = item;
										dr.ItemDrawNum = itemdraw;
										dr.ItemName = name;
										dr.OrderRate = decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderRate").Text);//�ܰ����̺��� �ִ� �ŷ�ó�� ���ֺ���
										dr.ProgressRate = 100;//��ô����
										dr.ProcessSequenceNum = sequencenum;//��������
										dr.ProcessCode = processcode;//�����ڵ�
										dr.ProcessName = processname;//������
										dr.CompanyName = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("CompanyName").Text;
										dr.BusinessRegistrationNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BusinessRegistrationNum").Text;
										dr.ThistimeOutStorehouseQuantity = decimal.Parse(txtThisOrderQuantity.Text)*quantity;//decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderQuantity").Text)*quantity;//*decimal.Parse(arr[3].ToString());// �ŷ�ó�� �ݹ������*����ǰ�񱸼���
										dr.ProgressCondition = "���";
										dr.OutStorehouseDate = DateTime.Parse(DateTime.Now.ToShortDateString());
										dr.RegistrationPerson = Session["UserName"].ToString();
										dr.RegistrationPersonID = Session["ID"].ToString();
										dr.RegistrationDate = DateTime.Parse(DateTime.Now.ToShortDateString());
										dr.OutSideOrderHistoryIndex = int.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OutSideOrderHistoryIndex").Text);// ���ֹ��ֿ����ȣ
										dr.ThisOrderQuantity = decimal.Parse(txtThisOrderQuantity.Text);
										dr.ThisDeliveryDate = DateTime.Parse(wdcDeliveryDate.Text);

										dsOOS_HT1.OOS_HT.AddOOS_HTRow(dr);
										st1.Clear();
										break;
									}
									else//�����̸� ���ִܰ����� ���� ã�� �����̶� ��������� �����Ѱ��� �ִ��� ���캻��. ������ �����Ű�� ������ ���������� ã�´�
									{
										// ���ִܰ����� ����ȸ�� ���ְ������� �ľ��Ѵ�.
										str = "select count(*) From UCI_MT Where RecodingState = 1 and ItemNum = @itemnum and EndProcessCode = @code and BusinessRegistrationNum = @com";
										SqlCommand comm11 = new SqlCommand(str,conn);
										comm11.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
										comm11.Parameters.Add("@code",SqlDbType.VarChar).Value = processcode;
										comm11.Parameters.Add("@com",SqlDbType.VarChar).Value = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BusinessRegistrationNum").Text;

										int find = int.Parse(comm11.ExecuteScalar().ToString());
									

										// ����ȸ�簡 �ƴϸ� ���
										if(find == 0)
										{
											// �����ͼ¿� �߰��ϱ����� Row
											dsOOS_HT.OOS_HTRow dr = (dsOOS_HT.OOS_HTRow)dsOOS_HT1.OOS_HT.NewOOS_HTRow();

											dr.ItemNum = item;
											dr.ItemDrawNum = itemdraw;
											dr.ItemName = name;
											dr.OrderRate = decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderRate").Text);//�ܰ����̺��� �ִ� �ŷ�ó�� ���ֺ���
											dr.ProgressRate = 100;//��ô����
											dr.ProcessSequenceNum = sequencenum;//��������
											dr.ProcessCode = processcode;//�����ڵ�
											dr.ProcessName = processname;//������
											dr.CompanyName = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("CompanyName").Text;
											dr.BusinessRegistrationNum = uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("BusinessRegistrationNum").Text;
											dr.ThistimeOutStorehouseQuantity =  decimal.Parse(txtThisOrderQuantity.Text)*quantity;//decimal.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OrderQuantity").Text)*quantity;//*decimal.Parse(arr[3].ToString());// �ŷ�ó�� �ݹ������*����ǰ�񱸼���
											dr.ProgressCondition = "���";
											dr.OutStorehouseDate = DateTime.Parse(DateTime.Now.ToShortDateString());
											dr.RegistrationPerson = Session["UserName"].ToString();
											dr.RegistrationPersonID = Session["ID"].ToString();
											dr.RegistrationDate = DateTime.Parse(DateTime.Now.ToShortDateString());
											dr.OutSideOrderHistoryIndex = int.Parse(uwgOO_HT.Rows[int.Parse(lb_RowSelectIndex.Value)].Cells.FromKey("OutSideOrderHistoryIndex").Text);// ���ֹ��ֿ����ȣ
											dr.ThisOrderQuantity = decimal.Parse(txtThisOrderQuantity.Text);
											dr.ThisDeliveryDate = DateTime.Parse(wdcDeliveryDate.Text);

											dsOOS_HT1.OOS_HT.AddOOS_HTRow(dr);

											st1.Clear();
											break;
										}
									}
								}
							}
						}
					}
				}

				uwgOOS_HT.DataSource = dsOOS_HT1;
				uwgOOS_HT.DataBind();
			}
			Session["dsOOS_HT1"] = dsOOS_HT1 ;
		}


		/// <summary>
		/// ǰ���� �ڻ�з��� �������� �Ǵ��ϴ� �Լ�
		/// </summary>
		/// <param name="rowcount"></param>
		/// <returns></returns>
		private int Division(int rowcount)
		{
			string aa="";

			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value =  uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Text;
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			conn.Close();

			if(aa.ToString() == "������")
				return 1;
			else if(aa.ToString() =="����ǰ")
				return 2;
			else if(aa.ToString() =="��ǰ")
				return 3;
			else if(aa.ToString() =="��ǰ")
				return 4;
			else //if(aa.ToString() =="����")
				return 5;
		}


		private void preOutStorehouse_Click(object sender, System.EventArgs e)
		{
			string formID = "PreOutStorehousePopUp" ;

			Response.Write("<script language=javascript>");
			Response.Write("window.open('PreOutStorehousePopUp.aspx?formID=" + formID + "','Calendar'," + "'width=675px" + "," + "height=270px');");
			Response.Write("</script>");  
		}

		

		private void uwgOO_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgOO_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			uwgOO_HT.DataSource = Search();
			uwgOO_HT.DataBind();
			
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = uwgOOS_HT;
			bool check = true;
			
			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count >= 15)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
				//��������� 0�ΰ��� ����
				for(int count = UWG.Rows.Count -1 ; count >=0 ; count--)
				{
					if(decimal.Parse(UWG.Rows[count].Cells.FromKey("ThistimeOutStorehouseQuantity").Text.Trim()) == 0)
						UWG.Rows[count].Delete();
				}
					
				Session["Grid"] = UWG;
				//RegisterStartupScript("","<script>window.open('./Popup/OutSideOutStorehousePurchase.aspx','','width=1100,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
				RegisterStartupScript("","<script>window.open('./Popup/OutSideStorehousePurchase.aspx','','width=795,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
			
			}			
		}
	}
}
