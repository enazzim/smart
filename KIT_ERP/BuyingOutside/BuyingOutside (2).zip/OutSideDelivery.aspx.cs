using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideDelivery�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideDelivery : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.TextBox txtItemNum;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOD_HT;
		protected System.Web.UI.WebControls.TextBox txtDeliveryQuantity;
		protected System.Web.UI.WebControls.TextBox txtOrderQuantity;
		protected System.Web.UI.WebControls.TextBox txtCashQuantity;
		protected System.Web.UI.WebControls.TextBox txtItemName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden IndexNum;
		protected System.Web.UI.HtmlControls.HtmlInputHidden UnitCost;
		protected System.Web.UI.HtmlControls.HtmlInputHidden HistoryIndex;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcDeliveryDate;
		protected System.Web.UI.WebControls.TextBox txtRemainQuantity;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdLotNum;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected System.Web.UI.WebControls.TextBox txtCost;
		protected System.Web.UI.WebControls.DropDownList ddlYear;
		protected System.Web.UI.WebControls.DropDownList ddlMon;
		protected System.Web.UI.WebControls.Button btnRegistration;
		protected System.Web.UI.HtmlControls.HtmlInputHidden Hidden1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			ItemSearchControl1.HalfFinishedProducts = true; //����ǰ ���ε�
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction="���ְŷ�ó";
				


			if(!Page.IsPostBack)
			{

				wdcDeliveryDate.NullDateLabel = DateTime.Now.ToShortDateString();
				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";

				foreach(ListItem list in ddlYear.Items)
				{
					if(list.Value == DateTime.Now.Year.ToString())
					{
						list.Selected = true;
					}
				}

				for(int a = 0; a < ddlMon.Items.Count; a++)
				{
					if(DateTime.Now.Month == 12)
					{
						if(DateTime.Now.Day > 25)
						{
							for(int b = 0; b< ddlYear.Items.Count;b++)
							{
								ddlYear.Items[b].Selected = false;
								if(int.Parse(ddlYear.Items[b].Value) == DateTime.Now.Year + 1)
									ddlYear.Items[b].Selected = true;
							}
							ddlMon.Items[0].Selected = true;							
							break;
						}
						else
						{
							ddlMon.Items[DateTime.Now.Month-1].Selected = true;
							break;
						}
					}
					else
					{
						if(ddlMon.Items[a].Value == DateTime.Now.Month.ToString() )
						{
							if(DateTime.Now.Day > 25)
								ddlMon.Items[a+1].Selected = true;
							else
								ddlMon.Items[a].Selected = true;
							break;
						}
					}
				}
			}


		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.uwgOD_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgOD_HT_PageIndexChanged);
			this.btnRegistration.Click += new System.EventHandler(this.btnRegister_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		//�˻���ư Ŭ��
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgOD_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgOD_HT.DataSource = Search();
			this.uwgOD_HT.DataBind();

			this.txtDeliveryQuantity.Text = null;//�˻� ��ư ���������� ��ǰ���� �ؽ�Ʈ�ڽ� �ʱ�ȭ
		}

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("OutSideDelivery",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName, wdcStartDate, ddlItemClassification1.SelectedItem.Value,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			else
				search = new KIT_ERP.Search("OutSideDelivery",ItemSearchControl1.ItemNum, "", "", wdcStartDate, ddlItemClassification1.SelectedItem.Value,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum);
			return search.DataSet_search();
		}

		//��ǰ��� Ŭ��
		private void btnRegister_Click(object sender, System.EventArgs e)
		{
			if(HistoryIndex.Value.Trim() =="")
			{
				Response.Write("<script language='javascript'>");
				Response.Write("alert('ǰ���� �����ϼ���');");
				Response.Write("</script>");

			}
			else if(this.txtDeliveryQuantity.Text == "0" || this.txtDeliveryQuantity.Text.Trim() == "")
			{
				Response.Write("<script language='javascript'>");
				Response.Write("alert('��ǰ������ �Էµ��� �ʾҽ��ϴ�. �Է����ּ���');");
				Response.Write("</script>");
			}
			else
			{
				
				ArrayList OD_HTArraylist = new ArrayList();
				OD_HTArraylist.Add(int.Parse(HistoryIndex.Value));//���屸��
				OD_HTArraylist.Add(int.Parse(IndexNum.Value));//�ش�����ȣ
				OD_HTArraylist.Add(decimal.Parse(txtDeliveryQuantity.Text));//��ǰ����

				//��ǰ���� �Է����� ������ ����� ��¥�� �ڵ� �Էµȴ�.
				if(this.wdcDeliveryDate.Value == null)
				{
					OD_HTArraylist.Add(DateTime.Now.ToShortDateString()); //��ǰ��
				}
				else
				{
					OD_HTArraylist.Add(DateTime.Parse(wdcDeliveryDate.Text)); //��ǰ��
				}		

				OD_HTArraylist.Add(txtCost.Text); //�ܰ�
				OD_HTArraylist.Add(""); //Lot
				OD_HTArraylist.Add(ddlYear.SelectedItem.Value); //���Գ�
				OD_HTArraylist.Add(ddlMon.SelectedItem.Value); //���Կ�
				OD_HTArraylist.Add(UnitCost.Value); //ǥ�شܰ�

				if(MonthClosing())
				{
				
					KIT_ERP.Register register = new KIT_ERP.Register(OD_HTArraylist,"OutSideDelivery",Session["ID"].ToString());
					register.Registration();
				}
				else
				{
					RegisterStartupScript("","<script>alert('�������� �Ǿ� �԰��� �Ұ��� �մϴ�!');</script>");
				}				
				

				this.uwgOD_HT.DataSource = Search();
				this.uwgOD_HT.DataBind();

				this.txtDeliveryQuantity.Text = "0";//�˻� ��ư ���������� ��ǰ���� �ؽ�Ʈ�ڽ� �ʱ�ȭ
				this.wdcDeliveryDate.Value = null; //��ǰ�� �ʱ�ȭ
				txtCost.Text = "0";

			}			
		}


		

		private void btLot_Click(object sender, System.EventArgs e)
		{
			Response.Write("<script>window.open('../LotNumberManagement.aspx','LotNumberManagement','width=760,height=400,left=300,top=400, center=yes, resizable= yes');</script>");				
		}

		private void uwgOD_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgOD_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			this.uwgOD_HT.DataSource = Search();
			uwgOD_HT.DataBind();
		}

		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			if(year < int.Parse(ddlYear.SelectedItem.Value))
				return true;
			else if(year == int.Parse(ddlYear.SelectedItem.Value))
			{
				if(month < int.Parse(ddlMon.SelectedItem.Value))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		

			
		}

		
	}
}
