using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Infragistics.WebUI.UltraWebGrid;
using System.Text;

using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	public class QualityInspectionPresentCondition : KIT_ERP.QualityInspection.QualityInspection_BaseClass
	{
		protected System.Web.UI.WebControls.TextBox txtSuccessQuantity;
		protected string strEditMsg;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.WebControls.DropDownList ddlProcessDiv;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser txtStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser txtEndDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid DataGrid1;
		protected System.Web.UI.WebControls.Literal Literal1;
		protected System.Web.UI.WebControls.Literal Literal2;
		protected System.Web.UI.WebControls.Literal Literal3;
		protected System.Web.UI.WebControls.Literal Literal4;
		protected System.Web.UI.WebControls.Literal Literal5;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnReset;	
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdSucessQuantity;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdIncongruityQuantity;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdIndex;
		protected ArrayList arrlist = new ArrayList();
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdBeforeSucessQauntity;
		protected System.Web.UI.WebControls.Button btExcel;
		protected System.Web.UI.WebControls.Button btCancle;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter UltraWebGridExcelExporter1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdUpdateRegion;
		protected System.Web.UI.WebControls.DropDownList ddlDivision;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdOldMonth;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdBeforeApplyUintCost;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl  ItemSearchControl1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected int index;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdyear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdmon;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdyear1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdmon1;
		protected string[] vals ;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			ItemSearchControl1.Commodity = true;
			ItemSearchControl1.Products = true;
			ItemSearchControl1.HalfFinishedProducts = true;
			ItemSearchControl1.RawMaterials = true;
			CSC1.UnitCostDistinction ="���ſ���";

			if (!IsPostBack) 
			{
				btnReset.Attributes.Add("onclick", "ResetTextBox();ResettxtBox();");
				btCancle.Attributes.Add("onclick","return OK('������ ǰ��鿡 ���Ͽ� �˻縦 ���');");
			}
			else 
			{
				
				Response.Write(" 	<script >  var MonthCloseing = \"0\";    function EditRegistCheck() { document.QualityInspectionPresentCondition.hdUpdateRegion.value = document.QualityInspectionPresentCondition.UpdateRegion.value;  if(document.QualityInspectionPresentCondition.txtSuccessQuantity.value == \"\") {   alert(\"���ռ����� ������ ���Ե��� �ʾҽ��ϴ�.\");     return false;}   if(confirm(\"���� ǰ���� ���� �Ͻðڽ��ϱ�?\")) return true; else return false; }</script> ");
				
			}
		}



		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.DataGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.DataGrid1_PageIndexChanged);
			this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
			this.Button3.Click += new System.EventHandler(this.Button3_Click);
			this.btCancle.Click += new System.EventHandler(this.btCancle_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion





		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			DataGrid1.DisplayLayout.Pager.CurrentPageIndex = 1;
			SByte sbyteProcessDiv = Convert.ToSByte(ddlProcessDiv.SelectedItem.Value);
			
			// �˻� ��ü ����
			KIT_ERP.QualityInspection.QualityInspection_Search qis = new KIT_ERP.QualityInspection.QualityInspection_Search
				(
				PageNames.ǰ���˻���Ȳ
				, ItemSearchControl1.ItemNum
				, ItemSearchControl1.ItemDrawNum
				, ItemSearchControl1.ItemName
				, txtStartDate.Text
				, txtEndDate.Text
				, CSC1.Company
				, CSC1.BusinessRegistrationNum
				, sbyteProcessDiv
				, ddlDivision.SelectedItem.Value
				);

			DataTable dt_Source = qis.GetDataSet().Tables[0];
			
			// �׸��� �ϴ� ��� ��� �޼ҵ� ȣ��
			this.SUM_and_AVG_(dt_Source);
			
			DataGrid1.DataSource = dt_Source.DefaultView;
			DataGrid1.DataKeyField = "��ȣ";
			DataGrid1.DataBind();

			Session["DT1"] = dt_Source;
		}	




		// �׸��� �ϴ� ���ڵ� ��� ����Ͽ� ����ϴ� �޼ҵ�
		private void SUM_and_AVG_(DataTable dt)
		{
			decimal dE_totalRequestQuantity = 0;
			decimal dE_totalSuitabilityQuantity = 0;
			decimal dE_totalUnSuitabilityQuantity = 0;
			decimal dE_TotalPPM = 0;

			foreach ( DataRow drow in dt.Rows )
			{
				dE_totalRequestQuantity += Convert.ToDecimal(drow[8]);
				dE_totalSuitabilityQuantity +=  Convert.ToDecimal(drow[22]);
				dE_totalUnSuitabilityQuantity +=  Convert.ToDecimal(drow[24]);
			}

			if ( dE_totalRequestQuantity != 0 )
			{
				dE_TotalPPM = ( dE_totalUnSuitabilityQuantity / dE_totalRequestQuantity ) * 1000000;

				Literal1.Text = "�� <b>\" " + dt.Rows.Count.ToString() + " \"</b> ��" ;
				Literal2.Text = "�Ƿڼ��� : <b>" + dE_totalRequestQuantity.ToString().Substring(0, dE_totalRequestQuantity.ToString().IndexOf(".") + 2) + "</b>";
				Literal3.Text = "���ռ��� : <b>" + dE_totalSuitabilityQuantity.ToString().Substring(0, dE_totalSuitabilityQuantity.ToString().IndexOf(".") + 2) + "</b>";
				Literal4.Text = "�����ռ��� : <b>" + dE_totalUnSuitabilityQuantity.ToString().Substring(0, dE_totalUnSuitabilityQuantity.ToString().IndexOf(".") + 2 ) + "</b>";

			
				if (dE_TotalPPM > 0)
				{
					try
					{
						Literal5.Text = "<b>" + dE_TotalPPM.ToString().Substring( 0, (dE_TotalPPM.ToString()).IndexOf(".") + 3 ) + "</b> PPM";
					}
					catch
					{
						Literal5.Text = "<b>" + dE_TotalPPM + "</b> PPM";	
					}
				}
				else 
					Literal5.Text = "<b>0</b> PPM";
			}
		}


		// aspx���� template Row ���� ���
		protected DataSet DDL_DataSource
		{
			get
			{
				KIT_ERP.QualityInspection.QualityInspection_InputReady qi = new  KIT_ERP.QualityInspection.QualityInspection_InputReady();
				DataSet ds = qi.DDL_DataSource();
				
				return ds;
			}
		}



		private void DataGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			DataGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			DataGrid1.DataSource = ((DataTable)Session["DT1"]).DefaultView;
			DataGrid1.DataBind();
		}

		// ������Ʈ( __doPostBack �� ���� ��ư �̺�Ʈ )
		private void Button3_Click(object sender, System.EventArgs e)
		{
			index = int.Parse(hdIndex.Value);

			vals =  Request.Params["hidden_TemplateRow_UpdateValue"].ToString().Split('��');
			
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			con.Open();
			
			SqlTransaction trans = con.BeginTransaction();
			
			try
			{
						
				if(MonthClosing())
				{
					//�����հݼ����� �ҷ����� ����
					arrlist.Add(hdBeforeSucessQauntity.Value);
					arrlist.Add(hdIncongruityQuantity.Value);

					//if(decimal.Parse(arrlist[0].ToString()) != decimal.Parse(hdSucessQuantity.Value))
					//{
					//���Ű��ü���ó��
					if(vals[12].ToString() == "����")
					{
						BuyingUpdate(con,trans);
						DeliveryHistoryUpdate(con,trans,vals);	
						BuyingDeliveryUpdate(con,trans,vals);					//���Ű��԰� �ݾ׼���
					}
					else if(vals[12].ToString() == "����")
					{	//���ְ��ü���ó��
						OutSideUpdate(con,trans);
						DeliveryHistoryUpdate(con,trans, vals);					//
						OutSideDeliveryUpdate(con,trans,vals);
					}
					else
					{
						//throw new Exception("�ڰ�ǰ���� �˻���Ұ� �Ұ��� �մϴ�. �۾��Ϻ���Ȳ���� �����Ͽ��ּ���!");
						//�ڰ�ó��
						SelfUpdate(con,trans);				
					}
					//}

					KIT_ERP.QualityInspection.QualityInspection_Edit qiEdit = new  KIT_ERP.QualityInspection.QualityInspection_Edit(vals);
					qiEdit.Edit();
			

					//btnSearch_Click(this.btnSearch, null);
					Search();

					hdSucessQuantity.Value = "0";
					hdIncongruityQuantity.Value = "0";
					hdIndex.Value = "0";
					trans.Commit();
				}
				else
				{
					throw new Exception("�������� �Ǿ� ������ �Ұ��� �մϴ�!");
				}

				
			}
			catch(Exception ee)
			{
				Response.Write("<script>alert('"+ee.Message +"');</script>");

				trans.Rollback();
			}
			finally
			{
				con.Close();
			}

		}

		private void Search()
		{
			SByte sbyteProcessDiv = Convert.ToSByte(ddlProcessDiv.SelectedItem.Value);
			
			// �˻� ��ü ����
			KIT_ERP.QualityInspection.QualityInspection_Search qis = new KIT_ERP.QualityInspection.QualityInspection_Search
				(
				PageNames.ǰ���˻���Ȳ
				, ItemSearchControl1.ItemNum
				, ItemSearchControl1.ItemDrawNum
				, ItemSearchControl1.ItemName
				, txtStartDate.Text
				, txtEndDate.Text
				, CSC1.Company
				, CSC1.BusinessRegistrationNum
				, sbyteProcessDiv
				, ddlDivision.SelectedItem.Value
				);

			DataTable dt_Source = qis.GetDataSet().Tables[0];
			
			// �׸��� �ϴ� ��� ��� �޼ҵ� ȣ��
			this.SUM_and_AVG_(dt_Source);
			
			DataGrid1.DataSource = dt_Source.DefaultView;
			DataGrid1.DataKeyField = "��ȣ";
			DataGrid1.DataBind();

			Session["DT1"] = dt_Source;
		}

		private void DeliveryHistoryUpdate(SqlConnection conn,SqlTransaction tr, string[] list)
		{
			SqlCommand comm = new SqlCommand();
			comm.Connection=conn;
			comm.Transaction = tr;

			string str = "";
			
			if(DataGrid1.Rows[index].Cells.FromKey("historysection1").Text == "����")
			{
				if(Division(DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text) == "������")
					str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason,[Date], UpdatePerson, UpdatePersonID, HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,0,'14000000','����',@CompanyName, @BusinessRegistrationNum, @Quantity,@UnitCost,@UpdateHistoryReason,@Date,@Person, @PersonID, '���ų�ǰ',@HistoryIndex)";
				else
					str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason,[Date], UpdatePerson, UpdatePersonID, HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,99,'14009999','����ǰ',@CompanyName, @BusinessRegistrationNum, @Quantity,@UnitCost,@UpdateHistoryReason,@Date,@Person, @PersonID, '���ų�ǰ',@HistoryIndex)";

				comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text);									//ǰ���ȣ
				comm.Parameters.Add("@itemdrawnum", DataGrid1.Rows[index].Cells.FromKey("ItemDrawNum").Text);								//�����ȣ
				comm.Parameters.Add("@itemname",DataGrid1.Rows[index].Cells.FromKey("ItemName").Text);									//ǰ���
				comm.Parameters.Add("@CompanyName", DataGrid1.Rows[index].Cells.FromKey("CompanyName").Text);								//��ü��
				comm.Parameters.Add("@BusinessRegistrationNum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
				comm.Parameters.Add("@Quantity",decimal.Parse(list[1]));					//����� ����
				comm.Parameters.Add("@UnitCost",decimal.Parse(list[21]));					//����� ����
				comm.Parameters.Add("@UpdateHistoryReason",hdUpdateRegion.Value);
				comm.Parameters.Add("@Date",DateTime.Now.ToShortDateString());								//�������
				comm.Parameters.Add("@Person",Session["UserName"].ToString());
				comm.Parameters.Add("@PersonID",Session["ID"].ToString());
				comm.Parameters.Add("@HistoryIndex",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex1").Text));
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				//SH_HT���� ����
				str = @"Update SH_HT Set Quantity = @Quantity where HistoryDivision ='ǰ���˻�' and HistoryIndex  = @HistoryIndex";
				comm.Parameters.Add("@Quantity",decimal.Parse(list[1]));					//����� ����
				comm.Parameters.Add("@HistoryIndex",int.Parse(list[0]));
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

			}
			else if(DataGrid1.Rows[index].Cells.FromKey("historysection1").Text == "����")
			{
				str=@"Insert into BOS_HT (ItemNum,ItemDrawNum,ItemName,ProcessSequenceNum,ProcessCode,ProcessName,CompanyName, BusinessRegistrationNum,Quantity,UnitCost,UpdateHistoryReason,[Date], UpdatePerson, UpdatePersonID, HistoryDivision,HistoryIndex) values(
				@itemnum,@itemdrawnum,@itemname,@ProcessSequenceNum,@ProcessCode,@ProcessName,@CompanyName, @BusinessRegistrationNum, @Quantity,@UnitCost,@UpdateHistoryReason,@Date,@Person, @PersonID, '���ֳ�ǰ',@HistoryIndex)";

				comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text);									//ǰ���ȣ
				comm.Parameters.Add("@itemdrawnum", DataGrid1.Rows[index].Cells.FromKey("ItemDrawNum").Text);								//�����ȣ
				comm.Parameters.Add("@itemname",DataGrid1.Rows[index].Cells.FromKey("ItemName").Text);									//ǰ���
				comm.Parameters.Add("@ProcessSequenceNum",int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Text));											//��������
				comm.Parameters.Add("@ProcessCode",DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Text);											//�����ڵ�
				comm.Parameters.Add("@ProcessName",DataGrid1.Rows[index].Cells.FromKey("���������").Text);												//������
				comm.Parameters.Add("@CompanyName", DataGrid1.Rows[index].Cells.FromKey("CompanyName").Text);								//��ü��
				comm.Parameters.Add("@BusinessRegistrationNum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
				comm.Parameters.Add("@Quantity",decimal.Parse(list[1]));					//����� ����
				comm.Parameters.Add("@UnitCost",decimal.Parse(list[21]));	
				comm.Parameters.Add("@UpdateHistoryReason",hdUpdateRegion.Value);
				comm.Parameters.Add("@Date",DateTime.Now.ToShortDateString());								//�������
				comm.Parameters.Add("@Person",Session["UserName"].ToString());
				comm.Parameters.Add("@PersonID",Session["ID"].ToString());
				comm.Parameters.Add("@HistoryIndex",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex1").Text));
				
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				InsertSH_HT(conn,tr,vals);
			}
		}

		private void InsertSH_HT(SqlConnection conn, SqlTransaction tr, string[] list)
		{

			

			SqlCommand comm = new SqlCommand();
			comm.Connection=conn;
			comm.Transaction = tr;

			
			//���� ������������ �Ʒ��� ���������� �ִ��� �������� ���Ѵ�
			int sequence1 = 0;	//��������
			string Code = "";	// �����ڵ�
			string Name = "";	// ������
			string str = "Select Max(ProcessSequenceNum) From PSI_MT Where RecodingState = 1 and ProcessSequenceNum < @num and ItemNum = @itemnum";
			
			comm.Parameters.Add("@num", int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Text));
			comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text);
			comm.CommandText = str;
			if(comm.ExecuteScalar() == null || comm.ExecuteScalar().ToString().Trim() == "")
				sequence1 = 0;
			else
				sequence1 = int.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();
			
			str = "Select ProcessCode From PSI_MT Where RecodingState = 1 and ProcessSequenceNum = @num and ItemNum = @itemnum";
			comm.Parameters.Add("@num", sequence1);
			comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text);
			comm.CommandText = str;
			SqlDataReader dr2 = comm.ExecuteReader();
			while(dr2.Read())
			{
				Code = dr2["ProcessCode"].ToString();
			}
			dr2.Close();
			comm.Parameters.Clear();

			str = "Select SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and SmallClassificationCode = @code";
			comm.Parameters.Add("@code",SqlDbType.VarChar).Value = Code;
			comm.CommandText = str;
			SqlDataReader dr3 = comm.ExecuteReader();
			while(dr3.Read())
			{
				Name = dr3["SmallClassificationName"].ToString();
			}
			dr3.Close();
			comm.Parameters.Clear();
		

			

			// �Ʒ� ����������ȣ�� �����Ҷ���(���������� 0�� �ƴ� ���) �ٷ� �� ǰ���� �����Ų��.
			// ���� ����ִ� ����������ȣ�� ǰ���� �����Ų��.
			string st_ItemNum = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Text;

			if(sequence1 != 0)
			{
				str = @"Update SH_HT Set Quantity = @Quantity where HistoryDivision ='ǰ���˻�' and HistoryIndex  = @HistoryIndex";
				comm.Parameters.Add("@Quantity",decimal.Parse(list[1]));					//����� ����
				comm.Parameters.Add("@HistoryIndex",int.Parse(list[0]));
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

			}
			else
			{
				// ������ȣ�� 0 �̸� ����ǰ���� ã�� ���ÿ� Push�Ѵ�
				Stack st = new Stack();	

				string item = "";
				//����ǰ���� ã�����ؼ��� ǰ�񱸼������� ���� ǰ���� ��ǰ���� �ϴ� ��� ���ڵ带 ���ÿ� �ִ´�
				//str = "Select ChildItemNum, ItemDrawNum, Item From IOI_MT JOIN ON II_MT Where RecodingState = 1 and ParentItemNum = @itemnum";
				str = @"SELECT ItemNum, ItemDrawNum, ItemName, NeedQuantityNumerator, NeedQuantityDenominator FROM II_MT INNER JOIN IOI_MT ON II_MT.ItemNum = IOI_MT.ChildItemNum 	WHERE (II_MT.RecodingState = 1) AND (IOI_MT.RecodingState = 1) AND (IOI_MT.ParentItemNum = @itemnum) ";
				comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = st_ItemNum;
				comm.CommandText=str;
				SqlDataReader dr_Child = comm.ExecuteReader();
				while(dr_Child.Read())
				{
					st.Push(dr_Child["ItemNum"].ToString());
				}
				dr_Child.Close();
				comm.Parameters.Clear();
				
				
				// ���ÿ� ǰ���� �ִ��� Ȯ���Ѵ�.
				if(st.Count != 0)
				{
					// ������ ������ ������ �� ���������� ��� Pop�Ѵ�
					while(st.Count > 0)
					{	
						item =st.Pop().ToString();
						decimal quantity = 1;

						// ����ǰ���� ���������� ����1�� �ִ´�
						Stack st1 = new Stack();					
						int sequencenum=0;

						//���� ǰ���� ���������� �־�д�.
						str = "Select ProcessSequenceNum from PSI_MT where RecodingState = 1 AND ItemNum = @itemnum  order by ProcessSequenceNum";
						comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
						comm.CommandText = str;
						SqlDataReader dr_Sequence = comm.ExecuteReader();
						while(dr_Sequence.Read())
						{
							//��������
							st1.Push(int.Parse(dr_Sequence["ProcessSequenceNum"].ToString()));
							
						}
						dr_Sequence.Close();
						comm.Parameters.Clear();

						//����ǰ���� �ҿ䷮�� �־�д�
						str = "select * From IOI_MT Where ParentItemNum = @num and ChildItemNum = @item and RecodingState = 1 ";
						comm.Parameters.Add("@num",st_ItemNum);
						comm.Parameters.Add("@item",item);
						comm.CommandText = str;
						SqlDataReader dr1 = comm.ExecuteReader();
						while(dr1.Read())
						{
							quantity = decimal.Round(decimal.Parse(dr1["NeedQuantityNumerator"].ToString())/decimal.Parse(dr1["NeedQuantityDenominator"].ToString()),3);
						}
						dr1.Close();
						comm.Parameters.Clear();

						//���������� ������ ���� ǰ���� �������̹Ƿ� �̸� �����Ų��.
						if(st1.Count == 0)
						{
							//ǰ��,����,ǰ�� ���Ѵ�
							string itemdraw=""; string name="";
							str = "Select * From II_MT Where ItemNum = @num and RecodingState = 1";
							comm.Parameters.Add("@num",SqlDbType.VarChar).Value = item;
							comm.CommandText = str;
							SqlDataReader dr_Item = comm.ExecuteReader();
							while(dr_Item.Read())
							{
								itemdraw = dr_Item["ItemDrawNum"].ToString();
								name = dr_Item["ItemName"].ToString();
							}
							dr_Item.Close();
							comm.Parameters.Clear();

							str = @"Update SH_HT Set Quantity = @Quantity where ItemNum = @itemnum and  HistoryDivision ='ǰ���˻�' and HistoryIndex  = @HistoryIndex";
							comm.Parameters.Add("@itemnum",item);									//ǰ���ȣ
							comm.Parameters.Add("@Quantity",decimal.Parse(list[1])*quantity);					//����� ����
							comm.Parameters.Add("@HistoryIndex",int.Parse(list[0]));
							comm.CommandText = str;
							comm.ExecuteNonQuery();
							comm.Parameters.Clear();
							
							
						}
						else //�׷��� ������ �� ǰ���� �ֻ��� ���������� ã�Ƽ� �� ������ �������� �Ǵ��Ѵ�. ī��Ʈ�� 0�̸� ���ְ� �ƴϹǷ� �����Ų��.
						{
							// ����1�� �ִ� ���������� �ϳ���������.
							while(st1.Count > 0)
							{
								sequencenum = int.Parse(st1.Pop().ToString());
								str = " SELECT  count(*) FROM PSI_MT WHERE RecodingState = 1 and WorkDistinction <> '����' and ItemNum = @item and ProcessSequenceNum = @num";
								comm.Parameters.Add("@item",SqlDbType.VarChar).Value = item;//ǰ���ȣ
								comm.Parameters.Add("@num",SqlDbType.VarChar).Value = sequencenum;//��������
								comm.CommandText=str;
								int aaa = int.Parse(comm.ExecuteScalar().ToString());
								comm.Parameters.Clear();
								

								//ǰ��,����,ǰ�� ���Ѵ�
								string itemdraw=""; string name="";
								str = "Select * From II_MT Where ItemNum = @num";
								comm.Parameters.Add("@num",SqlDbType.VarChar).Value = item;
								comm.CommandText =str;
								SqlDataReader dr_Item = comm.ExecuteReader();
								while(dr_Item.Read())
								{
									itemdraw = dr_Item["ItemDrawNum"].ToString();
									name = dr_Item["ItemName"].ToString();
								}
								dr_Item.Close();
								comm.Parameters.Clear();

								//�����ڵ�� �������� ���Ѵ�
								string processcode="";string processname="";
								str = " SELECT  ProcessSequenceNum, ProcessCode, SmallClassificationName " +
									" FROM      PSI_MT INNER JOIN " +
									" PUC_MT ON ProcessCode = SmallClassificationCode " +
									" WHERE PSI_MT.RecodingState = 1 AND ItemNum = @itemnum and ProcessSequenceNum = @num";
								comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
								comm.Parameters.Add("@num",SqlDbType.VarChar).Value = sequencenum;
								comm.CommandText=str;
								SqlDataReader dr_code = comm.ExecuteReader();
								while(dr_code.Read())
								{
									processcode = dr_code["ProcessCode"].ToString();//�����ڵ�
									processname = dr_code["SmallClassificationName"].ToString();//������
								}
								dr_code.Close();
								comm.Parameters.Clear();

								// ���ְ� �ƴϸ� ���
								if(aaa != 0)
								{
									str = @"Update SH_HT Set Quantity = @Quantity where ItemNum = @itemnum and  HistoryDivision ='ǰ���˻�' and HistoryIndex  = @HistoryIndex";
									comm.Parameters.Add("@itemnum",item);									//ǰ���ȣ
									comm.Parameters.Add("@Quantity",decimal.Parse(list[1])*quantity);					//����� ����
									comm.Parameters.Add("@HistoryIndex",int.Parse(list[0]));
									comm.CommandText = str;
									comm.ExecuteNonQuery();
									comm.Parameters.Clear();
									
									st1.Clear();
									break;
								}
								else//�����̸� ���ִܰ����� ���� ã�� �����̶� ��������� �����Ѱ��� �ִ��� ���캻��. ������ �����Ű�� ������ ���������� ã�´�
								{
									// ���ִܰ����� ����ȸ�� ���ְ������� �ľ��Ѵ�.
									str = "select count(*) From UCI_MT Where RecodingState = 1 and ItemNum = @itemnum and EndProcessCode = @code and BusinessRegistrationNum = @com";
									comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = item;
									comm.Parameters.Add("@code",SqlDbType.VarChar).Value = processcode;
									comm.Parameters.Add("@com",SqlDbType.VarChar).Value = list[20].Trim() ;
									comm.CommandText = str;
									int find = int.Parse(comm.ExecuteScalar().ToString());
									comm.Parameters.Clear();
									

									// ����ȸ�簡 �ƴϸ� ���
									if(find == 0)
									{
										// �����ͼ¿� �߰��ϱ����� Row
										str = @"Update SH_HT Set Quantity = @Quantity where ItemNum = @itemnum and  HistoryDivision ='ǰ���˻�' and HistoryIndex  = @HistoryIndex";
										comm.Parameters.Add("@itemnum",item);									//ǰ���ȣ
										comm.Parameters.Add("@Quantity",decimal.Parse(list[1])*quantity);					//����� ����
										comm.Parameters.Add("@HistoryIndex",int.Parse(list[0]));
										comm.CommandText = str;
										comm.ExecuteNonQuery();
										comm.Parameters.Clear();

										st1.Clear();
										break;
									}
								}
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// �ڰ����� �����Լ�
		/// </summary>
		private void SelfUpdate(SqlConnection conn,SqlTransaction tr)
		{

			int year = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Year;
			int mon = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Month;
			Table table = new Table(year,mon);

			SqlCommand comm = new SqlCommand();
			

			//�۾���ȹ�� �Ϸ������ �����Ѵ�
			string str = "Update WDWP_HT Set WorkCompletionQuantity = WorkCompletionQuantity - @WorkCompletionQuantity Where WCDailyWorkPlanHistoryIndex = @Index";
			
			comm.Connection = conn;
			comm.Transaction = tr;
			comm.CommandText = str;
			comm.Parameters.Add("@WorkCompletionQuantity",decimal.Parse(arrlist[0].ToString()));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���� ���ռ������� �����Ѵ�.
			str = "Update WDWP_HT Set WorkCompletionQuantity = WorkCompletionQuantity + @WorkCompletionQuantity Where WCDailyWorkPlanHistoryIndex = @Index";
			comm.CommandText = str;
			comm.Parameters.Add("@WorkCompletionQuantity",decimal.Parse(hdSucessQuantity.Value));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();


			//�Ϸ������ ��ȹ�������� ������ ������¸� '����'���� �����Ų��.
			decimal Plan = 0;
			decimal Complete = 0;

			str = "Select WorkPlanQuantity,WorkCompletionQuantity From WDWP_HT Where  WCDailyWorkPlanHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			SqlDataReader dr_Quantity = comm.ExecuteReader();
			while(dr_Quantity.Read())
			{
				Plan = decimal.Parse(dr_Quantity["WorkPlanQuantity"].ToString());
				Complete = decimal.Parse(dr_Quantity["WorkCompletionQuantity"].ToString());
			}
			dr_Quantity.Close();
						
			if(Complete - Plan < 0)
				str = "Update OO_HT Set ProgressCondition = '����' Where  OutSideOrderHistoryIndex = @index";
			else
				str = "Update OO_HT Set ProgressCondition = '�Ϸ�' Where  OutSideOrderHistoryIndex = @index";

			comm.CommandText = str;
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();




			//����â������ ����
			// ��ô������ ���ؾ� �Ѵ�
			decimal rate = 100;	//��ô����(���������� �ִ� ��ô������ �־�д�.

			str = "Select OutsideOrderRate, ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @item and ProcessSequenceNum = @num";
			comm.CommandText =str;
			comm.Parameters.Add("@item",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString());
			comm.Parameters.Add("@num",int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Value.ToString()));
			SqlDataReader dr_Rate = comm.ExecuteReader();
			while(dr_Rate.Read())
			{
				rate = decimal.Parse(dr_Rate["ProgressRate"].ToString());
			}
			dr_Rate.Close();
			comm.Parameters.Clear();

			str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString());
			comm.CommandText =str;	
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = Decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			//�������̺����� ���������� ���̳ʽ� ����
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (-(decimal.Parse(arrlist[0].ToString()))*unitcost)* (rate/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(arrlist[0].ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
			comm.Parameters.Add("@year", year);
			comm.CommandText = table.InProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value)*unitcost*(rate/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value);
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
			comm.Parameters.Add("@year", year);
			comm.CommandText = table.InProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			str = "select Max(ProcessSequenceNum) From PSI_MT Where RecodingState = 1 and ItemNum = @ItemNum";
			comm.Parameters.Add("@ItemNum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString());
			comm.CommandText = str;
			int ProSeq = int.Parse(comm.ExecuteScalar().ToString());

			//conn.Close();
			//�ش� ǰ���� �ڻ�з��� ��ǰ�̸鼭 ������ ��������̸� �԰��Ƿڿ����� �հݼ����� �����Ѵ�
			if(Division(DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString()) == "��ǰ")				
			{
				if(ProSeq == int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Value.ToString()))
				{
					//conn.Open();
					str = "Update ISR_HT Set InstorehouseRequestQuantity = @InstorehouseRequestQuantity where HistoryIndex = @HistoryIndex and HistorySection = '�۾��Ϻ�'";
					comm.CommandText = str;
					comm.Parameters.Add("@InstorehouseRequestQuantity", decimal.Parse(hdSucessQuantity.Value));
					comm.Parameters.Add("@HistoryIndex", int.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionHistoryIndex").Value.ToString()));
					comm.ExecuteNonQuery();
					comm.Parameters.Clear();
					//conn.Close();
				}
			}



			//�۾��Ϻ� ��ȣ�� ã�� �����ȹ��ȣ�� ��������
			//�� �����ȹ��ȣ�� ������ �Ϸ������ �����Ѵ�.
			//�����Ϸ������  �����ȹ�������� ������ �����ȹ���� ������¸� �Ϸ�� ó��

			int idx = 0;
			str = "Select HistoryIndex2 From QI_HT Where HistorySection2 = '�۾���ȹ' and QualityInspectionHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionHistoryIndex").Value.ToString()));
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				idx = int.Parse(dr["HistoryIndex2"].ToString());
			}
			dr.Close();
			comm.Parameters.Clear();

			if(idx != 0)
			{
				string num = "";
				str = "Select ProductionPlanHistoryIndex From WDWP_HT where WCDailyWorkPlanHistoryIndex = @index";
				comm.CommandText = str;
				comm.Parameters.Add("@index",idx);
				SqlDataReader dr1 = comm.ExecuteReader();
				while(dr1.Read())
				{
					num = dr1["ProductionPlanHistoryIndex"].ToString();
				}
				dr1.Close();
				comm.Parameters.Clear();
				if(num != "")
				{
					str = "Update PP_HT Set  ProductionCompleteQuantity = ProductionCompleteQuantity - @quantity Where ProductionPlanHistoryIndex = @index";
					comm.CommandText = str;
					comm.Parameters.Add("@quantity",decimal.Parse(arrlist[0].ToString()));
					comm.Parameters.Add("@index",int.Parse(num));
					comm.ExecuteNonQuery();
					comm.Parameters.Clear();

					str = "Update PP_HT Set  ProductionCompleteQuantity = ProductionCompleteQuantity + @quantity Where ProductionPlanHistoryIndex = @index";
					comm.CommandText = str;
					comm.Parameters.Add("@quantity",decimal.Parse(hdSucessQuantity.Value));
					comm.Parameters.Add("@index",int.Parse(num));
					comm.ExecuteNonQuery();
					comm.Parameters.Clear();


					str = "Select (ProductionPlanQuantity - ProductionCompleteQuantity) as Quantity From PP_HT Where ProductionPlanHistoryIndex = @index";
					comm.CommandText = str;
					comm.Parameters.Add("@index",int.Parse(num));

					decimal Quantity1 = 0;
					SqlDataReader dr2 = comm.ExecuteReader();
					while(dr2.Read())
					{
						Quantity1 = decimal.Parse(dr2["Quantity"].ToString());
					}
					dr2.Close();
					comm.Parameters.Clear();
					//
					if(Quantity1 > 0)
					{
						str = "Update PP_HT Set ProgressCondition = '����'  Where ProductionPlanHistoryIndex = @index";
						comm.CommandText = str;
						comm.Parameters.Add("@index",int.Parse(num));
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();
					}
					else
					{
						str = "Update PP_HT Set ProgressCondition = '�Ϸ�'  Where ProductionPlanHistoryIndex = @index";
						comm.CommandText = str;
						comm.Parameters.Add("@index",int.Parse(num));
						comm.ExecuteNonQuery();
						comm.Parameters.Clear();
					}
				}
			}


			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM PS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code";
				comm.Parameters.Add("@ItemNum",SqlDbType.VarChar).Value =  DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
				comm.Parameters.Add("@year", year);
				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
						
				string StockQuantity = "False";
				string ItemName = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ������� �����մϴ�.");
				}
			}

			
		}


		/// <summary>
		/// ���ְ��� �����Լ�
		/// </summary>
		private void OutSideUpdate(SqlConnection conn,SqlTransaction tr)
		{
			//���ֹ��ֿ����� �ܷ����������� �Ѵ�
			//���ֹ��ֿ��� �����հݼ����� �ܷ����� �����ش�
			string str = "Update OO_HT Set RemainQuantity = RemainQuantity + @RemainQuantity where OutSideOrderHistoryIndex = @index";
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.CommandText = str;
			comm.Transaction = tr;
			comm.Parameters.Add("@RemainQuantity",decimal.Parse(arrlist[0].ToString()));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
			
			//���ֹ��ֿ��� �հݼ����� �ܷ��� ���ش�
			str = "Update OO_HT Set RemainQuantity = RemainQuantity - @RemainQuantity where OutSideOrderHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@RemainQuantity",decimal.Parse(hdSucessQuantity.Value));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//�ܷ��� ���ּ������� ������ ������¸� '����'���� �����Ų��.
			decimal Order = 0;
			decimal Remain = 0;

			str = "Select OrderQuantity,RemainQuantity From OO_HT Where  OutSideOrderHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				Order = decimal.Parse(dr["OrderQuantity"].ToString());
				Remain = decimal.Parse(dr["RemainQuantity"].ToString());
			}
			dr.Close();
						
			if(Remain > 0)
				str = "Update OO_HT Set ProgressCondition = '����' Where  OutSideOrderHistoryIndex = @index";
			else
				str = "Update OO_HT Set ProgressCondition = '�Ϸ�' Where  OutSideOrderHistoryIndex = @index";

			comm.CommandText = str;
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();



			// ���������̸� �����ȹ���忡 �Ϸ������ ����
			// ������� ����
			if(LastProcess(conn,tr))
			{
				int idx = 0;
				str = "Select HistoryIndex2 From QI_HT Where HistorySection2 = '���ֹ���' and QualityInspectionHistoryIndex = @index";
				comm.CommandText = str;
				comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionHistoryIndex").Value.ToString()));
				SqlDataReader reader = comm.ExecuteReader();
				while(reader.Read())
				{
					idx = int.Parse(reader["HistoryIndex2"].ToString());
				}
				reader.Close();
				comm.Parameters.Clear();

				if(idx != 0)
				{
					string number = "";
					str = "Select OutSideOrderRequestHistoryIndex From OO_HT where OutSideOrderHistoryIndex = @index";
					comm.CommandText = str;
					comm.Parameters.Add("@index",idx);
					SqlDataReader dr1 = comm.ExecuteReader();
					while(dr1.Read())
					{
						number = dr1["OutSideOrderRequestHistoryIndex"].ToString();
					}
					dr1.Close();
					comm.Parameters.Clear();
					if(number != "")
					{
						str = "select ProductionPlanHistoryIndex From OOR_HT where OutSideOrderRequestHistoryIndex = @index";
						comm.CommandText = str;
						comm.Parameters.Add("@index",number);
						SqlDataReader dr3 = comm.ExecuteReader();
						string num = "";
						while(dr3.Read())
						{
							num = dr3["ProductionPlanHistoryIndex"].ToString();
						}
						dr3.Close();
						comm.Parameters.Clear();

						if(num != "")
						{

							str = "Update PP_HT Set  ProductionCompleteQuantity = ProductionCompleteQuantity - @quantity Where ProductionPlanHistoryIndex = @index";
							comm.CommandText = str;
							comm.Parameters.Add("@quantity",decimal.Parse(arrlist[0].ToString()));
							comm.Parameters.Add("@index",int.Parse(num));
							comm.ExecuteNonQuery();
							comm.Parameters.Clear();

							str = "Update PP_HT Set  ProductionCompleteQuantity = ProductionCompleteQuantity + @quantity Where ProductionPlanHistoryIndex = @index";
							comm.CommandText = str;
							comm.Parameters.Add("@quantity",decimal.Parse(hdSucessQuantity.Value));
							comm.Parameters.Add("@index",int.Parse(num));
							comm.ExecuteNonQuery();
							comm.Parameters.Clear();

							str = "Select (ProductionPlanQuantity - ProductionCompleteQuantity) as Quantity From PP_HT Where ProductionPlanHistoryIndex = @index";
							comm.CommandText = str;
							comm.Parameters.Add("@index",int.Parse(num));

							decimal Quantity1 = 0;
							SqlDataReader dr2 = comm.ExecuteReader();
							while(dr2.Read())
							{
								Quantity1 = decimal.Parse(dr2["Quantity"].ToString());
							}
							dr2.Close();
							comm.Parameters.Clear();	
							//
							if(Quantity1 <= 0)
							{
								str = "Update PP_HT Set ProgressCondition = '�Ϸ�'  Where ProductionPlanHistoryIndex = @index";
								comm.CommandText = str;
								comm.Parameters.Add("@index",int.Parse(num));
								comm.ExecuteNonQuery();
								comm.Parameters.Clear();
							}
						}
					}
				}
			}



			int year = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Year;
			int mon = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Month;
				
			Table table = new Table(year,mon);


			//�������̺��� �ݾ��� ������Ų��(�����ݾ� ���̳ʽ��԰�,����ݾ� �÷��� �԰�)
			decimal BeforeCost = decimal.Parse(hdBeforeApplyUintCost.Value)*decimal.Parse(hdBeforeSucessQauntity.Value);
			comm.Parameters.Add("@comnum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
			comm.Parameters.Add("@year",year);
			comm.Parameters.Add("@cost", -BeforeCost);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			decimal NowCost = decimal.Parse(vals[1])*decimal.Parse(vals[21]);
			comm.Parameters.Add("@comnum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
			comm.Parameters.Add("@year",year);
			comm.Parameters.Add("@cost", NowCost);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();


			//����â������ ����
			// ��ô������ ���ؾ� �Ѵ�
			int sequence = int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Value.ToString());
			
			decimal Rate = 100;	//��ô����(���������� �ִ� ��ô������ �־�д�.

			str = "Select OutsideOrderRate, ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @item and ProcessSequenceNum = @num";
			comm.CommandText =str;
			comm.Parameters.Add("@item",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@num",SqlDbType.Int).Value = sequence;
			
			SqlDataReader dr_Rate1 = comm.ExecuteReader();
			while(dr_Rate1.Read())
			{
				Rate = decimal.Parse(dr_Rate1["ProgressRate"].ToString());
			}
			dr_Rate1.Close();
			comm.Parameters.Clear();

			str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			comm.Parameters.Add("@itemnum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString());
			comm.CommandText =str;	
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal UnitCost = Decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			//�������̺����� ���������� ���̳ʽ� ����
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (-(decimal.Parse(arrlist[0].ToString()))*UnitCost)* (Rate/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(arrlist[0].ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
			comm.Parameters.Add("@year",year);
			comm.CommandText = table.InProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value)*UnitCost*(Rate/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value);
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
			comm.Parameters.Add("@year",year);
			comm.CommandText = table.InProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			str = "select Max(ProcessSequenceNum) From PSI_MT Where RecodingState = 1 and ItemNum = @ItemNum";
			comm.Parameters.Add("@ItemNum",DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString());
			comm.CommandText = str;
			int ProSeq = int.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			//conn.Close();
			
			//�ش� ǰ���� �ڻ�з��� ��ǰ�̸鼭 ������ ��������̸� �԰��Ƿڿ����� �հݼ����� �����Ѵ�
			if(Division(DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString()) == "��ǰ")				
			{
				

				if(ProSeq == int.Parse(DataGrid1.Rows[index].Cells.FromKey("�����������").Value.ToString()))
				{
					//conn.Open();
					str = "Update ISR_HT Set InstorehouseRequestQuantity = @InstorehouseRequestQuantity where HistoryIndex = @HistoryIndex and HistorySection = 'ǰ���˻�'";
					comm.CommandText = str;
					comm.Parameters.Add("@InstorehouseRequestQuantity", decimal.Parse(hdSucessQuantity.Value));
					comm.Parameters.Add("@HistoryIndex", int.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionHistoryIndex").Value.ToString()));
					comm.ExecuteNonQuery();
					comm.Parameters.Clear();
					//conn.Close();
				}
			}


			//���̳ʽ� ������ ����
			if(MinusStore() == false)
			{
				string strSQL = "SELECT StockQuantity12 FROM PS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @code and [Year] = @year";
				comm.Parameters.Add("@ItemNum", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@code", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("��������ڵ�").Value.ToString();
				comm.Parameters.Add("@year",year);
									
				comm.CommandText = strSQL;
				SqlDataReader reader = comm.ExecuteReader();
				comm.Parameters.Clear();
						
				string StockQuantity = "False";
				string ItemName = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				if(reader.Read())
				{
					if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
					{
						StockQuantity = "True";
					}
				}
				reader.Close();

				if(StockQuantity == "True")
				{
					throw new Exception(ItemName + " �� ������� �����մϴ�.");
				}
			}
		}

		/// <summary>
		/// �ش� ǰ���� ������ ������������ �ľ�
		/// </summary>
		/// <returns></returns>
		private bool LastProcess(SqlConnection conn,SqlTransaction tr)
		{
			string str = "Select count(*) From PSI_MT Where RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = @Code and ProcessSequenceNum > @num";
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			comm.CommandText = str;
			comm.Parameters.Add("@ItemNum",vals[17].ToString());
			comm.Parameters.Add("@Code",vals[26].ToString());
			comm.Parameters.Add("@num",int.Parse(vals[23].ToString()));
			int count = int.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();

			if(count == 0)
				return true;
			else
				return false;
		}



		/// <summary>
		/// �����԰����� �ݾ� ����
		/// </summary>
		/// <param name="conn"></param>
		/// <param name="tr"></param>
		private void OutSideDeliveryUpdate(SqlConnection conn,SqlTransaction tr,string[] list)
		{
			string str = "Update OSD_HT Set ApplyUnitCost = @ApplyUnitCost, TotalCost = @TotalCost, [Year] = @year, [Month] = @month where OutSideDeliveryHistoryIndex = @index";
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			comm.CommandText = str;
			comm.Parameters.Add("@ApplyUnitCost",decimal.Parse(list[21]));
			comm.Parameters.Add("@TotalCost",decimal.Parse(list[21]) * decimal.Parse(DataGrid1.Rows[index].Cells.FromKey("���ռ���").Value.ToString()));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex1").Value.ToString()));
			comm.Parameters.Add("@year",list[30]);
			comm.Parameters.Add("@month",list[31]);
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();	
		}


		/// <summary>
		/// �����԰����� �ݾ� ����
		/// </summary>
		/// <param name="conn"></param>
		/// <param name="tr"></param>
		private void BuyingDeliveryUpdate(SqlConnection conn,SqlTransaction tr,string[] list)
		{
			string str = "Update BD_HT Set ApplyUnitCost = @ApplyUnitCost, TotalCost = @TotalCost, [Year] = @year, [Month] = @month where BuyingDeliveryHistoryIndex = @index";
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			comm.CommandText = str;
			comm.Parameters.Add("@ApplyUnitCost",decimal.Parse(list[21]));
			comm.Parameters.Add("@TotalCost",decimal.Parse(list[21]) * decimal.Parse(DataGrid1.Rows[index].Cells.FromKey("���ռ���").Value.ToString()));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex1").Value.ToString()));
			comm.Parameters.Add("@year",list[30].Trim());
			comm.Parameters.Add("@month",list[31].Trim());
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();	
		}

		/// <summary>
		/// ���Ű��� �����Լ�
		/// </summary>
		private void BuyingUpdate(SqlConnection conn,SqlTransaction tr)
		{
			//���Ź��ֿ����� �ܷ����������� �Ѵ�
			//�����ڻ�з��� ���� ����������,��ǰ�ΰ��� ���� �� â���� ������ �����Ѵ�.
			//			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			//			conn.Open();
			
			
			//���Ź��ֿ��� �����հݼ����� �ܷ����� ���ش�
			string str = "Update BO_HT Set RemainQuantity = RemainQuantity + @RemainQuantity where BuyingOrderHistoryIndex = @index";
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			comm.CommandText = str;
			comm.Parameters.Add("@RemainQuantity",decimal.Parse(arrlist[0].ToString()));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();			
			
			//���Ź��ֿ��� �ܷ��ʵ忡 �ѹ��ַ����� ���� �հݼ����� �������� ���Ѵ�
			str = "Update BO_HT Set RemainQuantity = RemainQuantity - @RemainQuantity where BuyingOrderHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@RemainQuantity",decimal.Parse(hdSucessQuantity.Value));
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
			


			//�ܷ��� ���ּ������� ������ ������¸� '����'���� �����Ų��.
			decimal Order = 0;
			decimal Remain = 0;

			str = "Select OrderQuantity,RemainQuantity From BO_HT Where BuyingOrderHistoryIndex = @index";
			comm.CommandText = str;
			comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("HistoryIndex2").Value.ToString()));
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				Order = decimal.Parse(dr["OrderQuantity"].ToString());
				Remain = decimal.Parse(dr["RemainQuantity"].ToString());
			}
			dr.Close();
						
			if(Remain > 0)
				str = "Update BO_HT Set ProgressCondition = '����' Where  BuyingOrderHistoryIndex = @index";
			else
				str = "Update BO_HT Set ProgressCondition = '�Ϸ�' Where  BuyingOrderHistoryIndex = @index";

			comm.CommandText = str;
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			int year = int.Parse(hdyear.Value);
			int mon = int.Parse(hdmon.Value);
				
			Table table = new Table(year,mon);


			//�������̺��� �ݾ��� ������Ų��(�����ݾ� ���̳ʽ��԰�,����ݾ� �÷��� �԰�)
			decimal BeforeCost = decimal.Parse(hdBeforeApplyUintCost.Value)*decimal.Parse(hdBeforeSucessQauntity.Value);
			comm.Parameters.Add("@comnum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
			comm.Parameters.Add("@year",year);
			comm.Parameters.Add("@cost", -BeforeCost);
			comm.CommandText = table.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//year = int.Parse(DataGrid1.Rows[index].Cells.FromKey("Year").Text);
			//mon = int.Parse(DataGrid1.Rows[index].Cells.FromKey("Month").Text);

			year = int.Parse(hdyear1.Value);
			mon = int.Parse(hdmon1.Value);

			Table table1 = new Table(year,mon);
			decimal NowCost = decimal.Parse(vals[1])*decimal.Parse(vals[21]);
			comm.Parameters.Add("@comnum",DataGrid1.Rows[index].Cells.FromKey("BusinessCompanyNum").Text);
			comm.Parameters.Add("@year",year);
			comm.Parameters.Add("@cost", NowCost);
			comm.CommandText = table1.PaymentIncreaseTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

	
			year = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Year;
			mon = DateTime.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionCompleteDate").Value.ToString()).Month;
				
			//�ش�ǰ���� �ڻ�з��� ���� ����â���� ������â���� ������ �����Ų��.
			if(Division(DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString()) == "������")
			{
				
				//������ â���� �԰������� ���̳ʽ� ������Ų��
				
				//������â�� ǰ���� â���ݾ�
				decimal Cost = 0;
				str = "Select StandardUnitCost From II_MT Where RecodingState = 1 and ItemNum = @itemnum";
				comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.CommandText = str;
				SqlDataReader dr3 = comm.ExecuteReader();
				while(dr3.Read())
				{
					Cost = decimal.Parse(dr3["StandardUnitCost"].ToString());
				}
				dr3.Close();
				comm.Parameters.Clear();

				// ������â�� �԰����� ���̳ʽ� ����
				str = table.InRowTable();
				comm.Parameters.Add("@quantity",SqlDbType.Decimal).Value = -decimal.Parse(arrlist[0].ToString());
				comm.Parameters.Add("@cost",SqlDbType.Decimal).Value = -(Cost*decimal.Parse(arrlist[0].ToString()));
				comm.Parameters.Add("@num",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@year",year);
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				// ������â�� �԰����� ����
				str = table.InRowTable();
				comm.Parameters.Add("@quantity",SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value);
				comm.Parameters.Add("@cost",SqlDbType.Decimal).Value = (Cost*decimal.Parse(hdSucessQuantity.Value));
				comm.Parameters.Add("@num",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@year",year);
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				//���̳ʽ� ������ ����
				if(MinusStore() == false)
				{
					string strSQL = "SELECT StockQuantity12 FROM RMS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = '14000000' and [Year] = @year";
					comm.Parameters.Add("@ItemNum", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
					comm.Parameters.Add("@year",year);
									
					comm.CommandText = strSQL;
					SqlDataReader reader = comm.ExecuteReader();
					comm.Parameters.Clear();	
					string StockQuantity = "False";
					string ItemName = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
					if(reader.Read())
					{
						if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
						{
							StockQuantity = "True";
						}
					}
					reader.Close();

					if(StockQuantity == "True")
					{
						throw new Exception(ItemName + " �� ������� �����մϴ�.");
					}
				}

				


				
				
			}
			else//��ǰ�ΰ�� �԰��Ƿڿ��忡�� �԰��Ƿڼ����� �����Ų��.
			{	
				
				//���� â���� �԰������� ���̳ʽ� ������Ų��
				
				//������â�� ǰ���� â���ݾ�
				decimal Cost = 0;
				str = "Select StandardUnitCost From II_MT Where RecodingState = 1 and ItemNum = @itemnum";
				comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.CommandText = str;
				SqlDataReader dr3 = comm.ExecuteReader();
				while(dr3.Read())
				{
					Cost = decimal.Parse(dr3["StandardUnitCost"].ToString());
				}
				dr3.Close();
				comm.Parameters.Clear();
				// ����â�� �԰����� ���̳ʽ� ����
				str = table.InProductionTable();
				comm.Parameters.Add("@quantity",SqlDbType.Decimal).Value = -decimal.Parse(arrlist[0].ToString());
				comm.Parameters.Add("@cost",SqlDbType.Decimal).Value = -(Cost*decimal.Parse(arrlist[0].ToString()));
				comm.Parameters.Add("@num",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@code",SqlDbType.VarChar).Value = "14009999";
				comm.Parameters.Add("@year",year);
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				// ����â�� �԰����� ����
				str = table.InProductionTable();
				comm.Parameters.Add("@quantity",SqlDbType.Decimal).Value = decimal.Parse(hdSucessQuantity.Value);
				comm.Parameters.Add("@cost",SqlDbType.Decimal).Value = (Cost*decimal.Parse(hdSucessQuantity.Value));
				comm.Parameters.Add("@num",SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
				comm.Parameters.Add("@code",SqlDbType.VarChar).Value = "14009999";
				comm.Parameters.Add("@year",year);
				comm.CommandText = str;
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();

				//���̳ʽ� ������ ����
				if(MinusStore() == false)
				{
					string strSQL = "SELECT StockQuantity12 FROM PS_MT WHERE RecodingState = 1 and ItemNum = @ItemNum and ProcessCode = '14009999' and [Year] = @year";
					comm.Parameters.Add("@ItemNum", SqlDbType.VarChar).Value = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
									
					comm.CommandText = strSQL;
					SqlDataReader reader = comm.ExecuteReader();
					comm.Parameters.Clear();
					string StockQuantity = "False";
					string ItemName = DataGrid1.Rows[index].Cells.FromKey("ItemNum").Value.ToString();
					if(reader.Read())
					{
						if(float.Parse(reader["StockQuantity12"].ToString()) < 0)
						{
							StockQuantity = "True";
						}
					}
					reader.Close();

					if(StockQuantity == "True")
					{
						throw new Exception(ItemName + " �� ������� �����մϴ�.");
					}
				}


				//�԰��Ƿڿ��� �԰��Ƿڼ��� ����
				str = "Update ISR_HT Set InstorehouseRequestQuantity = @InstorehouseRequestQuantity where HistoryIndex = @index and HistorySection = 'ǰ���˻�'";
				comm.CommandText = str;
				comm.Parameters.Add("@InstorehouseRequestQuantity",decimal.Parse(hdSucessQuantity.Value));
				comm.Parameters.Add("@index",int.Parse(DataGrid1.Rows[index].Cells.FromKey("QualityInspectionHistoryIndex").Value.ToString()));
				comm.ExecuteNonQuery();
				comm.Parameters.Clear();
				
			}

			


		}


		private string Division(string Item)
		{
			
			string aa="";
			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			con.Open();
			SqlCommand comm =  new SqlCommand(str,con);
				
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value = Item;
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			dr.Close();
			con.Close();
			
			return aa;
		}

		
		/// <summary>
		/// ���̳ʽ� ��� ��뿩��
		/// </summary>
		/// <returns></returns>
		private bool MinusStore()
		{
			bool aa = true;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Day"]);
			conn.Open();
			string str = "Select MinusRowMaterialPermissionUsed From SCS_T";
			SqlCommand comm =  new SqlCommand(str,conn);
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = bool.Parse(dr["MinusRowMaterialPermissionUsed"].ToString());
			}
			dr.Close();
			conn.Close();

			return aa;
		}

		private void btCancle_Click(object sender, System.EventArgs e)
		{
			
			Delete del = new Delete(DataGrid1,"QualityInspectionPC",Session["UserName"].ToString(), Session["ID"].ToString());
			del.MainRowDelete();


			
			
			SByte sbyteProcessDiv = Convert.ToSByte(ddlProcessDiv.SelectedItem.Value);
			
			// �˻� ��ü ����
			KIT_ERP.QualityInspection.QualityInspection_Search qis = new KIT_ERP.QualityInspection.QualityInspection_Search
				(
				PageNames.ǰ���˻���Ȳ
				, ItemSearchControl1.ItemNum
				, ItemSearchControl1.ItemDrawNum
				, ItemSearchControl1.ItemName
				, txtStartDate.Text
				, txtEndDate.Text
				, CSC1.Company
				, CSC1.BusinessRegistrationNum
				, sbyteProcessDiv
				, ddlDivision.SelectedItem.Value
				);

			DataTable dt_Source = qis.GetDataSet().Tables[0];
			
			// �׸��� �ϴ� ��� ��� �޼ҵ� ȣ��
			this.SUM_and_AVG_(dt_Source);
			
			DataGrid1.DataSource = dt_Source.DefaultView;
			DataGrid1.DataKeyField = "��ȣ";
			DataGrid1.DataBind();

			Session["DT1"] = dt_Source;
		}

		private void btExcel_Click(object sender, System.EventArgs e)
		{
			SByte sbyteProcessDiv = Convert.ToSByte(ddlProcessDiv.SelectedItem.Value);
			
			// �˻� ��ü ����
			KIT_ERP.QualityInspection.QualityInspection_Search qis = new KIT_ERP.QualityInspection.QualityInspection_Search
				(
				PageNames.ǰ���˻���Ȳ
				, ItemSearchControl1.ItemNum
				, ItemSearchControl1.ItemDrawNum
				, ItemSearchControl1.ItemName
				, txtStartDate.Text
				, txtEndDate.Text
				, CSC1.Company
				, CSC1.BusinessRegistrationNum
				, sbyteProcessDiv
				, ddlDivision.SelectedItem.Value
				);

			DataTable dt_Source = qis.GetDataSet().Tables[0];

			UltraWebGrid uwg_QI = new UltraWebGrid();
			uwg_QI = DataGrid1;
			uwg_QI.DisplayLayout.Pager.AllowPaging = false;
			uwg_QI.Columns.FromKey("chk").Hidden = true;
			uwg_QI.DataSource = dt_Source;
			uwg_QI.DataSource = dt_Source.DefaultView;
			uwg_QI.DataKeyField = "��ȣ";
			uwg_QI.DataBind();
			UltraWebGridExcelExporter1.Export(uwg_QI);
		
		}


		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			int count = int.Parse(hdIndex.Value);
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			int CloseYear = 0;
			int CloseMonth = 0;
			
			
			CloseYear = int.Parse(DataGrid1.Rows[count].Cells.FromKey("Year").Text);
			CloseMonth = int.Parse(DataGrid1.Rows[count].Cells.FromKey("Month").Text);
			
			if(year < CloseYear)
			{
				return true;
			}
			else if(year == CloseYear)
			{
				if(month < CloseMonth)
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		
		}
	}
}
