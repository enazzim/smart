using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Data.SqlClient;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// Claim�� ���� ��� �����Դϴ�.
	/// </summary>
	public class Claim : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox tbQuantity;
		protected System.Web.UI.WebControls.TextBox tb_Cost;
		protected System.Web.UI.WebControls.DropDownList ddlClaimStatus;
		protected System.Web.UI.WebControls.DropDownList ddlClaimCause;
		protected System.Web.UI.WebControls.Button bt_Delete;
		protected System.Web.UI.WebControls.Button bt_Update;
		protected System.Web.UI.WebControls.Button bt_Register;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lbItemNum;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lbItemDrawNum;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_OldCost;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcDate;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden lb_Index;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdDate;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			ItemSearchControl1.Commodity = true; //��ǰ ���ε�				
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			ItemSearchControl1.HalfFinishedProducts = true;//����ǰ ���ε�
			ItemSearchControl1.RawMaterials = true;//������ ���ε�
			CSC1.UnitCostDistinction = "���ſ���";


			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if(!Page.IsPostBack)
			{
				//Response.Write("<script language='javascript'>document.parentWindow.parent.ContentsTitle.location = '../ContentsTitle.aspx?title=�� �������� > Ŭ���� ���';</script>");
				
				//bt_Register.Attributes.Add("onClick", "return OK('�Է��� �׸��� ���');");
				//bt_Update.Attributes.Add("onClick", "return OK('������ �׸��� ����');");
				bt_Delete.Attributes.Add("onClick", "return OK('������ �׸��� ����');");
				//Button1.Attributes.Add("onClick", "ResetTextBox();;");


				tbQuantity.Attributes.Add("OnKeyDown", "OnKeyDown_Float(this);");
				tbQuantity.Attributes.Add("OnFocus", "OnFocus_Obj(this);");
				tbQuantity.Attributes.Add("OnBlur", "OnBlur_Cur(this);");
				tbQuantity.Attributes.Add("OnKeyUp", "OnKeyUp_Currency(this);");

				tb_Cost.Attributes.Add("OnKeyDown", "OnKeyDown_Float(this);");
				tb_Cost.Attributes.Add("OnKeyUp", "OnKeyUp_Currency(this);");
				tb_Cost.Attributes.Add("OnFocus", "OnFocus_Obj(this);");
				tb_Cost.Attributes.Add("OnBlur", "OnBlur_Cur(this);");
				

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
				conn.Open();


				// ǰ����ε�
			
				/////////////////////////////////////////
				/// Ŭ���� ���� �ڵ� ����
				/////////////////////////////////////////
				string str = "SELECT SmallClassificationCode, SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '1000' order by SmallClassificationName";
				SqlCommand comm =  new SqlCommand(str,conn);
				SqlDataAdapter da = new SqlDataAdapter(comm) ;
				DataSet ds = new DataSet() ;
				da.Fill(ds,"Code");

				ddlClaimStatus.DataSource = ds;
				ddlClaimStatus.DataMember = "Code";
				ddlClaimStatus.DataTextField = "SmallClassificationName";
				ddlClaimStatus.DataValueField = "SmallClassificationCode";
				ddlClaimStatus.DataBind();
				ddlClaimStatus.Items.Insert(0, "---����---");
				ddlClaimStatus.Items[0].Value = "";

				/////////////////////////////////////////
				/// Ŭ���� ���� �ڵ� ����
				/////////////////////////////////////////
				string str1 = "SELECT SmallClassificationCode, SmallClassificationName from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '1010' order by SmallClassificationName";
				SqlCommand comm1 =  new SqlCommand(str1,conn);
				SqlDataAdapter da1 = new SqlDataAdapter(comm1) ;
				DataSet ds1 = new DataSet() ;
				da1.Fill(ds1,"Code");

				ddlClaimCause.DataSource = ds1;
				ddlClaimCause.DataMember = "Code";
				ddlClaimCause.DataTextField = "SmallClassificationName";
				ddlClaimCause.DataValueField = "SmallClassificationCode";
				ddlClaimCause.DataBind();
				ddlClaimCause.Items.Insert(0, "---����---");
				ddlClaimCause.Items[0].Value = "";


				wdcDate.NullDateLabel = DateTime.Now.ToShortDateString();


				conn.Close();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
			this.bt_Update.Click += new System.EventHandler(this.bt_Update_Click);
			this.bt_Register.Click += new System.EventHandler(this.bt_Register_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void bt_Register_Click(object sender, System.EventArgs e)
		{
			if(Validity())
			{
				ArrayList arr = new ArrayList();
				arr.Add(ItemSearchControl1.ItemNum);						//ǰ���ȣ
				arr.Add(ItemSearchControl1.ItemDrawNum);					//�����ȣ			
				arr.Add(ItemSearchControl1.ItemName);			//ǰ���
				arr.Add(CSC1.Company);		//�ŷ�ó��
				arr.Add(CSC1.BusinessRegistrationNum);		//����ڵ�Ϲ�ȣ
				arr.Add(wdcDate.Text);							//��������
				arr.Add(decimal.Parse(tbQuantity.Text));						//����
				arr.Add(decimal.Parse(tb_Cost.Text));							//�ݾ�
				arr.Add(ddlClaimStatus.SelectedItem.Text);		//����
				arr.Add(ddlClaimStatus.SelectedItem.Value);		//�����ڵ�
				arr.Add(ddlClaimCause.SelectedItem.Text);		//����
				arr.Add(ddlClaimCause.SelectedItem.Value);		//�����ڵ�
			


				Registration reg = new Registration("Claim",Session["ID"].ToString(),"",arr);
				UltraWebGrid1.DataSource = reg.MainTableRegistration();
				UltraWebGrid1.DataBind();
			}
		}

		private bool Validity()
		{
			string str = "";
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			SqlCommand comm = new SqlCommand();
			comm.Connection = conn;
			comm.Transaction = tr;
			try
			{
				str = "Select count(*) From II_MT Where RecodingState = 1 and ItemNum = @num";
				comm.Parameters.Add("@num",ItemSearchControl1.ItemNum);
				comm.CommandText = str;
				int a = int.Parse(comm.ExecuteScalar().ToString());
				comm.Parameters.Clear();
				if(a == 0)
				{
					throw new Exception("ǰ���� ��Ȯ�� �Է����ּ���!");
				}
				str = "Select count(*) From CI_MT Where RecodingState = 1 and BusinessRegistrationNum = @num";
				comm.Parameters.Add("@num",CSC1.BusinessRegistrationNum);
				comm.CommandText = str;
				int b = int.Parse(comm.ExecuteScalar().ToString());
				comm.Parameters.Clear();
				if(b == 0)
				{
					throw new Exception("�ŷ�ó�� ��Ȯ�� �Է����ּ���!");
				}
				

				if(ddlClaimStatus.SelectedIndex == 0)
					throw new Exception("�ҷ������� �Է����ּ���!");
				if(ddlClaimCause.SelectedIndex == 0)
					throw new Exception("�ҷ������� �Է����ּ���!");
				else if(!Compare(CSC1.Company, CSC1.BusinessRegistrationNum))
					throw new Exception("����ڹ�ȣ�� �ŷ�ó���� �ٸ��ϴ�!");

				tr.Commit();
				conn.Close();
				return true;
				
			}
			catch(Exception ee)
			{
				tr.Rollback();
				RegisterStartupScript("","<script>alert('"+ee.Message+"');</script>");
				conn.Close();
				return false;
			}
		}

		private bool Compare(string Company, string BusinessRegistrationNum)
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			SqlCommand com = new SqlCommand();
			com.Connection = con;
			con.Open();
			string str = "Select Count(BusinessRegistrationNum) From CI_MT where RecodingState =1 and CompanyName = @Com and BusinessRegistrationNum = @Num";
			com.CommandText = str;
			com.Parameters.Add("@Com",Company);
			com.Parameters.Add("@Num",BusinessRegistrationNum);
			int a = int.Parse(com.ExecuteScalar().ToString());
			com.Parameters.Clear();
			con.Close();

			if(a == 0)
				return false;
			else
				return true;
		}

		private void bt_Update_Click(object sender, System.EventArgs e)
		{
			if(lb_Index.Value == "0")
			{
				RegisterStartupScript("","<script>alert('�׸��� ������ �����ϼ���!');</script>");
			}
			else
			{
				if(Validity())
				{
					ArrayList arr = new ArrayList();
					arr.Add(ItemSearchControl1.ItemNum);						//ǰ���ȣ
					arr.Add(ItemSearchControl1.ItemDrawNum);					//�����ȣ			
					arr.Add(ItemSearchControl1.ItemName);		//ǰ���
					arr.Add(CSC1.Company);		//�ŷ�ó��
					arr.Add(CSC1.BusinessRegistrationNum);		//����ڵ�Ϲ�ȣ
					arr.Add(wdcDate.Text);							//��������
					arr.Add(decimal.Parse(tbQuantity.Text));						//����
					arr.Add(decimal.Parse(tb_Cost.Text));							//�ݾ�
					arr.Add(ddlClaimStatus.SelectedItem.Text);		//����
					arr.Add(ddlClaimStatus.SelectedItem.Value);		//�����ڵ�
					arr.Add(ddlClaimCause.SelectedItem.Text);		//����
					arr.Add(ddlClaimCause.SelectedItem.Value);		//�����ڵ�
					arr.Add(lb_OldCost.Value);							//�����ݾ�
					arr.Add(hdDate.Value);

					Registration reg = new Registration("Claim",Session["ID"].ToString(),lb_Index.Value,arr);
					//Registration reg = new Registration("Claim","admin",lb_Index.Value,arr);
					UltraWebGrid1.DataSource = reg.MainTableUpdate();
					UltraWebGrid1.DataBind();
				}
			}
		}

		private void bt_Delete_Click(object sender, System.EventArgs e)
		{
			if(lb_Index.Value != "0")
			{
				ArrayList arr = new ArrayList();
				arr.Add(ItemSearchControl1.ItemNum);						//ǰ���ȣ
				arr.Add(ItemSearchControl1.ItemDrawNum);					//�����ȣ			
				arr.Add(ItemSearchControl1.ItemName);		//ǰ���
				arr.Add(CSC1.Company);		//�ŷ�ó��
				arr.Add(CSC1.BusinessRegistrationNum);		//����ڵ�Ϲ�ȣ
				arr.Add(wdcDate.Text);							//��������
				arr.Add(decimal.Parse(tbQuantity.Text));						//����
				arr.Add(decimal.Parse(tb_Cost.Text));							//�ݾ�
				arr.Add(ddlClaimStatus.SelectedItem.Text);		//����
				arr.Add(ddlClaimStatus.SelectedItem.Value);		//�����ڵ�
				arr.Add(ddlClaimCause.SelectedItem.Text);		//����
				arr.Add(ddlClaimCause.SelectedItem.Value);		//�����ڵ�
				arr.Add(lb_OldCost.Value);							//�����ݾ�
				arr.Add(hdDate.Value);
				

				Registration reg = new Registration("Claim",lb_Index.Value,arr);
				UltraWebGrid1.DataSource = reg.MainTableDelete();
				UltraWebGrid1.DataBind();
				
				
				CSC1.Company="";
				CSC1.BusinessRegistrationNum = "";
				ItemSearchControl1.ItemDrawNum = "";
				ItemSearchControl1.ItemName = "";
				ItemSearchControl1.ItemNum = "";
				tb_Cost.Text = "0";
				tbQuantity.Text = "0";
				ddlClaimCause.SelectedIndex = 0;
				ddlClaimStatus.SelectedIndex = 0;
				lb_Index.Value = "0";
				lb_OldCost.Value = "0";
				lbItemDrawNum.Value  ="";
				lbItemNum.Value = "";
			}
			else
			{
				RegisterStartupScript("","<script>alert('�׸��� ������ �����ϼ���!');</script>");
			}
		}

		
	}
}
