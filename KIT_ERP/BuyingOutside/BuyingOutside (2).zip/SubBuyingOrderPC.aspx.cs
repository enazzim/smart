using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// SubBuyingOrderPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SubBuyingOrderPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcDeliveryDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcDeliveryDate1;
		protected System.Web.UI.WebControls.DropDownList ddlState;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected System.Web.UI.WebControls.Button Button1;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter UltraWebGridExcelExporter1;
		protected System.Web.UI.WebControls.LinkButton lkbtnUpdate;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdIndex;

		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		protected System.Web.UI.WebControls.DropDownList ddlProperty;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			ItemSearchControl1.SubMaterials = true; //������ ���ε�	
			ItemSearchControl1.Expendable = true;// �Ҹ�ǰ
			CSC1.UnitCostDistinction = "���Űŷ�ó";

			if(!Page.IsPostBack)
			{
				btnDelete.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ������ �Ͻðڽ��ϱ�?');");
							
			}	
		
			// �������� üũ�Ͽ� ���, ����, ���� ���θ� Ŭ���̾�Ʈ �ܿ��� üũ�ϱ� ���� JavaScript ������������ ��� 
			// true �� ��ȯ�Ǹ� ��ϰ���
			if ( MonthClosing() )
			{
				Response.Write("<script>var MonthCloseing = \"0\"; </script>");	// ���������� "0" �� �Ҵ�
			}
			else
			{
				// ������ �Ǿ���. - ��� �Ұ�
				Response.Write("<script>var MonthCloseing = \"1\"; </script>");	// ���������� "1" �� �Ҵ�
			}
			
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.UltraWebGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.UltraWebGrid1_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.lkbtnUpdate.Click += new System.EventHandler(this.lkbtnUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



		#region ������ ���θ� Ȯ���ϴ� �޼ҵ�
		/// <summary>
		/// ������ ���θ� Ȯ���ϴ� �޼ҵ�
		/// </summary>
		/// <returns></returns>
		public bool MonthClosing()
		{
			int intYear = 0;
			int intMonth = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string str = "Select [ClosingYear], [ClosingMonth] From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";

			try
			{
				conn.Open();
				SqlDataReader dr = comm.ExecuteReader();
				while(dr.Read())
				{
					intYear = int.Parse(dr[0].ToString());
					intMonth = int.Parse(dr[1].ToString());
				}
			} 
			catch ( Exception e)
			{
				Response.Write("<script>alert(\"" + e.Message + "\")</script>"); 
			} 
			finally
			{
				conn.Close();
			}

			if(intYear < int.Parse(DateTime.Now.ToShortDateString().Substring(0,4).Trim()))
			{
				return true;
			}
			else if(intYear == int.Parse(DateTime.Now.ToShortDateString().Substring(0,4).Trim())) 
			{
				if(intMonth < int.Parse(DateTime.Now.ToShortDateString().Substring(5,2).Trim()))
					return true;
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
			
		}
		#endregion

		//�˻��Լ�
		private DataSet Search()
		{
			SqlDataAdapter adap = new SqlDataAdapter("SubBuyingOrderPC_Search", ConfigurationSettings.AppSettings["DSN"]);
			adap.SelectCommand.Parameters.Add("@ItemNum", SqlDbType.VarChar).Value = ItemSearchControl1.ItemNum;
			adap.SelectCommand.Parameters.Add("@ItemDrawNum", SqlDbType.VarChar).Value = ItemSearchControl1.ItemDrawNum;
			adap.SelectCommand.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = ItemSearchControl1.ItemName;
			adap.SelectCommand.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = CSC1.Company;
			adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar).Value = CSC1.BusinessRegistrationNum;
			adap.SelectCommand.Parameters.Add("@DeliveryDate", SqlDbType.VarChar).Value = wcDeliveryDate.Text;
			adap.SelectCommand.Parameters.Add("@DeliveryDate1", SqlDbType.VarChar).Value = wcDeliveryDate1.Text;
			adap.SelectCommand.Parameters.Add("@ProgressCondition", SqlDbType.VarChar).Value =ddlState.SelectedItem.Value;
			adap.SelectCommand.Parameters.Add("@Property", SqlDbType.VarChar).Value =ddlProperty.SelectedItem.Value;

			adap.SelectCommand.CommandType = CommandType.StoredProcedure;
			DataSet ds = new DataSet();
			adap.Fill(ds);

			return ds;
		}

		//�˻���ư
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			UltraWebGrid1.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = 1;

			

			this.UltraWebGrid1.DataSource = Search();
			this.UltraWebGrid1.DataBind();			
		}

		// Excel��ư
		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = UltraWebGrid1;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;

			UltraWebGrid1.DataSource = Search();
			uwgExcelImport.DataBind();
			UltraWebGridExcelExporter1.Export(uwgExcelImport);
		}

		//������ư
		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			if(this.UltraWebGrid1.Rows.Count ==0)
			{				
				Response.Write("<script language=javascript>");
				Response.Write("alert('������ ǰ���� �����ϴ�.')");
				Response.Write("</script>");
			}
			else
			{
				KIT_ERP.Delete delete = new KIT_ERP.Delete(UltraWebGrid1,"SubBuyingOrderPC");
				delete.MainRowDelete();

				UltraWebGrid1.DataSource = Search();
				UltraWebGrid1.DataBind();						
			}			
		}

		//�������̵�
		private void UltraWebGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			UltraWebGrid1.DataSource =  Search();
			UltraWebGrid1.DataBind();
		}
		
        //������ư Ŭ��
		private void lkbtnUpdate_Click(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlTransaction tr = conn.BeginTransaction();
			
			try
			{			
				SBO_HT_Update(conn,tr); //���ֿ��� �����ϴ� �Լ�
				
				tr.Commit();
				Response.Write("<script language=javascript>");
				Response.Write("alert('�����Ǿ����ϴ�!');");
				Response.Write("</script>");
			}
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();
				UltraWebGrid1.DataSource = Search();
				UltraWebGrid1.DataBind();		
			}
		}

		//���Ź��ֿ��� �����ϴ� �Լ�
		private void SBO_HT_Update(SqlConnection con, SqlTransaction trans)
		{
			//���� ���Ź��ֿ��忡�� ���Լ���,�ܷ�,������¸� Update			
			int rowcount = int.Parse(hdIndex.Value);

			string str =" UPDATE SBO_HT SET " +
				" DeliveryQuantity = @DeliveryQuantity,DeliveryDate=@DeliveryDate,"+
				" ApplyUnitCost = @ApplyUnitCost,TotalCost = @TotalCost, " +
				" DeliveryRemainQuantity = @DeliveryRemainQuantity, "+
				" UpdatingPerson = @person,"+
				" UpdatingPersonID = @personid, "+
				" UpdatingDate = @date "+
				"WHERE SubBuyingOrderHistoryIndex= @INDEX ";
		
			SqlCommand comm = new SqlCommand(str,con);
			comm.Transaction = trans;
			//���ֿ����� �ܷ��� �����ܷ��� + ������ǰ�� - �����ĳ�ǰ�� �� �ִ´�.
			comm.Parameters.Add("@DeliveryQuantity", SqlDbType.Decimal).Value = decimal.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
			comm.Parameters.Add("@DeliveryDate", SqlDbType.DateTime).Value = DateTime.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("DeliveryDate").Value.ToString());
			comm.Parameters.Add("@ApplyUnitCost", SqlDbType.Decimal).Value = decimal.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("ApplyUnitCost").Value.ToString());
			comm.Parameters.Add("@TotalCost", SqlDbType.Decimal).Value = decimal.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("TotalCost").Value.ToString());
			comm.Parameters.Add("@DeliveryRemainQuantity", SqlDbType.Decimal).Value = decimal.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("DeliveryQuantity").Value.ToString());
		
			comm.Parameters.Add("@person", SqlDbType.VarChar).Value = Session["UserName"].ToString();
			comm.Parameters.Add("@personid", SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm.Parameters.Add("@date", SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();

			comm.Parameters.Add("@INDEX",SqlDbType.Int).Value = int.Parse(UltraWebGrid1.Rows[rowcount].Cells.FromKey("SubBuyingOrderHistoryIndex").Value.ToString());
						
			comm.ExecuteNonQuery();	
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = UltraWebGrid1;
			bool check = true;
			for(int count = UltraWebGrid1.Rows.Count-1 ; count >=0 ; count--)
			{
				if(UWG.Rows[count].Cells.FromKey("chk").Value == null || UWG.Rows[count].Cells.FromKey("chk").Value.ToString() == "false")
					UWG.Rows[count].Delete();
			}

			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count > 12)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
					
				Session["Grid"] = UWG;
				RegisterStartupScript("","<script>window.open('./Popup/SubPurchase.aspx','','width=1000, heigth=800,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
							
			}
			else
			{
				UltraWebGrid1.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
				UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = 1;

				UltraWebGrid1.DataSource = Search();
				UltraWebGrid1.DataBind();
			}
		}
	}
}
