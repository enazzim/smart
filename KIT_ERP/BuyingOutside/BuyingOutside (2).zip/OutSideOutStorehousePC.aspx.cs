using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// OutSideOutStorehousePC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class OutSideOutStorehousePC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcStartDate;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wdcEndDate;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.Button btnStop;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid uwgOOS_HT;
		protected System.Web.UI.WebControls.LinkButton linkUpdate;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter uwgExcel;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdRowIndex;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdquantity;
		
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdYear;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdMonth;
		protected System.Web.UI.WebControls.DropDownList ddlItemClassification1;
		protected KIT_ERP.Common.ItemSearchControl.ItemSearchControl ItemSearchControl1;
		protected System.Web.UI.WebControls.Button Button1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}


			ItemSearchControl1.RawMaterials = true; //������ ���ε�
			ItemSearchControl1.HalfFinishedProducts = true; //����ǰ ���ε�
			ItemSearchControl1.Products = true; //��ǰ ���ε�
			CSC1.UnitCostDistinction = "���ְŷ�ó";
				

			if(!Page.IsPostBack)
			{

				// �ߴܹ�ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnStop.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ����� �ߴ� �Ͻðڽ��ϱ�?');");
				// ������ư�� ���Ͽ� onclick�Ӽ��� �߰� ��Ŵ
				btnDelete.Attributes.Add("onClick","return Confirm('������ ǰ����� ���Ͽ� ����� ���� �Ͻðڽ��ϱ�?');");

				SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			
				//	*************************************************
				//	**  ǰ��з�1 ��Ӵٿ��Ʈ... ����Ÿ���ε�... **		
				//	*************************************************
				//�ڵ�з�ǥ���� ��з����� ǰ��з�1�� �Һз����� ������ ��.
				string str_ItemClassification1 = "Select SmallClassificationName, SmallClassificationCode from PUC_MT where SmallClassificationName != '' and RecodingState = 1 and LargeClassificationCode = '0210'" ;
				SqlCommand comm_ItemClassification1 = new SqlCommand(str_ItemClassification1,conn);
				SqlDataAdapter da_ItemClassification1 = new SqlDataAdapter(comm_ItemClassification1) ;
				DataSet ds_ItemClassification1 = new DataSet() ;
				da_ItemClassification1.Fill(ds_ItemClassification1);
				
				ddlItemClassification1.DataSource = ds_ItemClassification1;
				ddlItemClassification1.DataTextField = ds_ItemClassification1.Tables[0].Columns[0].ToString();
				ddlItemClassification1.DataValueField = ds_ItemClassification1.Tables[0].Columns[1].ToString();
				ddlItemClassification1.DataBind();
				ddlItemClassification1.Items.Insert(0, "-�����ϼ���-") ;
				ddlItemClassification1.Items[0].Value = "";
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.uwgOOS_HT.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.uwgOOS_HT_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.linkUpdate.Click += new System.EventHandler(this.linkUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private DataSet Search()
		{
			KIT_ERP.Search search;
			if(ItemSearchControl1.hdItem.Trim() == "")
				search = new KIT_ERP.Search("OutSideOutStorehousePC",ItemSearchControl1.ItemNum,ItemSearchControl1.ItemDrawNum,ItemSearchControl1.ItemName,wdcStartDate,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum,"���",ddlItemClassification1.SelectedItem.Value);
			else
				search = new KIT_ERP.Search("OutSideOutStorehousePC",ItemSearchControl1.ItemNum, "", "",wdcStartDate,wdcEndDate,CSC1.Company,CSC1.BusinessRegistrationNum,"���",ddlItemClassification1.SelectedItem.Value);
			return search.DataSet_search();
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			uwgOOS_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
			this.uwgOOS_HT.DataSource = Search();
			this.uwgOOS_HT.DataBind();			
		}

		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			KIT_ERP.Delete delete = new Delete(uwgOOS_HT,"OutSideOutStorehousePC");
			delete.MainRowDelete();
			
			//������ư�� ���� �����͸� ������ �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgOOS_HT.DataSource = Search();
			this.uwgOOS_HT.DataBind();	
		}

		private void btnStop_Click(object sender, System.EventArgs e)
		{
			KIT_ERP.Stop stop = new Stop(uwgOOS_HT,"OutSideOutStorehousePC","����");
			stop.MainTableStop();

			//�ߴܹ�ư�� ���� �����͸� �ߴ��� �Ŀ� �ٽ� �˻� ��ü�� ȣ���ؼ� �׸��忡 ���ε��� �ٽ� ��Ŵ.
			this.uwgOOS_HT.DataSource = Search();
			this.uwgOOS_HT.DataBind();	
		}

		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			// ���� Grid�� ������ Excel�� Export
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid  uwgExcelImport = new Infragistics.WebUI.UltraWebGrid.UltraWebGrid();
			uwgExcelImport = uwgOOS_HT;
			uwgExcelImport.DisplayLayout.Pager.AllowPaging = false;
			uwgExcelImport.Columns.FromKey("chk").Hidden = true;

			this.uwgOOS_HT.DataSource = Search();
			uwgExcelImport.DataBind();			

			uwgExcel.Export(uwgOOS_HT);	
		}

		private void linkUpdate_Click(object sender, System.EventArgs e)
		{
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			SqlCommand comm = new SqlCommand();
			SqlTransaction tr = conn.BeginTransaction();
			comm.Connection = conn;
			comm.Transaction = tr;

			try
			{			

				OOS_HT_Update(); //����������� ���� ����
				OS_MT_Update(); //����â�� ���� ����

				//�����ϰ��� �ϴ� ǰ���� ����ǰ �Ǵ� ��ǰ�ΰ�� ����â�� ���� ����
				if(Division() == 2 || Division() == 3)
				{	
					if(!WorkPlan3() || (StoreManage(conn,tr) =="��"))
					{
						PS_MT_Update();
						PS_MTHistory();
					}
					
				}
					//�����ϰ��� �ϴ� ǰ���� �������� ��� ������â�� ���� ����
				else if(Division() ==1)
				{
					if(!WorkPlan3() || (StoreManage(conn,tr) =="��"))
						RMS_MT_Update();
					RMS_MTHistory();
				}
				
				tr.Commit();
				Response.Write("<script language=javascript>");
				Response.Write("alert('�����Ǿ����ϴ�!');");
				Response.Write("</script>");

				this.uwgOOS_HT.DataSource = Search();
				this.uwgOOS_HT.DataBind();			

			}
			catch(Exception ee)
			{
				
				Response.Write("<script language=javascript>");
				Response.Write("alert('"+ee.Message+"');");
				Response.Write("</script>");

				tr.Rollback();
			}
			finally
			{
				conn.Close();
			}
		}



		/// <summary>
		/// �����������
		/// </summary>
		/// <returns></returns>
		private string StoreManage(SqlConnection con, SqlTransaction trans)
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string store = "�ƴϿ�";
			string str = "Select Unit4 From II_MT Where ItemNum = @ItemNum and RecodingState = 1";
			SqlCommand comm = new SqlCommand();
			comm.Connection = con;
			comm.Transaction = trans;
			comm.CommandText = str;
			comm.CommandType = CommandType.Text;

			comm.Parameters.Add("@ItemNum",uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString());
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				store = dr["Unit4"].ToString();				
			}
			dr.Close();
			return store;
		}

		/// <summary>
		/// �۾���ȹ����3���� �Ǵ��Լ�
		/// </summary>
		/// <returns></returns>
		private bool WorkPlan3()
		{
			bool Work = false;
			// ���� �����Ǿ��ִ� ���� ������ ������
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Day"]);
			conn.Open();

			string strSQL = @"SELECT WorkPlan3 FROM SCS_T";
			SqlCommand comm = new SqlCommand(strSQL, conn);

			SqlDataReader reader = comm.ExecuteReader();
			if(reader.Read())
			{
				Work = bool.Parse(reader["WorkPlan3"].ToString());
			}
			conn.Close();

			return Work;

		}
		


		//�����ϰ��� �ϴ� ǰ���� ��ǰ���� ���������� �Ǵ��ϴ� �Լ�
		private int Division()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			string aa="";

			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select PropertyClassification From II_MT Where RecodingState = 1 and ItemNum = @num";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@num",SqlDbType.VarChar).Value =uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			SqlDataReader dr = comm.ExecuteReader();
			if(dr.Read())
			{
				aa = dr["PropertyClassification"].ToString();
			}
			conn.Close();

			if(aa.ToString() == "������")
				return 1;
			else if(aa.ToString() =="����ǰ")
				return 2;
			else if(aa.ToString() =="��ǰ")
				return 3;
			else if(aa.ToString() =="��ǰ")
				return 4;
			else 
				return 5;
		}

		//������������� ������ �����ϴ� �Լ�
		private void OOS_HT_Update()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
		
			string itemnum= uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			conn.Open();	
			
			string str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);			
			comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = itemnum;			
			
		
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = Decimal.Parse(comm.ExecuteScalar().ToString());
						
			
			string str1 = "Update OOS_HT set ThistimeOutStorehouseQuantity = @quantity,OutStorehouseDate = @outdate , UpdatingPerson=@Person,UpdatingPersonID=@PersonID,UpdatingDate=@Date Where OutSideOutStorehouseHistoryIndex = @Index";
			SqlCommand comm1 = new SqlCommand(str1,conn);

			//���κ���Ǵ� ������ ������ ����
			comm1.Connection = conn;
			comm1.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm1.Parameters.Add("@outdate", SqlDbType.SmallDateTime).Value = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Value.ToString());
			comm1.Parameters.Add("@Person", SqlDbType.VarChar).Value = Session["UserName"].ToString();
			comm1.Parameters.Add("@PersonID", SqlDbType.VarChar).Value = Session["ID"].ToString();
			comm1.Parameters.Add("@Date", SqlDbType.SmallDateTime).Value = DateTime.Now.ToShortDateString();
			comm1.Parameters.Add("@Index", SqlDbType.Int).Value = int.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutSideOutStorehouseHistoryIndex").Value.ToString());
			comm1.ExecuteNonQuery();

			conn.Close();	
			
		}

		
		
		//����â���� ������ �����ϴ� �Լ�
		private void PS_MT_Update()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			Decimal m_progressrate = 100;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string itemnum= uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			conn.Open();	
			
			// ǰ���� ��ô��
			string str_rate = "Select ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessCode = @code";
			SqlCommand comm_rate = new SqlCommand(str_rate,conn);
			comm_rate.Parameters.Add("@num",SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm_rate.Parameters.Add("@code",SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			SqlDataReader dr_rate = comm_rate.ExecuteReader();

			if(dr_rate.Read())
			{
				if(dr_rate["ProgressRate"].ToString() == null || dr_rate["ProgressRate"].ToString().Trim() =="")
					m_progressrate = 0;
				else
					m_progressrate = Decimal.Parse(dr_rate["ProgressRate"].ToString());
			}		
			dr_rate.Close();
		

			string str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);			
			comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = itemnum;			
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = Decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();


		
			//�������̺����� ���������� ���̳ʽ� ����
			int year = int.Parse(hdYear.Value);
			int mon = int.Parse(hdMonth.Value);
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = (-(decimal.Parse(hdquantity.Value.ToString()))*(decimal.Parse(unitcost.ToString()))* (decimal.Parse(m_progressrate.ToString())/100));
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Year ;
			mon = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Month ;
			comm.Parameters.Add("@cost", SqlDbType.VarChar).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString())*decimal.Parse(unitcost.ToString())*(decimal.Parse(m_progressrate.ToString())/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@year",year);
			Table table1 = new Table(year,mon);

			comm.CommandText = table1.OutProductionTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			conn.Close();
		}

		//����â���� ������ �����ϴ� �Լ�
		private void OS_MT_Update()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			Decimal m_progressrate = 100;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string itemnum= uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			conn.Open();	

			// ǰ���� ��ô��
			string str_rate = "Select ProgressRate From PSI_MT Where RecodingState = 1 and ItemNum = @num and ProcessCode = @code";
			SqlCommand comm_rate = new SqlCommand(str_rate,conn);
			comm_rate.Parameters.Add("@num",SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm_rate.Parameters.Add("@code",SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			SqlDataReader dr_rate = comm_rate.ExecuteReader();

			if(dr_rate.Read())
			{
				if(dr_rate["ProgressRate"].ToString() == null || dr_rate["ProgressRate"].ToString().Trim() =="")
					m_progressrate = 0;
				else
					m_progressrate = Decimal.Parse(dr_rate["ProgressRate"].ToString());
			}		
			dr_rate.Close();
			

			string str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);
			
			comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = itemnum;
			
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = Decimal.Parse(comm.ExecuteScalar().ToString());
			
			comm.Parameters.Clear();
		
			//�������̺����� ���������� ���̳ʽ� ����
			int year = int.Parse(hdYear.Value);
			int mon = int.Parse(hdMonth.Value);
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = (-(decimal.Parse(hdquantity.Value.ToString()))*(decimal.Parse(unitcost.ToString()))* (decimal.Parse(m_progressrate.ToString())/100));
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@year",year);
			
			Table table = new Table(year,mon);
			comm.CommandText = table.InTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Year ;
			mon = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Month ;
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString())*decimal.Parse(unitcost.ToString())*(decimal.Parse(m_progressrate.ToString())/100);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@code", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ProcessCode").Value.ToString();
			comm.Parameters.Add("@comnum", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("BusinessRegistrationNum").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table1 = new Table(year,mon);
			comm.CommandText = table1.InTable();
			comm.ExecuteNonQuery();

			conn.Close();
		}


		/// <summary>
		/// ����ǰ ����� ������ �����Ǵ� �̷¿���
		/// </summary>
		private void PS_MTHistory()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string str=" UPDATE SH_HT SET Quantity = @Quantity WHERE HistoryDivision= '�������' and HistoryIndex = @index and ItemNum = @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);	
			comm.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm.Parameters.Add("@index",SqlDbType.Int).Value = int.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutSideOutStorehouseHistoryIndex").Value.ToString());
			comm.Parameters.Add("@itemnum",uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString());
			conn.Open();	
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
			conn.Close();
		}



		/// <summary>
		/// ������ ����� ������ �����Ǵ� �̷¿���
		/// </summary>
		private void RMS_MTHistory()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string str=" UPDATE SH_HT SET Quantity = @Quantity WHERE HistoryDivision= '�������' and HistoryIndex = @index and ItemNum = @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);	
			comm.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm.Parameters.Add("@index",SqlDbType.Int).Value = int.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutSideOutStorehouseHistoryIndex").Value.ToString());
			comm.Parameters.Add("@itemnum",uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString());
			conn.Open();	
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();
			conn.Close();
		}

		//������â�� ���� �����ϴ� �Լ�
		private void RMS_MT_Update()
		{
			int rowcount = int.Parse(hdRowIndex.Value);
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			string itemnum= uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			conn.Open();	
			
			string str = "select StandardUnitCost from II_MT where RecodingState = 1 and ItemNum= @itemnum";
			SqlCommand comm = new SqlCommand(str,conn);

			
			comm.Parameters.Add("@itemnum",SqlDbType.VarChar).Value = itemnum;
			
			//ǰ���������̺����� ���� �����ϰ����ϴ� ǰ���� �ܰ��� �������ִ� ����
			decimal unitcost = decimal.Parse(comm.ExecuteScalar().ToString());
			comm.Parameters.Clear();
		
			//�������̺����� ���������� ���̳ʽ� ����
			int year = int.Parse(hdYear.Value);
			int mon = int.Parse(hdMonth.Value);			
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString())*unitcost);
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = -(decimal.Parse(hdquantity.Value.ToString()));
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table = new Table(year,mon);
			comm.CommandText = table.OutRowTable();
			comm.ExecuteNonQuery();
			comm.Parameters.Clear();

			//���κ���Ǵ� ������ ������ ����
			year = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Year ;
			mon = DateTime.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("OutStorehouseDate").Text).Month ;
			comm.Parameters.Add("@cost", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString())*unitcost;
			comm.Parameters.Add("@quantity", SqlDbType.Decimal).Value = decimal.Parse(uwgOOS_HT.Rows[rowcount].Cells.FromKey("ThistimeOutStorehouseQuantity").Value.ToString());
			comm.Parameters.Add("@num", SqlDbType.VarChar).Value = uwgOOS_HT.Rows[rowcount].Cells.FromKey("ItemNum").Value.ToString();
			comm.Parameters.Add("@year",year);

			Table table1 = new Table(year,mon);
			comm.CommandText = table1.OutRowTable();
			comm.ExecuteNonQuery();

			conn.Close();
		}

		private void uwgOOS_HT_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			uwgOOS_HT.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			this.uwgOOS_HT.DataSource = Search();
			this.uwgOOS_HT.DataBind();	
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = uwgOOS_HT;
			bool check = true;
			for(int count = uwgOOS_HT.Rows.Count-1 ; count >=0 ; count--)
			{
				if(UWG.Rows[count].Cells.FromKey("chk").Value == null || UWG.Rows[count].Cells.FromKey("chk").Value.ToString() == "false")
					UWG.Rows[count].Delete();
			}

			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count >= 15)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
					
				Session["Grid"] = UWG;
				RegisterStartupScript("","<script>window.open('./Popup/OutSideStorehousePurchase.aspx','','width=800,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
				//RegisterStartupScript("","<script>window.open('./Popup/OutSideOutStorehousePurchase.aspx','','width=1100,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");

				
			}
			else
			{
				uwgOOS_HT.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
				uwgOOS_HT.DisplayLayout.Pager.CurrentPageIndex = 1;
				
				this.uwgOOS_HT.DataSource = Search();
				this.uwgOOS_HT.DataBind();
			}
		}

	}
}
