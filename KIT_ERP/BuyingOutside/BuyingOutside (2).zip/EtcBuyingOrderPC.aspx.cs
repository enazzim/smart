using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI;
using System.Text;


namespace KIT_ERP.BuyingOutside
{
	/// <summary>
	/// EtcBuyingOrderPC�� ���� ��� �����Դϴ�.
	/// </summary>
	public class EtcBuyingOrderPC : System.Web.UI.Page
	{
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcDeliveryDate;
		protected System.Web.UI.WebControls.TextBox txtItemName;
		protected System.Web.UI.WebControls.DropDownList ddlState;
		protected Infragistics.WebUI.UltraWebGrid.ExcelExport.UltraWebGridExcelExporter UltraWebGridExcelExporter1;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdIndex;
		protected System.Web.UI.WebControls.Button btnExcel;
		protected System.Web.UI.WebControls.LinkButton lkbtnUpdate;
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
		protected Infragistics.WebUI.WebSchedule.WebDateChooser wcDeliveryDate1;
		protected System.Web.UI.WebControls.Button btnSearch;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.Button Button1;
		protected KIT_ERP.Common.CompanySearchControl.CompanySearchControl CSC1;
		


		

		/// <summary>
		/// ������忡�� ��Ÿ���Ż��� ���ε���Ű�� �����ͼ��� ����
		/// </summary>
		/// <returns></returns>
		protected DataSet EtcStore
		{
			get
			{
				KIT_ERP.Update Etc = new KIT_ERP.Update(Session["ID"].ToString());
				DataSet ds_Reson = Etc.EtcBuy();
				
				return ds_Reson;
			}
		}


		private void Page_Load(object sender, System.EventArgs e)
		{
			CSC1.UnitCostDistinction = "���Űŷ�ó";
			if(Session["ID"] == null)
			{	
				Session.Abandon();
				Page.RegisterClientScriptBlock("SEND", "<script>parent.location.href = '../Login.aspx';</script>");
			}

			if ( !IsPostBack )
			{
				PageLoad_Bind();
				Response.Write("<script>var MonthCloseing = \"0\"; </script>");	// ���������� "0" �� �Ҵ�
			}

			// �������� üũ�Ͽ� ���, ����, ���� ���θ� Ŭ���̾�Ʈ �ܿ��� üũ�ϱ� ���� JavaScript ������������ ��� 
			// true �� ��ȯ�Ǹ� ��ϰ���
//			if ( MonthClosing() )
//			{
//				Response.Write("<script>var MonthCloseing = \"0\"; </script>");	// ���������� "0" �� �Ҵ�
//			}
//			else
//			{
//				// ������ �Ǿ���. - ��� �Ұ�
//				Response.Write("<script>var MonthCloseing = \"1\"; </script>");	// ���������� "1" �� �Ҵ�
//			}
		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.UltraWebGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.UltraWebGrid1_PageIndexChanged);
			this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.lkbtnUpdate.Click += new System.EventHandler(this.lkbtnUpdate_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void PageLoad_Bind()
		{
			btnDelete.Attributes.Add("onclick", " return DeleteCheck(); ");
		}



		#region �˻���ư Ŭ���� �̺�Ʈ �ڵ鷯�� ���� �޼���
		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex =1;
			string[] strArrValue = new string[6];
			strArrValue[0] = txtItemName.Text;
			strArrValue[1] = CSC1.Company;
			strArrValue[2] = CSC1.BusinessRegistrationNum;
			strArrValue[3] = wcDeliveryDate.Text;
			strArrValue[4] = wcDeliveryDate1.Text;
			strArrValue[5] = ddlState.SelectedItem.Value;

			this.DataBind(strArrValue);
		}
		private void DataBind(string[] strArrValue)
		{
			SqlDataAdapter adap = new SqlDataAdapter("EtcBuyingOrderPC_Search", ConfigurationSettings.AppSettings["DSN"]);
			adap.SelectCommand.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = strArrValue[0];
			adap.SelectCommand.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = strArrValue[1];
			adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar).Value = strArrValue[2];
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate", SqlDbType.VarChar).Value = strArrValue[3] ;
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate1", SqlDbType.VarChar).Value = strArrValue[4] ;
			adap.SelectCommand.Parameters.Add("@RecodingState", SqlDbType.VarChar).Value = strArrValue[5];

			adap.SelectCommand.CommandType = CommandType.StoredProcedure;
			DataSet ds = new DataSet();
			adap.Fill(ds);

			UltraWebGrid1.DataSource = ds.Tables[0].DefaultView;
			UltraWebGrid1.DataBind();
		}
		#endregion



		// ������ư
		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			if (UltraWebGrid1.Rows.Count == 0)
			{
				Response.Write("<script>alert('������ ǰ���� �����ϴ�.');</script>");
			}
			else
			{
				// ���� ũ�� 6 �� StringBuilder ��ü ����.
				StringBuilder sb = new StringBuilder(6);
				bool test = false;

				for( int i = 0 ; i < UltraWebGrid1.Rows.Count ; i ++)
				{
					if(MonthClosing1(i))
					{
						if (Convert.ToBoolean( UltraWebGrid1.Rows[i].Cells.FromKey("chk").Value ))
						{
							sb.Append (UltraWebGrid1.Rows[i].Cells.FromKey("EtcBuyingOrderHistoryIndex").Text );
							sb.Append(",");
						}
					}
					else
					{
						test = true;
						RegisterStartupScript("","<script>alert('�������� �Ǿ� ������ �Ұ��� �մϴ�!');</script>");
						break;
					}

				}
				
				if(!test)
				{
					if ( sb.Length > 0 )
					{
						// SQL �������� in ���� ����ϱ� ���� ������ �޸� ����
						string strDeleteIndex = sb.ToString().Substring(0, sb.ToString().Length - 1);
				
						DB_Delete( strDeleteIndex );
						Response.Write("<script>alert('���� �Ǿ����ϴ�.')</script>");
						btnSearch_Click(sender, e);
					}
					else
					{
						Response.Write("<script>alert('���õ� ���� �����ϴ�.')</script>");
					}
				}
			}
		}


		// �������� DB�� ������ �����ϴ� �޼���
		private void DB_Delete( string strDeleteIndex )
		{
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			SqlCommand cmd = new SqlCommand("EtcBuyingOrderPC_Delete", con);
			SqlTransaction tran = null;
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@Delindex", SqlDbType.VarChar).Value = strDeleteIndex;

			try
			{
				con.Open();
				tran = con.BeginTransaction();
				cmd.Transaction = tran;

				cmd.ExecuteNonQuery();
				tran.Commit();
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				tran.Rollback();
			}
			finally
			{
				con.Close();
			}
		}



		// ���������� �����Ǿ����� true ���� ����
		private bool DB_Update(string[] strArrUdValue)
		{	
			bool bResult = false;
			SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			SqlCommand cmd = new SqlCommand("EtcBuyingOrderPC_Update", con);
			SqlTransaction tran = null;
			cmd.CommandType = CommandType.StoredProcedure;
		
			cmd.Parameters.Add("@itemNum", SqlDbType.VarChar).Value = strArrUdValue[0];
			cmd.Parameters.Add("@ApplyUnitCost", SqlDbType.Decimal).Value = strArrUdValue[1];
			cmd.Parameters.Add("@OrderQuantity", SqlDbType.Decimal).Value = strArrUdValue[2];
			cmd.Parameters.Add("@TotalCost", SqlDbType.Decimal).Value = strArrUdValue[3];
			cmd.Parameters.Add("@DeliveryDemandDate", SqlDbType.SmallDateTime).Value = strArrUdValue[4];
			cmd.Parameters.Add("@UpdatePersonID", SqlDbType.VarChar).Value = strArrUdValue[5];
			cmd.Parameters.Add("@EtcBuyingOrderHistoryIndex", SqlDbType.Int).Value = strArrUdValue[6];
			cmd.Parameters.Add("@ReasonName", SqlDbType.VarChar).Value = strArrUdValue[7];
			cmd.Parameters.Add("@ReasonCode", SqlDbType.VarChar).Value = strArrUdValue[8];

			try
			{
				con.Open();
				tran = con.BeginTransaction();
				cmd.Transaction = tran;

				cmd.ExecuteNonQuery();
				tran.Commit();
				bResult = true;
			}
			catch(Exception ex)
			{
				Response.Write("<script>alert(\"" + ex.Message + "\")</script>");
				tran.Rollback();
				bResult = false;;
			}
			finally
			{
				con.Close();
			}

			return bResult;
		}



		// Row Template �� ������ư Ŭ���� �߻��ϴ� __doPostBack �̺�Ʈ
		private void lkbtnUpdate_Click(object sender, System.EventArgs e)
		{
			if(MonthClosing())
			{
				string[] strArrUdValue = new string[9];
				// ���� ������ ���� ��ȣ(DB �ε��� ��ȣ�� �ƴ�)
				int i = int.Parse(hdIndex.Value);
			

				strArrUdValue[0] = UltraWebGrid1.Rows[i].Cells.FromKey("ItemName").Value.ToString();
				strArrUdValue[1] = UltraWebGrid1.Rows[i].Cells.FromKey("ApplyUnitCost").Value.ToString();
				strArrUdValue[2] = UltraWebGrid1.Rows[i].Cells.FromKey("OrderQuantity").Value.ToString();
				strArrUdValue[3] = UltraWebGrid1.Rows[i].Cells.FromKey("TotalCost").Value.ToString();
				strArrUdValue[4] = UltraWebGrid1.Rows[i].Cells.FromKey("DeliveryDemandDate").Value.ToString();	
				strArrUdValue[5] = Session["ID"].ToString();
				strArrUdValue[6] = UltraWebGrid1.Rows[i].Cells.FromKey("EtcBuyingOrderHistoryIndex").Value.ToString();
				strArrUdValue[7] = UltraWebGrid1.Rows[i].Cells.FromKey("ReasonName").Value.ToString();
				strArrUdValue[8] = UltraWebGrid1.Rows[i].Cells.FromKey("ReasonCode").Value.ToString();

				if ( DB_Update(strArrUdValue) )
				{
					Response.Write("<script>alert('���� �Ǿ����ϴ�.')</script>");
				}
			}
			else
			{
				RegisterStartupScript("","<script>alert('�������� �Ǿ� ������ �Ұ��� �մϴ�!');</script>");
			}

			btnSearch_Click(sender, e);
		}

		

		//Excel
		private void btnExcel_Click(object sender, System.EventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.AllowPaging = false;
			UltraWebGrid1.Columns.FromKey("chk").Hidden = true;

			SqlDataAdapter adap = new SqlDataAdapter("EtcBuyingOrderPC_Search", ConfigurationSettings.AppSettings["DSN"]);
			adap.SelectCommand.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = txtItemName.Text;
			adap.SelectCommand.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = CSC1.Company;
			adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar).Value = CSC1.BusinessRegistrationNum;
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate", SqlDbType.VarChar).Value = wcDeliveryDate.Text;
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate1", SqlDbType.VarChar).Value = wcDeliveryDate1.Text;
			adap.SelectCommand.Parameters.Add("@RecodingState", SqlDbType.VarChar).Value =ddlState.SelectedItem.Value;

			adap.SelectCommand.CommandType = CommandType.StoredProcedure;
			DataSet ds = new DataSet();
			adap.Fill(ds);

			UltraWebGrid1.DataSource = ds.Tables[0].DefaultView;
			UltraWebGrid1.DataBind();

			UltraWebGridExcelExporter1.Export(UltraWebGrid1);
		}

		private void UltraWebGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			
			SqlDataAdapter adap = new SqlDataAdapter("EtcBuyingOrderPC_Search", ConfigurationSettings.AppSettings["DSN"]);
			adap.SelectCommand.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = txtItemName.Text;
			adap.SelectCommand.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = CSC1.Company;
			adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar).Value = CSC1.BusinessRegistrationNum;
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate", SqlDbType.VarChar).Value = wcDeliveryDate.Text;
			adap.SelectCommand.Parameters.Add("@DeliveryDemandDate1", SqlDbType.VarChar).Value = wcDeliveryDate1.Text;
			adap.SelectCommand.Parameters.Add("@RecodingState", SqlDbType.VarChar).Value =ddlState.SelectedItem.Value;

			adap.SelectCommand.CommandType = CommandType.StoredProcedure;
			DataSet ds = new DataSet();
			adap.Fill(ds);

			UltraWebGrid1.DataSource = ds.Tables[0].DefaultView;
			UltraWebGrid1.DataBind();
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Infragistics.WebUI.UltraWebGrid.UltraWebGrid UWG = UltraWebGrid1;
			bool check = true;
			for(int count = UltraWebGrid1.Rows.Count-1 ; count >=0 ; count--)
			{
				if(UWG.Rows[count].Cells.FromKey("chk").Value == null || UWG.Rows[count].Cells.FromKey("chk").Value.ToString() == "false")
					UWG.Rows[count].Delete();
			}

			if(UWG.Rows.Count == 0)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �����ϴ�!');</script>");
			}
			else if(UWG.Rows.Count > 12)
			{
				check = false;
				RegisterStartupScript("","<script>alert('������ �׸��� �ʹ� �����ϴ�!');</script>");
			}
			else
			{
				for(int i = 0; i < UWG.Rows.Count; i++)
				{
					// üũ���� ������ Value���� null�̴� �׷��Ƿ� Ȯ���� false���� �־��ش�.
					if(UWG.Rows[0].Cells.FromKey("BusinessRegistrationNum").Text != UWG.Rows[i].Cells.FromKey("BusinessRegistrationNum").Text)
					{
						check = false;
						RegisterStartupScript("","<script>alert('������ �ŷ�ó�� 2�� �̻��Դϴ�!');</script>");
					}
				}
			}


			if(check)
			{
					
				Session["Grid"] = UWG;
				RegisterStartupScript("","<script>window.open('./Popup/EtcPurchase.aspx','','width=1000, heigth=800,scrollbars=yes,menubar=yes,status=yes,toolbar=yes,center=yes');</script>");
							
			}
			else
			{
				UltraWebGrid1.Columns[0].AllowUpdate = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
				UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = 1;


				SqlDataAdapter adap = new SqlDataAdapter("EtcBuyingOrderPC_Search", ConfigurationSettings.AppSettings["DSN"]);
				adap.SelectCommand.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = txtItemName.Text;
				adap.SelectCommand.Parameters.Add("@CompanyName", SqlDbType.VarChar).Value = CSC1.Company;
				adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar).Value = CSC1.BusinessRegistrationNum;
				adap.SelectCommand.Parameters.Add("@DeliveryDemandDate", SqlDbType.VarChar).Value = wcDeliveryDate.Text;
				adap.SelectCommand.Parameters.Add("@DeliveryDemandDate1", SqlDbType.VarChar).Value = wcDeliveryDate1.Text;
				adap.SelectCommand.Parameters.Add("@RecodingState", SqlDbType.VarChar).Value =ddlState.SelectedItem.Value;

				adap.SelectCommand.CommandType = CommandType.StoredProcedure;
				DataSet ds = new DataSet();
				adap.Fill(ds);

				UltraWebGrid1.DataSource = ds.Tables[0].DefaultView;
				UltraWebGrid1.DataBind();
			}
		}

		/// <summary>
		/// ������ ������ ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing()
		{
			int count = int.Parse(hdIndex.Value);
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

			
			if(year < DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Year)
				return true; 
			else if(year == DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Year)
			{
				if(month < DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Month)
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}		
		}

		/// <summary>
		/// �����ÿ����� ���θ� Ȯ���ϴ� �Լ�
		/// </summary>
		/// <returns></returns>
		private bool MonthClosing1(int count)
		{
			
			int year = 0;
			int month = 0;
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DSN"]);
			conn.Open();
			string str = "Select ClosingYear, ClosingMonth From MCI_MT Where AffairDistinction = @Distinction";
			SqlCommand comm =  new SqlCommand(str,conn);
			comm.Parameters.Add("@Distinction",SqlDbType.VarChar).Value = "����";
			SqlDataReader dr = comm.ExecuteReader();
			while(dr.Read())
			{
				year = int.Parse(dr[0].ToString());
				month = int.Parse(dr[1].ToString());
			}
			conn.Close();

		
			if (Convert.ToBoolean( UltraWebGrid1.Rows[count].Cells.FromKey("chk").Value ))
			{
				if(year < DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Year)
					return true; 
				else if(year == DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Year)
				{
					if(month < DateTime.Parse(UltraWebGrid1.Rows[count].Cells.FromKey("DeliveryDemandDate").Text).Month)
						return true;
					else
						return false;
				}
				else
				{
					return false;
				}	
			}
			else
				return true;
			
		}

	}
}
