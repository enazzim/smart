using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace KIT_ERP.ProductionManagement.ItemSearchControl
{
	/// <summary>
	/// popUp_ItemSearch�� ���� ��� �����Դϴ�.
	/// </summary>
	public class popUp_ItemSearch : System.Web.UI.Page
	{
		protected Infragistics.WebUI.UltraWebGrid.UltraWebGrid UltraWebGrid1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			Bind();
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.UltraWebGrid1.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.UltraWebGrid1_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void UltraWebGrid1_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			UltraWebGrid1.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
			Bind();
		}

		private void Bind()
		{
			try
			{
				string strConnectionString = ConfigurationSettings.AppSettings["DSN"];
				string strTag = Request["tag"].ToString();			// �˻� �׸�
				string strValue = Request["value"].ToString();		// �˻���
				string[] arrStrValue = new String[5];
				string strBusinessRegistrationNum = Request["businessregistrationnum"];	// �ŷ�ó��
				string strUnitCostDistinction = Request["unitcostdistinction"];
				arrStrValue = Request["propertyClassification"].ToString().Split(';');;		// �˻���
				
				
				SqlDataAdapter adap = new SqlDataAdapter("ItemSearch_Popup", strConnectionString);
				adap.SelectCommand.CommandType = CommandType.StoredProcedure;
				adap.SelectCommand.Parameters.Add("@Tag", SqlDbType.VarChar, 30).Value = strTag;
				adap.SelectCommand.Parameters.Add("@Value", SqlDbType.VarChar, 50).Value = strValue;

				adap.SelectCommand.Parameters.Add("@��ǰ", SqlDbType.Bit).Value = Convert.ToBoolean( arrStrValue[0]);
				adap.SelectCommand.Parameters.Add("@��ǰ", SqlDbType.Bit).Value = Convert.ToBoolean( arrStrValue[1]);
				adap.SelectCommand.Parameters.Add("@����", SqlDbType.Bit).Value = Convert.ToBoolean( arrStrValue[2]);
				adap.SelectCommand.Parameters.Add("@����ǰ", SqlDbType.Bit).Value = Convert.ToBoolean( arrStrValue[3]);
				adap.SelectCommand.Parameters.Add("@������", SqlDbType.Bit).Value = Convert.ToBoolean( arrStrValue[4]);
				
				if ( strBusinessRegistrationNum != "" )
					adap.SelectCommand.Parameters.Add("@BusinessRegistrationNum", SqlDbType.VarChar, 50 ).Value = strBusinessRegistrationNum;
				if ( strUnitCostDistinction != "" )
					adap.SelectCommand.Parameters.Add("@UnitCostDistinction", SqlDbType.VarChar, 20 ).Value = strUnitCostDistinction;

				DataSet ds = new DataSet();

				adap.Fill(ds);
            
				UltraWebGrid1.DataSource = ds.Tables[0].DefaultView;
				UltraWebGrid1.DataBind();
			}
			catch( Exception Ex )
			{
				Response.Write("<script>alert(\"" + Ex.Message + "\"); window.close();</script>");
			}
		}
	}
}

